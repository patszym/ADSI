<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Tache par cycle
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation2.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> A l'appel du menu général, le mode <b> Liste et Edition</b> est le mode par défaut</p>
			<p> Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence Tachecycle. Les fichiers associés 
			sont mémorisés en binaires dans la base de données</p>
			<p> Cliquez sur l'image de l'oeil pour voir le détail de la ligne spécifiée en consultation dans la liste. </p>
			<p> Cliquez sur l'image du crayon pour voir le détail de la ligne spécifiée en modification dans la liste. </p>
			<p> Cliquez sur l'image de la croix pour voir le détail de la ligne spécifiée en suppression dans la liste</p>
			<p>Cliquez sur l'icône <b>PDF</b> pour voir le détail de la ligne en obtenant son édition PDF </p>
			
			<p>Cliquez sur l'icône <b>PDF</b> à gauche du titre pour obtenir l'édition PDF de la liste</p>
			
	</div><!-- #secondaire -->
		
	<div id="principal"> 
			<h5>Gestion des taches par cycles </h5>
			
		
			<div id="tabsF">
				<?php include('include/MHTC.php'); 
				session_start();
				$ses_id = session_id();
				?> 
									
			</div>
		
		<fieldset class="saisie">
			<table BORDER=0>
			
			<tr>
			
				<td>
				<a href="editions/edTCPDF.php">
				<img src="images/pdficon.jpg" height="20" width="20" align = "center" 
				alt="PDF">
				</a>
				
				</td>
				<td></td>
				<td>
				<h3>  LISTE DES TACHES PAR CYCLE </h3>
				</td>
			</tr>
				
				<?php 
				include('include/con2log.php');
	
				$sql = 'select idTACHE, idTACHECYCLE, 
					 datePrevOuvTACHECYCLE, dateEffOuvTACHECYCLE,
					datePrevFerTACHECYCLE, dateEffFerTACHECYCLE,
					datePrevFinTACHECYCLE, dateEffFinTACHECYCLE,
					libelleCourtCYCLE, libelleTACHE, idTACHE, 
					libellePROCESSUS, libelleCAMPAGNE,  
					idPROCESSUS, idCAMPAGNE, idAppli, nomAPPLI,
					filenameCompRendTACHECYCLE, extensionCompRendTACHECYCLE
					
					from TACHECYCLE, TACHE, PROCESSUS, CAMPAGNE, APPLI, CYCLE';
				if (isset ($adm))
				
				{
					if ($adm == 0)
					{
						$sql=$sql.' , APPLI_has_UTI';
						
							
					}
				}
				$sql=$sql.' where CAMPAGNE.APPLI_idAPPLI = APPLI.idAPPLI
					and TACHE.PROCESSUS_idPROCESSUS = PROCESSUS.idPROCESSUS
					and PROCESSUS.CAMPAGNE_idCAMPAGNE = CAMPAGNE.idCAMPAGNE
					and TACHECYCLE.TACHE_idTACHE = TACHE.idTACHE
					and TACHECYCLE.CYCLE_idCYCLE = CYCLE.idCYCLE';
				if (isset($adm))
				
				{
					if ($adm == 0)
					{
				
						$sql=$sql.' AND APPLI.idAPPLI = APPLI_has_UTI.APPLI_idAPPLI';
						$sql=$sql.' AND APPLI_has_UTI.UTI_idUTI = :idUti';
					}
				}
				$sql=$sql.' order by nomAPPLI, libelleCAMPAGNE, libelleTACHE, libelleCourtCYCLE, datePrevOuvTACHECYCLE';
	
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				if (isset ($adm))
				
				{
					if ($adm == 0)
					{
				
						$query->bindParam(':idUti', $idUti, PDO::PARAM_INT);
					}
				}
				
				include_once "include/visuConvTC.php";
				
				$i = 0 ;
				$idRowTache = null;
				
				$idTachecycle = null ;
				
				$datePrevOuvTachecycle =  null;
				$dateEffOuvTachecycle = null;
				$datePrevFerTachecycle =  null;
				$dateEffFerTachecycle = null;
				$datePrevFinTachecycle =  null;
				$dateEffFinTachecycle = null;
				$libelleCourtCycle = null ;
				$libelleTache = null;
				$idTache = null ;
				$libelleProcessus = null;
				$libelleCampagne =  null ;
				$idProcessus = null;
				$idCampagne = null;
				$idAppli = null;
				$nomAppli = null;
				$filenameCompRendTachecycle = null;
				$extensionCompRendTachecycle= null;
				
			
				
				
				while ($i<$maxRow)
				{
					$idRowTache =  $tableau [$i][0] ;
					$idTachecycle =  $tableau [$i][1] ;
					$datePrevOuvTachecycle=  $tableau [$i][2] ;
					$dateEffOuvTachecycle =  $tableau [$i][3] ;
					$datePrevFerTachecycle =  $tableau [$i] [4];
					$dateEffFerTachecycle =  $tableau [$i] [5];
					$datePrevFinTachecycle =  $tableau [$i] [6];
					$dateEffFinTachecycle  = $tableau [$i] [7];
					$libelleCourtCycle  = $tableau [$i] [8];
					$libelleTache = $tableau [$i] [9];
					$idTache= $tableau [$i] [10];
					$libelleProcessus  = $tableau [$i] [11];
					$libelleCampagne  = $tableau [$i] [12];
					$idProcessus = $tableau [$i] [13];
					$idCampagne = $tableau [$i] [14];
					$idAppli   = $tableau [$i] [15];
					$nomAppli   = $tableau [$i] [16];
					$filenameCompRendTachecycle= $tableau [$i] [17];
					$extensionCompRendTachecycle= $tableau [$i] [18];
					
					
					$i++;
					/* Exploitation des lignes dans la liste */
					?>
					
					<?php include "include/convDatesTC.php" ;?> 				
				
				<!-- Liste des  Tachecycles - formulaire en lecture -->
									
									
						
							<input type="hidden" name="idTachecycle"
							value="<?php echo htmlspecialchars($idTachecycle); ?>"
							maxlength="3" size="3" ></input>
					
					<tr>
						<td>								
							<input type="text" name="libelleCourtCycle" 
								value="<?php echo htmlspecialchars($libelleCourtCycle); ?>" 
								maxlength="10" size="10" readonly></input>
						</td>
						
						<td>
							<input type="text" name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="10" readonly></input>
						</td>
						<td>
							<input type="text" name="libelleCampagne" 
							value="<?php echo htmlspecialchars($libelleCampagne); ?>" 
							maxlength="100" size="50" readonly></input>
						</td>
					</tr>
					<tr>
						
						
						<td>
							
						</td>
						<td>
							
						</td>
						<td>
							<input type="text" name="libelleProcessus" 
							value="<?php echo htmlspecialchars($libelleProcessus); ?>" 
							maxlength="100" size="50" readonly></input>
						</td>
					</tr>
					<tr>
						
						
						<td>
							
						</td>
						<td>
							
						</td>
						<td>
							<input type="text" name="libelleTache" 
							value="<?php echo htmlspecialchars($libelleTache); ?>" 
							maxlength="100" size="50" readonly></input>
						</td>
						
						<td>
							<form action="consTC.php" method="post">

			 					<input type="hidden" name="idTachecycle" 
			 					value="<?php echo htmlspecialchars($idTachecycle); ?>">
			 					</input>
			 					<input type="hidden" name="idProcessus" 
			 					value="<?php echo htmlspecialchars($idProcessus); ?>">
			 					</input>
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form> 
						</td>
						<td>
							<form action="modifTC.php" method="post">

			 					<input type="hidden" name="idTachecycle" 
			 					value="<?php echo htmlspecialchars($idTachecycle); ?>">
			 					</input>
			 					<input type="hidden" name="idProcessus" 
			 					value="<?php echo htmlspecialchars($idProcessus); ?>">
			 					</input>
								<input border=0 src="images/crayon.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form>
						</td>
							<td> 
							<form action="supprTC.php" method="post">

			 					<input type="hidden" name="idTachecycle" 
			 					value="<?php echo htmlspecialchars($idTachecycle); ?>">
			 					</input>
			 					<input type="hidden" name="idProcessus" 
			 					value="<?php echo htmlspecialchars($idProcessus); ?>">
			 					</input>
								<input border=0 src="images/button-cancel.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form>
						</td> 
						<td> 					
							
							<form action="editions/edElTCPDF.php" method="post">
							
								<input type="hidden" name="nomAppli" 
								value="<?php echo htmlspecialchars($nomAppli); ?>">
								</input>
			 					<input type="hidden" name="libelleProcessus" 
								value="<?php echo htmlspecialchars($libelleProcessus); ?>">
								</input>
			 					<input type="hidden" name="libelleCampagne" 
								value="<?php echo htmlspecialchars($libelleCampagne); ?>">
								</input>
								<input type="hidden" name="libelleTache" 
								value="<?php echo htmlspecialchars($libelleTache); ?>">
								</input>
								<input type="hidden" name="libelleCourtCycle" 
								value="<?php echo htmlspecialchars($libelleCourtCycle); ?>">
								</input>
			 					<input type="hidden" name="idTachecycle" 
								value="<?php echo htmlspecialchars($idTachecycle); ?>">
								</input>
			 				
								<input type="hidden" name="dPrevOuvTachecycle" 
								value="<?php echo htmlspecialchars($dPrevOuvTachecycle); ?>">
								</input>
							
								<input type="hidden" name="HPrevOuvTachecycle" 
								value="<?php echo htmlspecialchars($HPrevOuvTachecycle); ?>">
								</input>
								
								<input type="hidden" name="iPrevOuvTachecycle" 
								value="<?php echo htmlspecialchars($iPrevOuvTachecycle); ?>">
								</input>
								
								<input type="hidden" name="dEffOuvTachecycle" 
								value="<?php echo htmlspecialchars($dEffOuvTachecycle); ?>">
								</input>
							
								<input type="hidden" name="HEffOuvTachecycle" 
								value="<?php echo htmlspecialchars($HEffOuvTachecycle); ?>">
								</input>
								
								<input type="hidden" name="iEffOuvTachecycle" 
								value="<?php echo htmlspecialchars($iEffOuvTachecycle); ?>">
								</input>
								
								<input type="hidden" name="dPrevFerTachecycle" 
								value="<?php echo htmlspecialchars($dPrevFerTachecycle); ?>">
								</input>
							
								<input type="hidden" name="HPrevFerTachecycle" 
								value="<?php echo htmlspecialchars($HPrevFerTachecycle); ?>">
								</input>
								<input type="hidden" name="iPrevFerTachecycle" 
								value="<?php echo htmlspecialchars($iPrevFerTachecycle); ?>">
								</input>
								
								<input type="hidden" name="dEffFerTachecycle" 
								value="<?php echo htmlspecialchars($dEffFerTachecycle); ?>">
								</input>
							
								<input type="hidden" name="HEffFerTachecycle" 
								value="<?php echo htmlspecialchars($HEffFerTachecycle); ?>">
								</input>
								
								<input type="hidden" name="iEffFerTachecycle" 
								value="<?php echo htmlspecialchars($iEffFerTachecycle); ?>">
								</input>
								
								<input type="hidden" name="dPrevFinTachecycle" 
								value="<?php echo htmlspecialchars($dPrevFinTachecycle); ?>">
								</input>
							
								<input type="hidden" name="HPrevFinTachecycle" 
								value="<?php echo htmlspecialchars($HPrevFinTachecycle); ?>">
								</input>
								<input type="hidden" name="iPrevFinTachecycle" 
								value="<?php echo htmlspecialchars($iPrevFinTachecycle); ?>">
								</input>
								
								<input type="hidden" name="dEffFinTachecycle" 
								value="<?php echo htmlspecialchars($dEffFinTachecycle); ?>">
								</input>
							
								<input type="hidden" name="HEffFinTachecycle" 
								value="<?php echo htmlspecialchars($HEffFinTachecycle); ?>">
								</input>
								
								<input type="hidden" name="iEffFinTachecycle" 
								value="<?php echo htmlspecialchars($iEffFinTachecycle); ?>">
								</input>
								
								<input type="hidden" name="filenameCompRendTachecycle" 
								value="<?php echo htmlspecialchars($filenameCompRendTachecycle); ?>">
								</input>
								
								<input type="hidden" name="extensionCompRendTachecycle" 
								value="<?php echo htmlspecialchars($extensionCompRendTachecycle); ?>">
								</input>
														
			 					<input border=0 src="images/pdficon.jpg" 
								type=image value=submit name = "soumet" align="left" 
								height="20" width="20">
								</input>

										
							</form>
						</td> 
											
					</tr>			
										
							
				<?php 
				}
				$query = null;
				?>
			</table>
		</fieldset>

		</div> <!-- principal-->
	
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
