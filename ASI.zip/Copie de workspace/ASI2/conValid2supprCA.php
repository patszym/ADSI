<?php	
			  
if(!empty($_POST["soumet"]))
{
					$idCalendrier = null;
					
					
					if(!empty($_POST["idCalendrier"]))
					{
						$idCalendrier=$_POST["idCalendrier"];
					} 
					
					include('include/connBase.php');
					
					// Contrôles de cohérence de la base pour les clés étrangères déclarées dans les autres tables
					// à la suppression. Normalement c'est fait des triggers (sous Oracle), mais pas sur Mysql
					// donc la cohérence de la base est assurée au niveau de la programmation
					// ---> clé étrangère de CALENDRIER dans la table APPLI
					
					$validBase = true;
					
				
				if ($validBase)
				{
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					
						$sql = 'DELETE FROM CALENDRIER WHERE idCALENDRIER = :idCalendrier ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idCalendrier', $idCalendrier, PDO::PARAM_INT);
					
						$sth->execute();
					
						echo "Validation de la suppression faite";
				
					} catch (Exception $e) {
					
						echo "la suppression a échouée: " . $e->getMessage();
					}
				}
}
			
				
			?>	