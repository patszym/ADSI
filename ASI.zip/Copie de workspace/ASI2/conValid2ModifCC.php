<?php	
include_once('include/ConversionDates.class.php');
if(!empty($_POST["soumet"]))
{

					$idCampagnecycle = $_POST["idCampagnecycle"];
					

					if(!empty($_POST["idCampagne"]))
					{
						$idCampagne=$_POST["idCampagne"];
					
					} else
					{
						$idCampagne = null;
						
					}

					if(!empty($_POST["idCycle"]))
					{
						$idCycle=$_POST["idCycle"];
						
						
					} else
					{
						$idCycle = null;
						
					}
					
				

					$dateversRowPrevOuvCampagnecycle  = null;
					$validdatePrevOuvCampagnecycle = true;
						
					if (!empty($_POST["datePrevOuvCampagnecycle"]))
					{
							
					
						$conversionDate1 = new ConversionDates();
						$conversionDate1->setdt($_POST['datePrevOuvCampagnecycle']);
						if (isset($_POST['HPrevOuvCampagnecycle']))
						{
							$H = $_POST['HPrevOuvCampagnecycle'];
					
							if (($H>24) or ($H<00))
							{
								echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
									
								$H = "00";
							}
						}
						else
						{
							$H = "00";
						}
							
					
						$conversionDate1->setH($H);
					
					
						if (isset($_POST['iPrevOuvCampagnecycle']))
						{
							$i = $_POST['iPrevOuvCampagnecycle'];
							if (($i>60) or ($i<00))
							{
								echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
								$i = "00";
							}
						}
						else
						{
							$i = "00";
						}
					
						$conversionDate1->seti($i);
					
					
						$conversionDate1->convdDate();
					
					
						$dateversRowPrevOuvCampagnecycle = $conversionDate1->getdate() ;
					
						if (!checkdate($conversionDate1->getm(), $conversionDate1->getd(), $conversionDate1->getY()))
						{
					
							$validdatePrevOuvCampagnecycle = false;
							echo $datePrevOuvCampagnecycle. " n'est pas une date et une heure valide <br>";
							?>
													<script language="javascript">
													alert("Date  non conforme au format d'une date");
													</script>
													<?php
											}
										} 
										else
										{
												$dateversRowPrevOuvCampagnecycle  = null;
												
										}
									
					
										$dateversRowEffOuvCampagnecycle  = null;
										$validdateEffOuvCampagnecycle = true;
											
										if (!empty($_POST["dateEffOuvCampagnecycle"])) 
										{
												
												
											$conversionDate2 = new ConversionDates();
											$conversionDate2->setdt($_POST['dateEffOuvCampagnecycle']);
											if (isset($_POST['HEffOuvCampagnecycle']))
											{
												$H = $_POST['HEffOuvCampagnecycle'];
										
												if (($H>24) or ($H<00))
												{
													echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
													
													$H = "00";
												}
											}
											else
											{
												$H = "00";
											}
										
											$conversionDate2->setH($H);
											if (isset($_POST['iEffOuvCampagnecycle']))
											{
												$i = $_POST['iEffOuvCampagnecycle'];
												if (($i>60) or ($i<00))
												{
													echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
													$i = "00";
												}
											}
											else
											{
												$i = "00";
											}
											
										
											$conversionDate2->seti($i);
										
										
											$conversionDate2->convdDate();
										
										
											$dateversRowEffOuvCampagnecycle = $conversionDate2->getdate() ;
										
											if (!checkdate($conversionDate2->getm(), $conversionDate2->getd(), $conversionDate2->getY()))
											{
										
												$validdateEffOuvCampagnecycle = false;
												echo $dateEffOuvCampagnecycle. " n'est pas une date et une heure valide <br>";
												?>
																		<script language="javascript">
																		alert("Date  non conforme au format d'une date");
																		</script>
												<?php
											}
										} 
										else
										{
											$dateversRowEffOuvCampagnecycle  = null;
																	
										}
														
																	
											// date de fermeture :
					
										$dateversRowPrevFerCampagnecycle  = null;
										$validdatePrevFerCampagnecycle = true;
																
										if (!empty($_POST["datePrevFerCampagnecycle"])) 
										{
																	
																	
											$conversionDate3 = new ConversionDates();
											$conversionDate3->setdt($_POST['datePrevFerCampagnecycle']);
											if (isset($_POST['HPrevFerCampagnecycle']))
											{
												$H = $_POST['HPrevFerCampagnecycle'];
															
												if (($H>24) or ($H<00))
												{
													echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
																		
													$H = "00";
												}
											}
											else
											{
												$H = "00";
											}				
											$conversionDate3->setH($H);
											if (isset($_POST['iPrevFerCampagnecycle']))
											{				
												$i = $_POST['iPrevFerCampagnecycle'];
												if (($i>60) or ($i<00))
												{
													echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
													$i = "00";
												}
											}
											else
											{
												$i = "00";
											}
															
											$conversionDate3->seti($i);
															
															
											$conversionDate3->convdDate();
															
															
											$dateversRowPrevFerCampagnecycle = $conversionDate3->getdate() ;
															
											if (!checkdate($conversionDate3->getm(), $conversionDate3->getd(), $conversionDate3->getY()))
											{
															
												$validdatePrevFerCampagnecycle = false;
												echo $datePrevFerCampagnecycle. " n'est pas une date et une heure valide <br>";
												?>
														<script language="javascript">
													alert("Date  non conforme au format d'une date");
													</script>
												<?php
											}
										} 
										else
										{
											$dateversRowPrevFerCampagnecycle  = null;
																						
										}
																			
															
										$dateversRowEffFerCampagnecycle  = null;
										$validdateEffFerCampagnecycle = true;
																					
										if (!empty($_POST["dateEffFerCampagnecycle"])) 
										{
																						
																						
											$conversionDate4 = new ConversionDates();
											$conversionDate4->setdt($_POST['dateEffFerCampagnecycle']);
											
											if (isset($_POST['HEffFerCampagnecycle']))
											{
												$H = $_POST['HEffFerCampagnecycle'];
																				
												if (($H>24) or ($H<00))
												{
													echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
																							
													$H = "00";
												}
											}
											else
											{
												$H = "00";
											}
																				
											$conversionDate4->setH($H);
											if (isset($_POST['iEffFerCampagnecycle']))
											{
																				
												$i = $_POST['iEffFerCampagnecycle'];
												if (($i>60) or ($i<00))
												{
													echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
													$i = "00";
												}
											}
											else
											{
												$i = "00";
											}
																				
											$conversionDate4->seti($i);
																				
																				
											$conversionDate4->convdDate();
																				
																				
											$dateversRowEffFerCampagnecycle = $conversionDate4->getdate() ;
																				
											if (!checkdate($conversionDate4->getm(), $conversionDate4->getd(), $conversionDate4->getY()))
											{
																				
																						$validdateEffFerCampagnecycle = false;
																						echo $dateEffFerCampagnecycle. " n'est pas une date et une heure valide <br>";
												?>
																												<script language="javascript">
																												alert("Date  non conforme au format d'une date");
																												</script>
												<?php
											}
										} 
										else
										{
											$dateversRowEffFerCampagnecycle  = null;
																											
										}
																								
																											
														// date de fin :
					
									$dateversRowPrevFinCampagnecycle  = null;
									$validdatePrevFinCampagnecycle = true;
																										
									if (!empty($_POST["datePrevFinCampagnecycle"])) 
									{
																											
																											
										$conversionDate5 = new ConversionDates();
										$conversionDate5->setdt($_POST['datePrevFinCampagnecycle']);
										if (isset($_POST['HPrevFinCampagnecycle']))
										{
											$H = $_POST['HPrevFinCampagnecycle'];
																									
											if (($H>24) or ($H<00))
											{
												echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
																												
												$H = "00";
											}
										}
										else
										{
											$H = "00";
										}
										
																									
										$conversionDate5->setH($H);
										if (isset($_POST['iPrevFinCampagnecycle']))
										{															
											$i = $_POST['iPrevFinCampagnecycle'];
											if (($i>60) or ($i<00))
											{
												echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
												$i = "00";
											}
										}
										else
										{
											$i = "00";
										}	
																									
										$conversionDate5->seti($i);
																									
																									
										$conversionDate5->convdDate();
																									
																									
										$dateversRowPrevFinCampagnecycle = $conversionDate5->getdate() ;
																									
										if (!checkdate($conversionDate5->getm(), $conversionDate5->getd(), $conversionDate5->getY()))
										{
																									
											$validdatePrevFinCampagnecycle = false;
											echo $datePrevFinCampagnecycle. " n'est pas une date et une heure valide <br>";
											?>
																																	<script language="javascript">
																																	alert("Date  non conforme au format d'une date");													</script>
											<?php
										}
									} 
									else
									{
										$dateversRowPrevFinCampagnecycle  = null;
																																
									}
																													
																									
									$dateversRowEffFinCampagnecycle  = null;
									$validdateEffFinCampagnecycle = true;
																															
									if (!empty($_POST["dateEffFinCampagnecycle"])) 
									{
																																
																																
										$conversionDate6 = new ConversionDates();
										$conversionDate6->setdt($_POST['dateEffFinCampagnecycle']);
										if (isset($_POST['HEffFinCampagnecycle']))
										{
											$H = $_POST['HEffFinCampagnecycle'];
																														
											if (($H>24) or ($H<00))
											{
												echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
																																	
												$H = "00";
											}
										}
										else
										{
											$H = "00";
										}
																														
										$conversionDate6->setH($H);
										if (isset($_POST['iEffFinCampagnecycle']))
										{																				
											$i = $_POST['iEffFinCampagnecycle'];
											if (($i>60) or ($i<00))
											{
												echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
												$i = "00";
											}
										}
										else 
										{
											$i = "00";
										}
											
																														
										$conversionDate6->seti($i);
																														
																														
										$conversionDate6->convdDate();
																														
																														
										$dateversRowEffFinCampagnecycle = $conversionDate6->getdate() ;
																														
										if (!checkdate($conversionDate6->getm(), $conversionDate6->getd(), $conversionDate6->getY()))
										{
																														
											$validdateEffFinCampagnecycle = false;
											echo $dateEffFinCampagnecycle. " n'est pas une date et une heure valide <br>";
											?>
																																						<script language="javascript">
																																						alert("Date  non conforme au format d'une date");
																																						</script>
											<?php
										}
									} 
									else
									{
										$dateversRowEffFinCampagnecycle  = null;
																																					
									}
																																		
																																					
																																							
																																
			$validBase = True;
			include('include/connBase.php');
								
			if ($validBase)
			{
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE CAMPAGNECYCLE SET '.
							' CYCLE_idCYCLE ="'.$idCycle.'",'.
							' CAMPAGNE_idCAMPAGNE ="'.$idCampagne.'"';
							
						
					
					if(!empty($_POST["datePrevOuvCampagnecycle"]))
					{
					$sql = $sql.', datePrevOuvCAMPAGNECYCLE ="'.$dateversRowPrevOuvCampagnecycle.'"';
					}
					else
					{
						$sql = $sql.', datePrevOuvCAMPAGNECYCLE = null';
					}
					
					

					if(!empty($_POST["dateEffOuvCampagnecycle"]))
					{
						$sql = $sql.', dateEffOuvCAMPAGNECYCLE ="'.$dateversRowEffOuvCampagnecycle.'"';
					}
					else
					{
						$sql = $sql.', dateEffOuvCAMPAGNECYCLE = null';
					}
					
					if(!empty($_POST["datePrevFerCampagnecycle"]))
					{
						$sql = $sql.', datePrevFerCAMPAGNECYCLE ="'.$dateversRowPrevFerCampagnecycle.'"';
					}
					else
					{
						$sql = $sql.', datePrevFerCAMPAGNECYCLE = null';
					}
						

					if(!empty($_POST["dateEffFerCampagnecycle"]))
					{
						$sql = $sql.', dateEffFerCAMPAGNECYCLE ="'.$dateversRowEffFerCampagnecycle.'"';
					}
					else
					{
						$sql = $sql.', dateEffFerCAMPAGNECYCLE = null';
					}
						
					
					if(!empty($_POST["datePrevFinCampagnecycle"]))
					{
						$sql = $sql.', datePrevFinCAMPAGNECYCLE ="'.$dateversRowPrevFinCampagnecycle.'"';
					}
					else
					{
						$sql = $sql.', datePrevFinCAMPAGNECYCLE = null';
					}
						
						
					if(!empty($_POST["dateEffFinCampagnecycle"]))
					{
						$sql = $sql.', dateEffFinCAMPAGNECYCLE ="'.$dateversRowEffFinCampagnecycle.'"';
					}
					else
					{
						$sql = $sql.', dateEffFinCAMPAGNECYCLE = null';
					}
						
					
				
					
					
					$sql = $sql.' WHERE idCAMPAGNECYCLE = :idCampagnecycle ';
					
					// echo $sql;
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idCampagnecycle', $idCampagnecycle, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			}
			
}
				
			?>	