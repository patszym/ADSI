<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		phases par cycle
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css">
	<style type="text/css">    
		div.ui-datepicker{
		font-size: 12px;
	}
	</style>
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
	<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
	<script src="jquery.ui.datepicker-fr.js"></script>
	<script>
		$(function() {
		$("#calendrier1").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		
	</script>
	<script>
		$(function() {
		$("#calendrier2").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		
	</script>
	<script>
		$(function() {
		$("#calendrier3").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		
	</script>
	<script>
		$(function() {
		$("#calendrier4").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		
	</script>
	<script>
		$(function() {
		$("#calendrier5").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		
	</script>
	<script>
		$(function() {
		$("#calendrier6").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		
	</script>
	
</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation2.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> Il faut valider l'ajout pour achever la tâche (bouton <b> valider </b>)</p>
			
			<p>Cliquez sur l'onglet <b>Liste et Edition </b> pour une consultation, 
			une modification, ou une suppression </p>
			<p> Cliquez sur l'onglet <b> Ajout </b> pour créer une occurence de Calendrier</p>
			
	</div><!-- #secondaire -->

	<div id="principal"> 
			<h5>Gestion des phases par cycle</h5>
			
			
			<div id="tabsF">
				<?php include('include/MHPC.php'); ?>
				<?php $idRowProcessus = null ; ?>
				<?php include('include/con1POs.php'); ?> 
				<?php $idRowCycle = null ; ?>
				<?php include('include/con1CYs.php'); ?> 
				<br></br>	
			<fieldset class="saisie">
			
			<form name="ajPC" id="ajPCForm" method="post"
				 enctype="multipart/form-data" 
					action="ajPC2.php">
				
				<table BORDER=0>	
					<!-- ajout Calendrier - formulaire -->
					<tr>
						<td>Phase :</td>
						<td>
						 <select   name="idProcessus">
							<?php
							
							$i = 0;
							while ($i<$index1)
							{
					
								 	echo '<option value="'.
										$tableau1 [$i][0].'"'.$tableau1 [$i][2].'>'.
										$tableau1 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
					
					<tr>
						<td>Cycle :</td>
						<td>
						 <select   name="idCycle">
							<?php
							
							$i = 0;
							while ($i<$index2)
							{
					
								 	echo '<option value="'.
										$tableau2 [$i][0].'"'.$tableau2 [$i][2].'>'.
										$tableau2 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
					
								
				
					<tr>
						<td> Date prévisionnelle d'ouverture : </td>
						<td>
							<INPUT type=text id="calendrier1" 
							name="datePrevOuvProcessuscycle" 
							value="" 
							maxlength="10" size="10" >
							</input>
						</td>
					</tr>
					<!--
					<tr>
						<td> Heure prévisionnelle d'ouverture : </td>
						<td>
							<INPUT type="text" 
							name="HPrevOuvProcessuscycle" 
							value="" 
							maxlength="2" size="2" >
							</input>
						</td>
					</tr>
					<tr>
						<td> Minutes prévisionnelle d'ouverture : </td>
						<td>
							<INPUT type="text" 
							name="iPrevOuvProcessuscycle" 
							value="" 
							maxlength="2" size="2" >
							</input>
						</td>
					</tr>
					-->			
						<tr>
						<td> Date effective d'ouverture : </td>
						<td>
							<INPUT type=text id="calendrier2" 
							name="dateEffOuvProcessuscycle" 
							value="" 
							maxlength="10" size="10" >
							</input>
						</td>
					</tr>
					<!--
					<tr>
						<td> Heure effective d'ouverture : </td>
						<td>
							<INPUT type="text" 
							name="HEffOuvProcessuscycle" 
							value="" 
							maxlength="2" size="2" >
							</input>
						</td>
					</tr>
					<tr>
						<td> Minutes effective d'ouverture : </td>
						<td>
							<INPUT type="text" 
							name="iEffOuvProcessuscycle" 
							value="" 
							maxlength="2" size="2" >
							</input>
						</td>
					</tr>
					-->						
					
				
					
					<tr>
						<td> Date prévisionnelle de fermeture : </td>
						<td>
							<INPUT type=text id="calendrier3" 
							name="datePrevFerProcessuscycle" 
							value="" 
							maxlength="10" size="10" >
							</input>
						</td>
					</tr>
					<!--
					<tr>
						<td> Heure prévisionnelle de fermeture : </td>
						<td>
							<INPUT type="text" 
							name="HPrevFerProcessuscycle" 
							value="" 
							maxlength="2" size="2" >
							</input>
						</td>
					</tr>
				
					<tr>
						<td> Minutes prévisionnelle de fermeture : </td>
						<td>
							<INPUT type="text" 
							name="iPrevFerProcessuscycle" 
							value="" 
							maxlength="2" size="2" >
							</input>
						</td>
					</tr>
					-->		
					<tr>
						<td> Date effective de fermeture : </td>
						<td>
							<INPUT type=text id="calendrier4" 
							name="dateEffFerProcessuscycle" 
							value="" 
							maxlength="10" size="10" >
							</input>
						</td>
					</tr>
					<!--
					<tr>
						<td> Heure effective de fermeture : </td>
						<td>
							<INPUT type="text" 
							name="HEffFerProcessuscycle" 
							value="" 
							maxlength="2" size="2" >
							</input>
						</td>
					</tr>
					<tr>
						<td> Minutes effective de fermeture : </td>
						<td>
							<INPUT type="text" 
							name="iEffFerProcessuscycle" 
							value="" 
							maxlength="2" size="2" >
							</input>
						</td>
					</tr>					
					-->		
					
					<tr>
						<td> Date prévisionnelle de fin : </td>
						<td>
							<INPUT type=text id="calendrier5" 
							name="datePrevFinProcessuscycle" 
							value="" 
							maxlength="10" size="10" >
							</input>
						</td>
					</tr>
					<!--
					<tr>
						<td> Heure prévisionnelle de fin : </td>
						<td>
							<INPUT type="text" 
							name="HPrevFinProcessuscycle" 
							value="" 
							maxlength="2" size="2" >
							</input>
						</td>
					</tr>
					<tr>
						<td> Minutes prévisionnelle de fin : </td>
						<td>
							<INPUT type="text" 
							name="iPrevFinProcessuscycle" 
							value="" 
							maxlength="2" size="2" >
							</input>
						</td>
					</tr>
					-->			
					<tr>
						<td> Date effective de fin : </td>
						<td>
							<INPUT type=text id="calendrier6" 
							name="dateEffFinProcessuscycle" 
							value="" 
							maxlength="10" size="10" >
							</input>
						</td>
					</tr>
					<!--
					<tr>
						<td> Heure effective de fin : </td>
						<td>
							<INPUT type="text" 
							name="HEffFinProcessuscycle" 
							value="" 
							maxlength="2" size="2" >
							</input>
						</td>
					</tr>
					<tr>
						<td> Minutes effective de fin : </td>
						<td>
							<INPUT type="text" 
							name="iEffFinProcessuscycle" 
							value="" 
							maxlength="2" size="2" >
							</input>
						</td>
					</tr>
					-->							
					
					
					<tr>
						<td>
						
					<input type="submit" value="Valider" name="soumet">
					</input>
						</td>
						<td>
					
					<input type="submit" value="Annuler">
					</input>
						</td>
					</tr>
				</table>			
					
					
					
			</form>
			
		</fieldset>
		</div>
	</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	

</div><!-- #global -->

</body>
</html>
