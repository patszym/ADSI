<?php

// Ouverture Campagne Cycle :
						
							if ($datePrevOuvCampagnecycle != null)
							{
							$dt = new DateTime($datePrevOuvCampagnecycle, new DateTimeZone('Europe/Paris'));
						
							$dtsPrevOuv =($dt->getTimestamp());
							}
							else 
							{
								$dtsPrevOuv = null;
							}
							
							if ($dateEffOuvCampagnecycle != null)
							{
								$dt = new DateTime($dateEffOuvCampagnecycle, new DateTimeZone('Europe/Paris'));
							
								$dtsEffOuv =($dt->getTimestamp());
							}
							else
							{
								$dtsEffOuv = null;
							}
							
							$differenceOuv = $todayTimeStamp - $dtsPrevOuv ;
							
							if ((($differenceOuv > 0)and ($dtsPrevOuv != null))  and ($dtsEffOuv == null)) 
								
							{
            					echo "<br></br>".$nomAppli." Campagnes ".$libelleCourtCycle.": date prévisionnelle d'ouverture ".$datePrevOuvCampagnecycle." inférieure à aujourd'hui";
            					echo "  et date effective d'ouverture nulle ";
						
            				
            				$feu_Rouge = 
            				'<td>
							<a href="edCC.php">
							<img src="images/feuRouge.jpg" height="20" width="20" align = "center" 
							>
							
							</a>
				
							</td>';
            				
							echo $feu_Rouge;
						
							}
							
	// Fermeture Campagne Cycle :
							
							if ($datePrevFerCampagnecycle != null)
							{
								$dt = new DateTime($datePrevFerCampagnecycle, new DateTimeZone('Europe/Paris'));
							
								$dtsPrevFer =($dt->getTimestamp());
							}
							else
							{
								$dtsPrevFer = null;
							}
								
							if ($dateEffFerCampagnecycle != null)
							{
								$dt = new DateTime($dateEffFerCampagnecycle, new DateTimeZone('Europe/Paris'));
									
								$dtsEffFer =($dt->getTimestamp());
							}
							else
							{
								$dtsEffFer = null;
							}
								
							$differenceFer = $todayTimeStamp - $dtsPrevFer ;
								
							if ((($differenceFer > 0)and ($dtsPrevFer != null)) and ($dtsEffFer == null))
							
							{
								echo "<br></br>".$nomAppli." Campagnes ".$libelleCourtCycle.": date prévisionnelle de fermeture ".$datePrevFerCampagnecycle." inférieure à aujourd'hui";
								echo "  et date effective de fermeture nulle ";
							
							
								$feu_Rouge =
								'<td>
							<a href="edCC.php">
							<img src="images/feuRouge.jpg" height="20" width="20" align = "center"
							>
				
							</a>
							
							</td>';
							
								echo $feu_Rouge;
							
							}
							
							
		// Fin Campagne Cycle :
								
							if ($datePrevFinCampagnecycle != null)
							{
								$dt = new DateTime($datePrevFinCampagnecycle, new DateTimeZone('Europe/Paris'));
									
								$dtsPrevFin =($dt->getTimestamp());
							}
							else
							{
								$dtsPrevFin = null;
							}
							
							if ($dateEffFinCampagnecycle != null)
							{
								$dt = new DateTime($dateEffFinCampagnecycle, new DateTimeZone('Europe/Paris'));
									
								$dtsEffFin =($dt->getTimestamp());
							}
							else
							{
								$dtsEffFin = null;
							}
							
							$differenceFin = $todayTimeStamp - $dtsPrevFin ;
							
							if ((($differenceFin > 0)and ($dtsPrevFin != null)) and ($dtsEffFin == null))
								
							{
								echo "<br></br>".$nomAppli." Campagnes ".$libelleCourtCycle.": date prévisionnelle de fin ".$datePrevFinCampagnecycle." inférieure à aujourd'hui";
								echo "  et date effective de fin nulle ";
									
									
								$feu_Rouge =
								'<td>
							<a href="edCC.php">
							<img src="images/feuRouge.jpg" height="20" width="20" align = "center"
							>
							
							</a>
				
							</td>';
									
								echo $feu_Rouge;
									
							}
							$differenceEffFin = $todayTimeStamp - $dtsEffFin ;
							
							if (($differenceEffFin > 0)and ($dtsEffFin != null))
								
							{
							
								$panneau_stop =
								'<td>
				
							<img src="images/arreter.png" height="20" width="20" align = "center"
							>
							
				
				
							</td>';
									
								echo $panneau_stop;
									
							}
							$differencePrevFin = $todayTimeStamp - $dtsPrevFin ;
							$differenceEffOuv = $todayTimeStamp - $dtsEffOuv ;
							
							if ((($differenceEffOuv > 0)and ($dtsEffOuv != null))
										
							
										
									and(($differencePrevFin < 0)and ($dtsPrevFin != null)))
							
							{
									
								$sunburst =
								'<td>
							
							<img src="images/Sunburst.jpg" height="20" width="20" align = "center"
							>
				
							
							
							</td>';
									
								echo $sunburst;
									
							}
?>