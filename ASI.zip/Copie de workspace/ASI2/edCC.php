<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Campagnecycle
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation2.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> A l'appel du menu général, le mode <b> Liste et Edition</b> est le mode par défaut</p>
			<p> Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence Campagnecycle. Les fichiers associés 
			sont mémorisés en binaires dans la base de données</p>
			<p> Cliquez sur l'image de l'oeil pour voir le détail de la ligne spécifiée en consultation dans la liste. </p>
			<p> Cliquez sur l'image du crayon pour voir le détail de la ligne spécifiée en modification dans la liste. </p>
			<p> Cliquez sur l'image de la croix pour voir le détail de la ligne spécifiée en suppression dans la liste</p>
			<p>Cliquez sur l'icône <b>PDF</b> pour voir le détail de la ligne en obtenant son édition PDF </p>
			
			<p>Cliquez sur l'icône <b>PDF</b> à gauche du titre pour obtenir l'édition PDF de la liste</p>
			
	</div><!-- #secondaire -->
		
	<div id="principal"> 
			<h5>Gestion des campagnes par cycles </h5>
			
		
			<div id="tabsF">
				<?php include('include/MHCC.php'); 
					session_start();
				$ses_id = session_id();
				?> 
									
			</div>
		
		<fieldset class="saisie">
			<table BORDER=0>
			
			<tr>
			
				<td>
				<a href="editions/edCCPDF.php">
				<img src="images/pdficon.jpg" height="20" width="20" align = "center" 
				alt="PDF">
				</a>
				
				</td>
				<td></td>
				<td>
				<h3>  LISTE DES CAMPAGNES PAR CYCLE </h3>
				</td>
			</tr>
				
				<?php 
				include('include/con2log.php');
	
				$sql = 'select idCAMPAGNE, idCAMPAGNECYCLE, 
					 datePrevOuvCAMPAGNECYCLE, dateEffOuvCAMPAGNECYCLE,
					datePrevFerCAMPAGNECYCLE, dateEffFerCAMPAGNECYCLE,
					datePrevFinCAMPAGNECYCLE, dateEffFinCAMPAGNECYCLE,
					libelleCourtCYCLE, libelleCAMPAGNE, idAppli, nomAPPLI
					
					from CAMPAGNECYCLE, CAMPAGNE, APPLI, CYCLE';
				if (isset ($adm))
				
				{
					if ($adm == 0)
					{
						$sql=$sql.' , APPLI_has_UTI';
						
							
					}
				}
				
					$sql=$sql.' where CAMPAGNE.APPLI_idAPPLI = APPLI.idAPPLI
					and CAMPAGNECYCLE.CAMPAGNE_idCAMPAGNE = CAMPAGNE.idCAMPAGNE
					and CAMPAGNECYCLE.CYCLE_idCYCLE = CYCLE.idCYCLE';
				if (isset ($adm))
						
				{
					if ($adm == 0)
					{
								
						$sql=$sql.' AND APPLI.idAPPLI = APPLI_has_UTI.APPLI_idAPPLI';
						$sql=$sql.' AND APPLI_has_UTI.UTI_idUTI = :idUti';
					}
				}
					$sql=$sql.' order by nomAPPLI, libelleCAMPAGNE, libelleCourtCYCLE, datePrevOuvCAMPAGNECYCLE';
					$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
					if (isset ($adm))
						
					{
						if ($adm == 0)
						{
								
							$query->bindParam(':idUti', $idUti, PDO::PARAM_INT);
						}
					}
			
				include_once "include/visuConvCC.php";
				
				$i = 0 ;
				$idRowCampagne = null;
				$idCampagnecycle = null ;
				
				$datePrevOuvCampagnecycle =  null;
				$dateEffOuvCampagnecycle = null;
				$datePrevFerCampagnecycle =  null;
				$dateEffFerCampagnecycle = null;
				$datePrevFinCampagnecycle =  null;
				$dateEffFinCampagnecycle = null;
				$libelleCourtCycle = null ;
				$libelleCampagne =  null ;
				$idAppli = null;
				$nomAppli = null;
				
			
				
				
				while ($i<$maxRow)
				{
					$idRowCampagne =  $tableau [$i][0] ;
					$idCampagnecycle =  $tableau [$i][1] ;
					$datePrevOuvCampagnecycle=  $tableau [$i][2] ;
					$dateEffOuvCampagnecycle =  $tableau [$i][3] ;
					$datePrevFerCampagnecycle =  $tableau [$i] [4];
					$dateEffFerCampagnecycle =  $tableau [$i] [5];
					$datePrevFinCampagnecycle =  $tableau [$i] [6];
					$dateEffFinCampagnecycle  = $tableau [$i] [7];
					$libelleCourtCycle  = $tableau [$i] [8];
					$libelleCampagne  = $tableau [$i] [9];
					$idAppli   = $tableau [$i] [10];
					$nomAppli   = $tableau [$i] [11];
					
					
					$i++;
					/* Exploitation des lignes dans la liste */
					?>
					
					<?php include "include/convDatesCC.php" ;?> 				
				
				<!-- Liste des  Campagnecycles - formulaire en lecture -->
									
									
						
							<input type="hidden" name="idCampagnecycle"
							value="<?php echo htmlspecialchars($idCampagnecycle); ?>"
							maxlength="3" size="3" ></input>
					
					<tr>
						<td>								
							<input type="text" name="libelleCourtCycle" 
								value="<?php echo htmlspecialchars($libelleCourtCycle); ?>" 
								maxlength="10" size="10" readonly></input>
						</td>
						
						<td>
							<input type="text" name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="10" readonly></input>
						</td>
						<td>
							<input type="text" name="libelleCampagne" 
							value="<?php echo htmlspecialchars($libelleCampagne); ?>" 
							maxlength="100" size="50" readonly></input>
						</td>
					
						<td>
							<form action="consCC.php" method="post">

			 					<input type="hidden" name="idCampagnecycle" 
			 					value="<?php echo htmlspecialchars($idCampagnecycle); ?>">
			 					</input>
			 					<input type="hidden" name="idAppli" 
			 					value="<?php echo htmlspecialchars($idAppli); ?>">
			 					</input>
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form> 
						</td>
						<td>
							<form action="modifCC.php" method="post">

			 					<input type="hidden" name="idCampagnecycle" 
			 					value="<?php echo htmlspecialchars($idCampagnecycle); ?>">
			 					</input>
			 					<input type="hidden" name="idAppli" 
			 					value="<?php echo htmlspecialchars($idAppli); ?>">
			 					</input>
								<input border=0 src="images/crayon.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form>
						</td>
							<td> 
							<form action="supprCC.php" method="post">

			 					<input type="hidden" name="idCampagnecycle" 
			 					value="<?php echo htmlspecialchars($idCampagnecycle); ?>">
			 					</input>
			 					<input type="hidden" name="idAppli" 
			 					value="<?php echo htmlspecialchars($idAppli); ?>">
			 					</input>
								<input border=0 src="images/button-cancel.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form>
						</td> 
						<td> 					
							
							<form action="editions/edElCCPDF.php" method="post">
							
								<input type="hidden" name="nomAppli" 
								value="<?php echo htmlspecialchars($nomAppli); ?>">
								</input>
			 					
			 					<input type="hidden" name="libelleCampagne" 
								value="<?php echo htmlspecialchars($libelleCampagne); ?>">
								</input>
			 					<input type="hidden" name="idCampagnecycle" 
								value="<?php echo htmlspecialchars($idCampagnecycle); ?>">
								</input>
			 				
								<input type="hidden" name="libelleCourtCycle" 
								value="<?php echo htmlspecialchars($libelleCourtCycle); ?>">
								</input>
								<input type="hidden" name="dPrevOuvCampagnecycle" 
								value="<?php echo htmlspecialchars($dPrevOuvCampagnecycle); ?>">
								</input>
								<input type="hidden" name="HPrevOuvCampagnecycle" 
								value="<?php echo htmlspecialchars($HPrevOuvCampagnecycle); ?>">
								</input>
								
								<input type="hidden" name="iPrevOuvCampagnecycle" 
								value="<?php echo htmlspecialchars($iPrevOuvCampagnecycle); ?>">
								</input>
								
								<input type="hidden" name="dEffOuvCampagnecycle" 
								value="<?php echo htmlspecialchars($dEffOuvCampagnecycle); ?>">
								</input>
							
								<input type="hidden" name="HEffOuvCampagnecycle" 
								value="<?php echo htmlspecialchars($HEffOuvCampagnecycle); ?>">
								</input>
								
								<input type="hidden" name="iEffOuvCampagnecycle" 
								value="<?php echo htmlspecialchars($iEffOuvCampagnecycle); ?>">
								</input>
								
								<input type="hidden" name="dPrevFerCampagnecycle" 
								value="<?php echo htmlspecialchars($dPrevFerCampagnecycle); ?>">
								</input>
							
								<input type="hidden" name="HPrevFerCampagnecycle" 
								value="<?php echo htmlspecialchars($HPrevFerCampagnecycle); ?>">
								</input>
								<input type="hidden" name="iPrevFerCampagnecycle" 
								value="<?php echo htmlspecialchars($iPrevFerCampagnecycle); ?>">
								</input>
								
								<input type="hidden" name="dEffFerCampagnecycle" 
								value="<?php echo htmlspecialchars($dEffFerCampagnecycle); ?>">
								</input>
							
								<input type="hidden" name="HEffFerCampagnecycle" 
								value="<?php echo htmlspecialchars($HEffFerCampagnecycle); ?>">
								</input>
								
								<input type="hidden" name="iEffFerCampagnecycle" 
								value="<?php echo htmlspecialchars($iEffFerCampagnecycle); ?>">
								</input>
								
								<input type="hidden" name="dPrevFinCampagnecycle" 
								value="<?php echo htmlspecialchars($dPrevFinCampagnecycle); ?>">
								</input>
							
								<input type="hidden" name="HPrevFinCampagnecycle" 
								value="<?php echo htmlspecialchars($HPrevFinCampagnecycle); ?>">
								</input>
								<input type="hidden" name="iPrevFinCampagnecycle" 
								value="<?php echo htmlspecialchars($iPrevFinCampagnecycle); ?>">
								</input>
								
								<input type="hidden" name="dEffFinCampagnecycle" 
								value="<?php echo htmlspecialchars($dEffFinCampagnecycle); ?>">
								</input>
							
								<input type="hidden" name="HEffFinCampagnecycle" 
								value="<?php echo htmlspecialchars($HEffFinCampagnecycle); ?>">
								</input>
								
								<input type="hidden" name="iEffFinCampagnecycle" 
								value="<?php echo htmlspecialchars($iEffFinCampagnecycle); ?>">
								</input>
														
			 					<input border=0 src="images/pdficon.jpg" 
								type=image value=submit name = "soumet" align="left" 
								height="20" width="20">
								</input>

										
							</form>
						</td> 
											
					</tr>			
										
							
				<?php 
				}
				$query = null;
				?>
			</table>
		</fieldset>

		</div> <!-- principal-->
	
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
