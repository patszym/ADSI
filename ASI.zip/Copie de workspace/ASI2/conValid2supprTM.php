<?php	
			  
if(!empty($_POST["soumet"]))
{
					$idTraitmaj = null;
					
					
					if(!empty($_POST["idTraitmaj"]))
					{
						$idTraitmaj=$_POST["idTraitmaj"];
					} 
					
					include('include/connBase.php');
					
					// Contrôles de cohérence de la base pour les clés étrangères déclarées dans les autres tables
					// à la suppression. Normalement c'est fait des triggers (sous Oracle), mais pas sur Mysql
					// donc la cohérence de la base est assurée au niveau de la programmation
					// ---> clé étrangère de TRAITMAJ dans la table APPLI
					
					$validBase = true;
					
				
				if ($validBase)
				{
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					
						$sql = 'DELETE FROM TRAITMAJ WHERE idTRAITMAJ = :idTraitmaj ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idTraitmaj', $idTraitmaj, PDO::PARAM_INT);
					
						$sth->execute();
					
						echo "Validation de la suppression faite";
				
					} catch (Exception $e) {
					
						echo "la suppression a échouée: " . $e->getMessage();
					}
				}
}
			
				
			?>	