<?php	
			  
if(!empty($_POST["soumet"]))
{
					$idCampagne = null;
					
					
					if(!empty($_POST["idCampagne"]))
					{
						$idCampagne=$_POST["idCampagne"];
					} 
					
					include('include/connBase.php');
					
					// Contrôles de cohérence de la base pour les clés étrangères déclarées dans les autres tables
					// à la suppression. Normalement c'est fait des triggers (sous Oracle), mais pas sur Mysql
					// donc la cohérence de la base est assurée au niveau de la programmation
					// ---> clé étrangère de CAMPAGNE dans la table APPLI
					
					
					$validBase = true;
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM PROCESSUS WHERE CAMPAGNE_idCAMPAGNE = :idCampagne ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idCampagne', $idCampagne, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
							
					
							
					
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table PROCESSUS utilise(nt) cette réference CAMPAGNE <br>";
						echo " Remède : Revenez par le menu principal au choix de l'option 'PROCESSUS'";
						echo "Puis supprimez le lien ";
						?>
																<script language="javascript">
																alert("La suppression est impossible car il y a une référence dans la table processus exploitant cette occurence de campagne");
																</script>
					<?php
					}
					
					$nbOccur = 0;
					try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
												
					$sql = 'SELECT COUNT(*) FROM CAMPAGNESCYCLE WHERE CAMPAGNE_idCAMPAGNE = :idCampagne ';
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idCampagne', $idCampagne, PDO::PARAM_INT);
					$sth->execute();
					$nbOccur = $sth->fetchColumn();
												
												
												
												
												
					} catch (Exception $e) {
												
					echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
					$validBase = false;
					echo $nbOccur. " occurence(s) dans la table CAMPAGNESCYCLE utilise(nt) cette réference CAMPAGNE <br>";
					echo " Remède : Revenez par le menu principal au choix de l'option 'CAMPAGNES PAR CYCLES'";
					echo "Puis supprimez le lien ";
					?>
															<script language="javascript">
															alert("La suppression est impossible car il y a une référence dans la table processus exploitant cette occurence de campagne");
															</script>
					<?php
					}
														
				if ($validBase)
				{
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					
						$sql = 'DELETE FROM CAMPAGNE WHERE idCAMPAGNE = :idCampagne ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idCampagne', $idCampagne, PDO::PARAM_INT);
					
						$sth->execute();
					
						echo "Validation de la suppression faite";
				
					} catch (Exception $e) {
					
						echo "la suppression a échouée: " . $e->getMessage();
					}
				}
}
			
				
			?>	