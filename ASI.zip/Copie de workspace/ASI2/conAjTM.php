<?php	
	  
				
					$idTraitmaj = null;
					
					if(!empty($_POST["idAppli"]))
					{
						$idAppli=$_POST["idAppli"];
					} else
					{
						$idAppli = null;
					}
						
					if(!empty($_POST["nomTraitmaj"]))
					{
						$nomTraitmaj=$_POST["nomTraitmaj"];
					} else 
					{ 
						$nomTraitmaj = null;
					}
					
										
					
					
					if(!empty($_POST["libelleTraitmaj"]))						
					{
						$libelleTraitmaj=$_POST["libelleTraitmaj"];
					} else
					{
						$libelleTraitmaj = null;
					}
				
					if(!empty($_POST["servTraitmaj"]))
					{
						$servTraitmaj=$_POST["servTraitmaj"];
					} else
					{
						$servTraitmaj = null;
					}
					
					
					if(!empty($_POST["chemTraitmaj"]))
					{
						$chemTraitmaj=$_POST["chemTraitmaj"];
					} else
					{
						$chemTraitmaj = null;
					}
					
					
					if(!empty($_POST["nomprogTraitmaj"]))
					{
						$nomprogTraitmaj=$_POST["nomprogTraitmaj"];
					} else
					{
						$nomprogTraitmaj = null;
					}
					
					if(!empty($_POST["locCompRendTraitmaj"]))
					{
						$locCompRendTraitmaj=$_POST["locCompRendTraitmaj"];
					} else
					{
						$locCompRendTraitmaj = null;
					}
						
					
						// initialisation des attibuts en ajout de table TRAITMAJ
						
						$crdTraitmaj = null;
						$mimecrdTraitmaj = null;
						$sizecrdTraitmaj = null;
						$filenamecrdTraitmaj = null;
						$extensioncrdTraitmaj = null;
						
						
						include('include/tailleMaxi.php');
						$content_blob = null;
						$mime_type = null;
						$fic_taille = 0;
						$content_nom = null;
						if(!empty($_FILES["crdFormTraitmaj"]))
						{
							if ($_FILES["crdFormTraitmaj"]["error"] > 0)
							{
								echo "Erreur Return Code: " . $_FILES["crdFormTraitmaj"]["error"] . "<br />";
							}
							else
							{
							
								if(!empty($_FILES['crdFormTraitmaj']['tmp_name']))
									{
						
									echo $_FILES['crdFormTraitmaj']['tmp_name'];
								
									$content_temp_nom = $_FILES['crdFormTraitmaj']['tmp_name'];
									$nom_fichier_origine = $_FILES['crdFormTraitmaj']['name'];
									
									$ret = is_uploaded_file ($_FILES['crdFormTraitmaj']['tmp_name']);
									if ( !$ret )
									{
										echo "Problème de transfert";
										return false;
									}
									else
									{
										$nom_fichier_origine = $_FILES['crdFormTraitmaj']['name'];
									// Le fichier a bien été reçu
										$fic_taille = $_FILES['crdFormTraitmaj']['size'];
										if ( $fic_taille > $taille_max )
										{
											echo "Fichier téléchargé trop important - taille maxi dépassée !";
											return false;
										}
									
										$mime_type = $_FILES['crdFormTraitmaj']['type'];
								
									
									
										$fp = fopen ($content_temp_nom, "rb");
									
										$content_blob = fread($fp, $fic_taille);
										fclose ($fp);
										$crdTraitmaj = addslashes($content_blob);
									
										$sizecrdTraitmaj = $fic_taille;
										$mimecrdTraitmaj = $mime_type;
									
										$path_parts = pathinfo($nom_fichier_origine);
									
									// echo $path_parts['dirname'], "\n";
									// echo $path_parts['basename'], "\n";
										$extensioncrdTraitmaj = $path_parts['extension'];
										$filenamecrdTraitmaj = $path_parts['filename']; // depuis PHP 5.2.0
									
									
									
									
									}
								}
								
							}
						}
						
						
		/* Mise à jour :
		 * 
		 */
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idTRAITMAJ) FROM TRAITMAJ ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idTraitmaj = $gid->fetchColumn();
					
					
					
					$idTraitmaj ++ ;
					
					
					$sql = 'insert into TRAITMAJ values ("'.$idTraitmaj.'",'.
							'"'.$idAppli.'","'.
							$nomTraitmaj.'","'.
							$libelleTraitmaj.'","'.
							$servTraitmaj.'","'.
							$chemTraitmaj.'","'.
							$nomprogTraitmaj.'","'.
							$locCompRendTraitmaj.'",';
					
					if(!empty($crdTraitmaj))
					{
						
						$sql = $sql .'"'.$crdTraitmaj.'","'.
								$mimecrdTraitmaj.'",'.
								$sizecrdTraitmaj.',"'.
								$filenamecrdTraitmaj.'","'.
								$extensioncrdTraitmaj.'"';
							
						
					}
					else
					{
						$sql = $sql .'null, null, null, null, null';
					}
							
							
					$sql = $sql .');'   ;
					// echo $sql;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
			?>	