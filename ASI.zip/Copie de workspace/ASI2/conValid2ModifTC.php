<?php	
include_once('include/ConversionDates.class.php');
if(!empty($_POST["soumet"]))
{

					$idTachecycle = $_POST["idTachecycle"];
					

					if(!empty($_POST["idTache"]))
					{
						$idTache=$_POST["idTache"];
					
					} else
					{
						$idTache = null;
						
					}

					if(!empty($_POST["idCycle"]))
					{
						$idCycle=$_POST["idCycle"];
						
						
					} else
					{
						$idCycle = null;
						
					}
					
				
							


					$dateversRowPrevOuvTachecycle  = null;
					$validdatePrevOuvTachecycle = true;
					
					if (!empty($_POST["datePrevOuvTachecycle"]))
					{
							
							
						$conversionDate1 = new ConversionDates();
						$conversionDate1->setdt($_POST['datePrevOuvTachecycle']);
						if (isset($_POST['HPrevOuvTachecycle']))
						{
							$H = $_POST['HPrevOuvTachecycle'];
								
							if (($H>24) or ($H<00))
							{
								echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
									
								$H = "00";
							}
						}
						else
						{
							$H = "00";
						}
							
							
						$conversionDate1->setH($H);
							
							
						if (isset($_POST['iPrevOuvTachecycle']))
						{
							$i = $_POST['iPrevOuvTachecycle'];
							if (($i>60) or ($i<00))
							{
								echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
								$i = "00";
							}
						}
						else
						{
							$i = "00";
						}
							
						$conversionDate1->seti($i);
							
							
						$conversionDate1->convdDate();
							
							
						$dateversRowPrevOuvTachecycle = $conversionDate1->getdate() ;
							
						if (!checkdate($conversionDate1->getm(), $conversionDate1->getd(), $conversionDate1->getY()))
						{
								
							$validdatePrevOuvTachecycle = false;
							echo $datePrevOuvTachecycle. " n'est pas une date et une heure valide <br>";
							?>
																		<script language="javascript">
																		alert("Date  non conforme au format d'une date");
																		</script>
																		<?php
																}
															} 
															else
															{
																	$dateversRowPrevOuvTachecycle  = null;
																	
															}
														
										
															$dateversRowEffOuvTachecycle  = null;
															$validdateEffOuvTachecycle = true;
																
															if (!empty($_POST["dateEffOuvTachecycle"])) 
															{
																	
																	
																$conversionDate2 = new ConversionDates();
																$conversionDate2->setdt($_POST['dateEffOuvTachecycle']);
																if (isset($_POST['HEffOuvTachecycle']))
																{
																	$H = $_POST['HEffOuvTachecycle'];
															
																	if (($H>24) or ($H<00))
																	{
																		echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
																		
																		$H = "00";
																	}
																}
																else
																{
																	$H = "00";
																}
															
																$conversionDate2->setH($H);
																if (isset($_POST['iEffOuvTachecycle']))
																{
																	$i = $_POST['iEffOuvTachecycle'];
																	if (($i>60) or ($i<00))
																	{
																		echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
																		$i = "00";
																	}
																}
																else
																{
																	$i = "00";
																}
																
															
																$conversionDate2->seti($i);
															
															
																$conversionDate2->convdDate();
															
															
																$dateversRowEffOuvTachecycle = $conversionDate2->getdate() ;
															
																if (!checkdate($conversionDate2->getm(), $conversionDate2->getd(), $conversionDate2->getY()))
																{
															
																	$validdateEffOuvTachecycle = false;
																	echo $dateEffOuvTachecycle. " n'est pas une date et une heure valide <br>";
																	?>
																							<script language="javascript">
																							alert("Date  non conforme au format d'une date");
																							</script>
																	<?php
																}
															} 
															else
															{
																$dateversRowEffOuvTachecycle  = null;
																						
															}
																			
																						
																// date de fermeture :
										
															$dateversRowPrevFerTachecycle  = null;
															$validdatePrevFerTachecycle = true;
																					
															if (!empty($_POST["datePrevFerTachecycle"])) 
															{
																						
																						
																$conversionDate3 = new ConversionDates();
																$conversionDate3->setdt($_POST['datePrevFerTachecycle']);
																if (isset($_POST['HPrevFerTachecycle']))
																{
																	$H = $_POST['HPrevFerTachecycle'];
																				
																	if (($H>24) or ($H<00))
																	{
																		echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
																							
																		$H = "00";
																	}
																}
																else
																{
																	$H = "00";
																}				
																$conversionDate3->setH($H);
																if (isset($_POST['iPrevFerTachecycle']))
																{				
																	$i = $_POST['iPrevFerTachecycle'];
																	if (($i>60) or ($i<00))
																	{
																		echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
																		$i = "00";
																	}
																}
																else
																{
																	$i = "00";
																}
																				
																$conversionDate3->seti($i);
																				
																				
																$conversionDate3->convdDate();
																				
																				
																$dateversRowPrevFerTachecycle = $conversionDate3->getdate() ;
																				
																if (!checkdate($conversionDate3->getm(), $conversionDate3->getd(), $conversionDate3->getY()))
																{
																				
																	$validdatePrevFerTachecycle = false;
																	echo $datePrevFerTachecycle. " n'est pas une date et une heure valide <br>";
																	?>
																			<script language="javascript">
																		alert("Date  non conforme au format d'une date");
																		</script>
																	<?php
																}
															} 
															else
															{
																$dateversRowPrevFerTachecycle  = null;
																											
															}
																								
																				
															$dateversRowEffFerTachecycle  = null;
															$validdateEffFerTachecycle = true;
																										
															if (!empty($_POST["dateEffFerTachecycle"])) 
															{
																											
																											
																$conversionDate4 = new ConversionDates();
																$conversionDate4->setdt($_POST['dateEffFerTachecycle']);
																
																if (isset($_POST['HEffFerTachecycle']))
																{
																	$H = $_POST['HEffFerTachecycle'];
																									
																	if (($H>24) or ($H<00))
																	{
																		echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
																												
																		$H = "00";
																	}
																}
																else
																{
																	$H = "00";
																}
																									
																$conversionDate4->setH($H);
																if (isset($_POST['iEffFerTachecycle']))
																{
																									
																	$i = $_POST['iEffFerTachecycle'];
																	if (($i>60) or ($i<00))
																	{
																		echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
																		$i = "00";
																	}
																}
																else
																{
																	$i = "00";
																}
																									
																$conversionDate4->seti($i);
																									
																									
																$conversionDate4->convdDate();
																									
																									
																$dateversRowEffFerTachecycle = $conversionDate4->getdate() ;
																									
																if (!checkdate($conversionDate4->getm(), $conversionDate4->getd(), $conversionDate4->getY()))
																{
																									
																											$validdateEffFerTachecycle = false;
																											echo $dateEffFerTachecycle. " n'est pas une date et une heure valide <br>";
																	?>
																																	<script language="javascript">
																																	alert("Date  non conforme au format d'une date");
																																	</script>
																	<?php
																}
															} 
															else
															{
																$dateversRowEffFerTachecycle  = null;
																																
															}
																													
																																
																			// date de fin :
										
														$dateversRowPrevFinTachecycle  = null;
														$validdatePrevFinTachecycle = true;
																															
														if (!empty($_POST["datePrevFinTachecycle"])) 
														{
																																
																																
															$conversionDate5 = new ConversionDates();
															$conversionDate5->setdt($_POST['datePrevFinTachecycle']);
															if (isset($_POST['HPrevFinTachecycle']))
															{
																$H = $_POST['HPrevFinTachecycle'];
																														
																if (($H>24) or ($H<00))
																{
																	echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
																																	
																	$H = "00";
																}
															}
															else
															{
																$H = "00";
															}
															
																														
															$conversionDate5->setH($H);
															if (isset($_POST['iPrevFinTachecycle']))
															{															
																$i = $_POST['iPrevFinTachecycle'];
																if (($i>60) or ($i<00))
																{
																	echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
																	$i = "00";
																}
															}
															else
															{
																$i = "00";
															}	
																														
															$conversionDate5->seti($i);
																														
																														
															$conversionDate5->convdDate();
																														
																														
															$dateversRowPrevFinTachecycle = $conversionDate5->getdate() ;
																														
															if (!checkdate($conversionDate5->getm(), $conversionDate5->getd(), $conversionDate5->getY()))
															{
																														
																$validdatePrevFinTachecycle = false;
																echo $datePrevFinTachecycle. " n'est pas une date et une heure valide <br>";
																?>
																																						<script language="javascript">
																																						alert("Date  non conforme au format d'une date");													</script>
																<?php
															}
														} 
														else
														{
															$dateversRowPrevFinTachecycle  = null;
																																					
														}
																																		
																														
														$dateversRowEffFinTachecycle  = null;
														$validdateEffFinTachecycle = true;
																																				
														if (!empty($_POST["dateEffFinTachecycle"])) 
														{
																																					
																																					
															$conversionDate6 = new ConversionDates();
															$conversionDate6->setdt($_POST['dateEffFinTachecycle']);
															if (isset($_POST['HEffFinTachecycle']))
															{
																$H = $_POST['HEffFinTachecycle'];
																																			
																if (($H>24) or ($H<00))
																{
																	echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
																																						
																	$H = "00";
																}
															}
															else
															{
																$H = "00";
															}
																																			
															$conversionDate6->setH($H);
															if (isset($_POST['iEffFinTachecycle']))
															{																				
																$i = $_POST['iEffFinTachecycle'];
																if (($i>60) or ($i<00))
																{
																	echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
																	$i = "00";
																}
															}
															else 
															{
																$i = "00";
															}
																
																																			
															$conversionDate6->seti($i);
																																			
																																			
															$conversionDate6->convdDate();
																																			
																																			
															$dateversRowEffFinTachecycle = $conversionDate6->getdate() ;
																																			
															if (!checkdate($conversionDate6->getm(), $conversionDate6->getd(), $conversionDate6->getY()))
															{
																																			
																$validdateEffFinTachecycle = false;
																echo $dateEffFinTachecycle. " n'est pas une date et une heure valide <br>";
																?>
																																											<script language="javascript">
																																											alert("Date  non conforme au format d'une date");
																																											</script>
																<?php
															}
														} 
														else
														{
															$dateversRowEffFinTachecycle  = null;
																																										
														}
																																							
																																										
																													
				// initialisation des attibuts en modification de la table PROJET
					
				$contenuCompRendTachecycle = null;
				$mimeCompRendTachecycle = null;
				$sizeCompRendTachecycle = null;
				$filenameCompRendTachecycle = null;
				$extensionCompRendTachecycle = null;
				
				include('include/tailleMaxi.php');
				$content_blob = null;
				$mime_type = null;
				$fic_taille = 0;
				$content_nom = null;
					
				if(!empty($_FILES["CompRendFormTachecycle"]))
				{
					if ($_FILES["CompRendFormTachecycle"]["error"] > 0)
					{
						echo "Erreur Return Code: " . $_FILES["CompRendFormTachecycle"]["error"] . "<br />";
					}
					else
					{
				
						if(!empty($_FILES['CompRendFormTachecycle']['tmp_name']))
						{
								
							echo $_FILES['CompRendFormTachecycle']['tmp_name'];
								
							$content_temp_nom = $_FILES['CompRendFormTachecycle']['tmp_name'];
							$nom_fichier_origine = $_FILES['CompRendFormTachecycle']['name'];
								
							$ret = is_uploaded_file ($_FILES['CompRendFormTachecycle']['tmp_name']);
							if ( !$ret )
							{
								echo "Problème de transfert";
								return false;
							}
							else
							{
								$nom_fichier_origine = $_FILES['CompRendFormTachecycle']['name'];
								
								// Le fichier a bien été reçu
								$fic_taille = $_FILES['CompRendFormTachecycle']['size'];
								if ( $fic_taille > $taille_max )
								{
									echo "Fichier téléchargé trop important - taille maxi dépassée !";
									return false;
								}
				
								$mime_type = $_FILES['CompRendFormTachecycle']['type'];
									
				
				
								$fp = fopen ($content_temp_nom, "rb");
				
								$content_blob = fread($fp, $fic_taille);
								fclose ($fp);
								$CompRendTachecycle = addslashes($content_blob);
				
								$sizeCompRendTachecycle = $fic_taille;
								$mimeCompRendTachecycle = $mime_type;
				
								$path_parts = pathinfo($nom_fichier_origine);
				
								// echo $path_parts['dirname'], "\n";
								// echo $path_parts['basename'], "\n";
								$extensionCompRendTachecycle = $path_parts['extension'];
								$filenameCompRendTachecycle = $path_parts['filename']; // depuis PHP 5.2.0
								
				
				
				
							}
						}
							
					}
				}																													
			$validBase = True;
			include('include/connBase.php');
								
			if ($validBase)
			{
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE TACHECYCLE SET '.
							' CYCLE_idCYCLE ="'.$idCycle.'",'.
							' TACHE_idTACHE ="'.$idTache.'"';
							
					
					if(!empty($_POST["datePrevOuvTachecycle"]))
					{
					$sql = $sql.', datePrevOuvTACHECYCLE ="'.$dateversRowPrevOuvTachecycle.'"';
					}
					else
					{
						$sql = $sql.', datePrevOuvTACHECYCLE = null';
					}
					
					
					if(!empty($_POST["dateEffOuvTachecycle"]))
					{
						$sql = $sql.', dateEffOuvTACHECYCLE ="'.$dateversRowEffOuvTachecycle.'"';
					}
					else 
					{ 
						$sql = $sql.', dateEffOuvTACHECYCLE = null';
					}
				
					
					if(!empty($_POST["datePrevFerTachecycle"]))
					{
						$sql = $sql.', datePrevFerTACHECYCLE ="'.$dateversRowPrevFerTachecycle.'"';
					}
					else
					{
						$sql = $sql.', datePrevFerTACHECYCLE = null';
					}	

					if(!empty($_POST["dateEffFerTachecycle"]))
					{
						$sql = $sql.', dateEffFerTACHECYCLE ="'.$dateversRowEffFerTachecycle.'"';
					}
					else
					{
						$sql = $sql.', dateEffFerTACHECYCLE = null';
					}
						
					if(!empty($_POST["datePrevFinTachecycle"]))
					{
						$sql = $sql.', datePrevFinTACHECYCLE ="'.$dateversRowPrevFinTachecycle.'"';
					}
					else
					{
						$sql = $sql.', datePrevFinTACHECYCLE = null';
					}
							
					
					if(!empty($_POST["dateEffFinTachecycle"]))
					{
						$sql = $sql.', dateEffFinTACHECYCLE ="'.$dateversRowEffFinTachecycle.'"';
					}
					else
					{
						$sql = $sql.', dateEffFinTACHECYCLE = null';
					}
					
					
					
					if(!empty($CompRendTachecycle))
					{
							
						$sql = $sql .','.' contenuCompRendTACHECYCLE ="'.$CompRendTachecycle.'",';
						$sql = $sql .' mimeCompRendTACHECYCLE ="'.$mimeCompRendTachecycle.'",';
						$sql = $sql .' sizeCompRendTACHECYCLE ='.$sizeCompRendTachecycle.',';
						$sql = $sql .' filenameCompRendTACHECYCLE ="'.$filenameCompRendTachecycle.'",';
						$sql = $sql .' extensionCompRendTACHECYCLE ="'.$extensionCompRendTachecycle.'"';
							
							
					}
					
				
					
					
					$sql = $sql.' WHERE idTACHECYCLE = :idTachecycle ';
					
					// echo $sql;
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idTachecycle', $idTachecycle, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			}
			
}
				
			?>	