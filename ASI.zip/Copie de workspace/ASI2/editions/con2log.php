<?php
/* initialisations : */


include('../include/connBase.php');
$validId = false;
session_start();
if(isset($_SESSION["idloginUtilisateur"]))
{
	if(!empty($_SESSION["idloginUtilisateur"]))
	{
		$idloginUtilisateur = $_SESSION['idloginUtilisateur'];
		$validId = true;
	}
}


if ($validId == true)
{

	
	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql="SELECT  idUTILISATEUR,
								nomUTILISATEUR,
								prenomUTILISATEUR,

								loginUTILISATEUR,
								mdpUTILISATEUR,
								datemodifUTILISATEUR,
								admUTILISATEUR

							FROM UTILISATEUR ";
	
if (!empty($idloginUtilisateur))
{
		$sql = $sql . " WHERE "."idUTILISATEUR = :idloginUtilisateur";
		$sql = $sql." LIMIT 1";
		$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
		$sth->bindValue(':idloginUtilisateur', $idloginUtilisateur, PDO::PARAM_INT);
			
	
		
	// echo $sql;
	try {
		$sth->execute();
			
	} catch (PDOException $e) {
		echo 'la recherche du login a échouée : ' . $e->getMessage();
			
	}
	while ($row = $sth->fetch())
		
	{

		if (!empty ($row['idUTILISATEUR']))
		{
			$idUtilisateur=$row['idUTILISATEUR'];
		}
		else
		{
			$idUtilisateur=null;
		}
		if (!empty ($row['nomUTILISATEUR']))
		{
			$nomUtilisateur=$row['nomUTILISATEUR'];
				
		}
		else
		{
			$nomUtilisateur=null;
		}
		if (!empty ($row['prenomUTILISATEUR']))
		{
			$prenomUtilisateur=$row['prenomUTILISATEUR'];

		}
		if (!empty ($row['loginUTILISATEUR']))
		{
			$loginUtilisateur=$row['loginUTILISATEUR'];

		}
		else
		{
			$loginUtilisateur=null;
		}
		if (!empty ($row['mdpUTILISATEUR']))
		{
			$mdpUtilisateur=$row['mdpUTILISATEUR'];

		}
		else
		{
			$mdpUtilisateur=null;
		}
		if (!empty ($row['datemodifUTILISATEUR']))
		{
			$datemodifUtilisateur=$row['datemodifUTILISATEUR'];

		}
		else
		{
			$datemodifUtilisateur=null;
		}
		if (!empty ($row['admUTILISATEUR']))
		{
			$admUtilisateur=$row['admUTILISATEUR'];
		}
		else
		{
			$admUtilisateur=2;
		}

	}
}

		
		
}

	
?>