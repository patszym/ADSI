<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Calendrier
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation2.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> A l'appel du menu général, le mode <b> Liste et Edition</b> est le mode par défaut</p>
			<p> Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence Calendrier. Les fichiers associés 
			sont mémorisés en binaires dans la base de données</p>
			<p> Cliquez sur l'image de l'oeil pour voir le détail de la ligne spécifiée en consultation dans la liste. 
			Dans ce cas particulier, des fichiers issus des binaires sont générés à parir des informations données 
			en ajout et les fihicers d'origine sont reconstitués dans le répertoire du serveur blobExtract</p>
			<p> Cliquez sur l'image du crayon pour voir le détail de la ligne spécifiée en modification dans la liste. 
			Les binaires associés aux fihiers déjà référencés avec le bouton "parcourir" 
			peuvent être modifiés en faisant référence à d'autres fihiers ou une nouvelle version mise à jour 
			de ces fihiers avec ce même bouton</p>
			<p> Cliquez sur l'image de la croix pour voir le détail de la ligne spécifiée en suppression dans la liste</p>
			<p>Cliquez sur l'icône <b>PDF</b> pour voir le détail de la ligne en obtenant son édition PDF </p>
			
			<p>Cliquez sur l'icône <b>PDF</b> à gauche du titre pour obtenir l'édition PDF de la liste</p>
			
	</div><!-- #secondaire -->
		
	<div id="principal"> 
			<h5>Gestion des calendriers </h5>
			
		
			<div id="tabsF">
				<?php include('include/MHCA.php'); 
					session_start();
				$ses_id = session_id();
				?> 
									
			</div>
		
		<fieldset class="saisie">
			<table BORDER=0>
			
			<tr>
			
				<td>
				<a href="editions/edCAPDF.php">
				<img src="images/pdficon.jpg" height="20" width="20" align = "center" 
				alt="PDF">
				</a>
				
				</td>
				
				<td>
				<h3>  LISTE DES RENDEZ VOUS </h3>
				</td>
			</tr>
				
				<?php 
				include('include/con2log.php');
	
				$sql = 'select CALENDRIER.APPLI_idAPPLI, idCALENDRIER, objetRDVCALENDRIER, 
					 dateRDVCALENDRIER, libelleCALENDRIER,
					
					filenamecrdCALENDRIER, extensioncrdCALENDRIER,
					nomAPPLI
					
					from CALENDRIER, APPLI';
				if (isset ($adm))
				
				{
					if ($adm == 0)
					{
						$sql=$sql.' , APPLI_has_UTI';
				
							
					}
				}
				$sql=$sql.'	where CALENDRIER.APPLI_idAPPLI = APPLI.idAPPLI ';
				if (isset ($adm))
				
				{
					if ($adm == 0)
					{
				
						$sql=$sql.' AND APPLI.idAPPLI = APPLI_has_UTI.APPLI_idAPPLI';
						$sql=$sql.' AND APPLI_has_UTI.UTI_idUTI = :idUti';
					}
				}
				$sql=$sql.'	order by nomAPPLI, dateRDVCALENDRIER, objetRDVCALENDRIER';
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				if (isset ($adm))
				
				{
					if ($adm == 0)
					{
				
						$query->bindParam(':idUti', $idUti, PDO::PARAM_INT);
					}
				}
					
			
				include_once "include/visuConvCA.php";
				
				$i = 0 ;
				$idRowAppli = null;
				$idCalendrier = null ;
				$objetRDVCalendrier =  null;
				$dateRDVCalendrier =  null;
				$libelleCalendrier =  null ;
				$filenamecrdCalendrier = null;
				$extensioncrdCalendrier = null;
				$nomAppli = null;
				
			
				
				
				while ($i<$maxRow)
				{
					$idRowAppli =  $tableau [$i][0] ;
					$idCalendrier =  $tableau [$i][1] ;
					$objetRDVCalendrier =  $tableau [$i][2] ;
					$dateRDVCalendrier =  $tableau [$i][3] ;
					$libelleCalendrier =  $tableau [$i] [4];
					$filenamecrdCalendrier =  $tableau [$i] [5];
					$extensioncrdCalendrier =  $tableau [$i] [6];
					$nomAppli = $tableau [$i] [7];
					
						
					
					
					$i++;
					/* Exploitation des lignes dans la liste */
					?>
					
					<?php include "include/convDatesCA.php" ;?> 				
				
				<!-- Liste des  Calendriers - formulaire en lecture -->
									
									
						
							<input type="hidden" name="idCalendrier"
							value="<?php echo htmlspecialchars($idCalendrier); ?>"
							maxlength="3" size="3" ></input>
					
					<tr>
						<td>								
							<input type="text" name="dRDVCalendrier" 
								value="<?php echo htmlspecialchars($dRDVCalendrier); ?>" 
								maxlength="10" size="10" readonly></input>
						</td>
						<td>
							<input type="text" name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="10" readonly></input>
						</td>
						<td>
							<input type="text" name="objetRDVCalendrier" 
							value="<?php echo htmlspecialchars($objetRDVCalendrier); ?>" 
							maxlength="80" size="30" readonly></input>
						</td>
						
						<td>
							<input type="text" name="HRDVCalendrier" 
							value="<?php echo htmlspecialchars($HRDVCalendrier); ?>" 
							maxlength="2" size="2" readonly></input>
						</td>
						<td>
							<input type="text" name="iRDVCalendrier" 
							value="<?php echo htmlspecialchars($iRDVCalendrier); ?>" 
							maxlength="2" size="2" readonly></input>
						</td>
						
						
						<td>
							<form action="consCA.php" method="post">

			 					<input type="hidden" name="idCalendrier" 
			 					value="<?php echo htmlspecialchars($idCalendrier); ?>">
			 					</input>
			 				
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form> 
						</td>
						<td>
							<form action="modifCA.php" method="post">

			 					<input type="hidden" name="idCalendrier" 
			 					value="<?php echo htmlspecialchars($idCalendrier); ?>">
			 					</input>
			 				
								<input border=0 src="images/crayon.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form>
						</td>
							<td> 
							<form action="supprCA.php" method="post">

			 					<input type="hidden" name="idCalendrier" 
			 					value="<?php echo htmlspecialchars($idCalendrier); ?>">
			 					</input>
			 				
								<input border=0 src="images/button-cancel.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form>
						</td> 
						<td> 					
							
							<form action="editions/edElCAPDF.php" method="post">
							
								<input type="hidden" name="nomAppli" 
								value="<?php echo htmlspecialchars($nomAppli); ?>">
								</input>
			 				
			 					<input type="hidden" name="idCalendrier" 
								value="<?php echo htmlspecialchars($idCalendrier); ?>">
								</input>
			 				
								<input type="hidden" name="objetRDVCalendrier" 
								value="<?php echo htmlspecialchars($objetRDVCalendrier); ?>">
								</input>
			 				
			 					<input type="hidden" name="libelleCalendrier" 
								value="<?php echo htmlspecialchars($libelleCalendrier); ?>">
								</input>
			 		
								<input type="hidden" name="dRDVCalendrier" 
								value="<?php echo htmlspecialchars($dRDVCalendrier); ?>">
								</input>
							
								<input type="hidden" name="HRDVCalendrier" 
								value="<?php echo htmlspecialchars($HRDVCalendrier); ?>">
								</input>
								<input type="hidden" name="iRDVCalendrier" 
								value="<?php echo htmlspecialchars($iRDVCalendrier); ?>">
								</input>
								
								<input type="hidden" name="filenamecrdCalendrier" 
								value="<?php echo htmlspecialchars($filenamecrdCalendrier); ?>">
								</input>
								<input type="hidden" name="extensioncrdCalendrier" 
								value="<?php echo htmlspecialchars($extensioncrdCalendrier); ?>">
								</input>
																
			 					<input border=0 src="images/pdficon.jpg" 
								type=image value=submit name = "soumet" align="left" 
								height="20" width="20">
								</input>

										
							</form>
						</td> 
											
					</tr>			
										
							
				<?php 
				}
				$query = null;
				?>
			</table>
		</fieldset>

		</div> <!-- principal-->
	
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
