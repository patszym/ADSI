<?php	
include_once('include/ConversionDates.class.php');			  
				
					$idProcessuscycle = null;
					
					if(!empty($_POST["idProcessus"]))
					{
						$idProcessus=$_POST["idProcessus"];
					} else
					{
						$idProcessus = null;
					}

					if(!empty($_POST["idCycle"]))
					{
						$idCycle=$_POST["idCycle"];
					} else
					{
						$idCycle = null;
					}
					include('include/connBase.php');
					$validBase = true;
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM PROCESSUSCYCLE WHERE PROCESSUS_idPROCESSUS = :idProcessus
								AND CYCLE_idCYCLE = :idCycle';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idProcessus', $idProcessus, PDO::PARAM_INT);
						$sth->bindValue(':idCycle', $idCycle, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
							
							
							
							
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé unique a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo  " au moins 1 occurence(s) dans la table PROCESSUSCYCLE utilise(nt) ces réferences PROCESSUS et CYCLE <br>";
					
						?>
							<script language="javascript">
							alert("L'ajout est impossible car il y a une référence dans la table PROCESSUSCYCLE exploitant ces valeurs de processus et cycle");
							</script>
						<?php
					}
																				
															
					
					
					$dateversRowPrevOuvProcessuscycle  = null;
					$validdatePrevOuvProcessuscycle = true;
					
					if (!empty($_POST["datePrevOuvProcessuscycle"])) 
					{
							
						
						$conversionDate1 = new ConversionDates();
						$conversionDate1->setdt($_POST['datePrevOuvProcessuscycle']);
						if (isset($_POST['HPrevOuvProcessuscycle'])) 
						{
							$H = $_POST['HPrevOuvProcessuscycle'];
						
							if (($H>24) or ($H<00))
							{
								echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
							
								$H = "00";
							}
						}
						else 
						{
							$H = "00";
						}
					
						
						$conversionDate1->setH($H);
						
						
						if (isset($_POST['iPrevOuvProcessuscycle']))
						{
							$i = $_POST['iPrevOuvProcessuscycle'];
							if (($i>60) or ($i<00))
							{
								echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
								$i = "00";
							}
						}
						else
						{
							$i = "00";
						}
						
						$conversionDate1->seti($i);
						
						
						$conversionDate1->convdDate();
						
						
						$dateversRowPrevOuvProcessuscycle = $conversionDate1->getdate() ;
						
						if (!checkdate($conversionDate1->getm(), $conversionDate1->getd(), $conversionDate1->getY()))
						{
								
							$validdatePrevOuvProcessuscycle = false;
							echo $datePrevOuvProcessuscycle. " n'est pas une date et une heure valide <br>";
							?>
								<script language="javascript">
								alert("Date  non conforme au format d'une date");
								</script>
								<?php
						}
					} 
					else
					{
							$dateversRowPrevOuvProcessuscycle  = null;
							
					}
				

					$dateversRowEffOuvProcessuscycle  = null;
					$validdateEffOuvProcessuscycle = true;
						
					if (!empty($_POST["dateEffOuvProcessuscycle"])) 
					{
							
							
						$conversionDate2 = new ConversionDates();
						$conversionDate2->setdt($_POST['dateEffOuvProcessuscycle']);
						if (isset($_POST['HEffOuvProcessuscycle']))
						{
							$H = $_POST['HEffOuvProcessuscycle'];
					
							if (($H>24) or ($H<00))
							{
								echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
								
								$H = "00";
							}
						}
						else
						{
							$H = "00";
						}
					
						$conversionDate2->setH($H);
						if (isset($_POST['iEffOuvProcessuscycle']))
						{
							$i = $_POST['iEffOuvProcessuscycle'];
							if (($i>60) or ($i<00))
							{
								echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
								$i = "00";
							}
						}
						else
						{
							$i = "00";
						}
						
					
						$conversionDate2->seti($i);
					
					
						$conversionDate2->convdDate();
					
					
						$dateversRowEffOuvProcessuscycle = $conversionDate2->getdate() ;
					
						if (!checkdate($conversionDate2->getm(), $conversionDate2->getd(), $conversionDate2->getY()))
						{
					
							$validdateEffOuvProcessuscycle = false;
							echo $dateEffOuvProcessuscycle. " n'est pas une date et une heure valide <br>";
							?>
													<script language="javascript">
													alert("Date  non conforme au format d'une date");
													</script>
							<?php
						}
					} 
					else
					{
						$dateversRowEffOuvProcessuscycle  = null;
												
					}
									
												
						// date de fermeture :

					$dateversRowPrevFerProcessuscycle  = null;
					$validdatePrevFerProcessuscycle = true;
											
					if (!empty($_POST["datePrevFerProcessuscycle"])) 
					{
												
												
						$conversionDate3 = new ConversionDates();
						$conversionDate3->setdt($_POST['datePrevFerProcessuscycle']);
						if (isset($_POST['HPrevFerProcessuscycle']))
						{
							$H = $_POST['HPrevFerProcessuscycle'];
										
							if (($H>24) or ($H<00))
							{
								echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
													
								$H = "00";
							}
						}
						else
						{
							$H = "00";
						}				
						$conversionDate3->setH($H);
						if (isset($_POST['iPrevFerProcessuscycle']))
						{				
							$i = $_POST['iPrevFerProcessuscycle'];
							if (($i>60) or ($i<00))
							{
								echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
								$i = "00";
							}
						}
						else
						{
							$i = "00";
						}
										
						$conversionDate3->seti($i);
										
										
						$conversionDate3->convdDate();
										
										
						$dateversRowPrevFerProcessuscycle = $conversionDate3->getdate() ;
										
						if (!checkdate($conversionDate3->getm(), $conversionDate3->getd(), $conversionDate3->getY()))
						{
										
							$validdatePrevFerProcessuscycle = false;
							echo $datePrevFerProcessuscycle. " n'est pas une date et une heure valide <br>";
							?>
									<script language="javascript">
								alert("Date  non conforme au format d'une date");
								</script>
							<?php
						}
					} 
					else
					{
						$dateversRowPrevFerProcessuscycle  = null;
																	
					}
														
										
					$dateversRowEffFerProcessuscycle  = null;
					$validdateEffFerProcessuscycle = true;
																
					if (!empty($_POST["dateEffFerProcessuscycle"])) 
					{
																	
																	
						$conversionDate4 = new ConversionDates();
						$conversionDate4->setdt($_POST['dateEffFerProcessuscycle']);
						
						if (isset($_POST['HEffFerProcessuscycle']))
						{
							$H = $_POST['HEffFerProcessuscycle'];
															
							if (($H>24) or ($H<00))
							{
								echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
																		
								$H = "00";
							}
						}
						else
						{
							$H = "00";
						}
															
						$conversionDate4->setH($H);
						if (isset($_POST['iEffFerProcessuscycle']))
						{
															
							$i = $_POST['iEffFerProcessuscycle'];
							if (($i>60) or ($i<00))
							{
								echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
								$i = "00";
							}
						}
						else
						{
							$i = "00";
						}
															
						$conversionDate4->seti($i);
															
															
						$conversionDate4->convdDate();
															
															
						$dateversRowEffFerProcessuscycle = $conversionDate4->getdate() ;
															
						if (!checkdate($conversionDate4->getm(), $conversionDate4->getd(), $conversionDate4->getY()))
						{
															
																	$validdateEffFerProcessuscycle = false;
																	echo $dateEffFerProcessuscycle. " n'est pas une date et une heure valide <br>";
							?>
																							<script language="javascript">
																							alert("Date  non conforme au format d'une date");
																							</script>
							<?php
						}
					} 
					else
					{
						$dateversRowEffFerProcessuscycle  = null;
																						
					}
																			
																						
									// date de fin :

				$dateversRowPrevFinProcessuscycle  = null;
				$validdatePrevFinProcessuscycle = true;
																					
				if (!empty($_POST["datePrevFinProcessuscycle"])) 
				{
																						
																						
					$conversionDate5 = new ConversionDates();
					$conversionDate5->setdt($_POST['datePrevFinProcessuscycle']);
					if (isset($_POST['HPrevFinProcessuscycle']))
					{
						$H = $_POST['HPrevFinProcessuscycle'];
																				
						if (($H>24) or ($H<00))
						{
							echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
																							
							$H = "00";
						}
					}
					else
					{
						$H = "00";
					}
					
																				
					$conversionDate5->setH($H);
					if (isset($_POST['iPrevFinProcessuscycle']))
					{															
						$i = $_POST['iPrevFinProcessuscycle'];
						if (($i>60) or ($i<00))
						{
							echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
							$i = "00";
						}
					}
					else
					{
						$i = "00";
					}	
																				
					$conversionDate5->seti($i);
																				
																				
					$conversionDate5->convdDate();
																				
																				
					$dateversRowPrevFinProcessuscycle = $conversionDate5->getdate() ;
																				
					if (!checkdate($conversionDate5->getm(), $conversionDate5->getd(), $conversionDate5->getY()))
					{
																				
						$validdatePrevFinProcessuscycle = false;
						echo $datePrevFinProcessuscycle. " n'est pas une date et une heure valide <br>";
						?>
																												<script language="javascript">
																												alert("Date  non conforme au format d'une date");													</script>
						<?php
					}
				} 
				else
				{
					$dateversRowPrevFinProcessuscycle  = null;
																											
				}
																								
																				
				$dateversRowEffFinProcessuscycle  = null;
				$validdateEffFinProcessuscycle = true;
																										
				if (!empty($_POST["dateEffFinProcessuscycle"])) 
				{
																											
																											
					$conversionDate6 = new ConversionDates();
					$conversionDate6->setdt($_POST['dateEffFinProcessuscycle']);
					if (isset($_POST['HEffFinProcessuscycle']))
					{
						$H = $_POST['HEffFinProcessuscycle'];
																									
						if (($H>24) or ($H<00))
						{
							echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
																												
							$H = "00";
						}
					}
					else
					{
						$H = "00";
					}
																									
					$conversionDate6->setH($H);
					if (isset($_POST['iEffFinProcessuscycle']))
					{																				
						$i = $_POST['iEffFinProcessuscycle'];
						if (($i>60) or ($i<00))
						{
							echo "minutes anormales: minutes doit être supérieure à 00 et inférieure à 61 <br></br>";
							$i = "00";
						}
					}
					else 
					{
						$i = "00";
					}
						
																									
					$conversionDate6->seti($i);
																									
																									
					$conversionDate6->convdDate();
																									
																									
					$dateversRowEffFinProcessuscycle = $conversionDate6->getdate() ;
																									
					if (!checkdate($conversionDate6->getm(), $conversionDate6->getd(), $conversionDate6->getY()))
					{
																									
						$validdateEffFinProcessuscycle = false;
						echo $dateEffFinProcessuscycle. " n'est pas une date et une heure valide <br>";
						?>
																																	<script language="javascript">
																																	alert("Date  non conforme au format d'une date");
																																	</script>
						<?php
					}
				} 
				else
				{
					$dateversRowEffFinProcessuscycle  = null;
																																
				}
																													
																																
																			
						
						
		/* Mise à jour :
		 * 
		 */
					if (((!empty( $_POST['soumet'] )) AND ($validBase))  AND (!empty( $_POST['idProcessus'] )))
				{		
					
					
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idPROCESSUSCYCLE) FROM PROCESSUSCYCLE ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idProcessuscycle = $gid->fetchColumn();
					
					
					
					$idProcessuscycle ++ ;
					
					
					$sql = 'insert into PROCESSUSCYCLE values ("'.$idProcessuscycle.'",'.
							'"'.$idCycle.'","'.$idProcessus.'",';
							
						
									
									
					if(!empty($_POST["datePrevOuvProcessuscycle"]))
					{
						
						$sql = $sql.'"'.$dateversRowPrevOuvProcessuscycle .'",';
					}
					else
					{
					$sql = $sql .'null,';
					}
					if(!empty($_POST["dateEffOuvProcessuscycle"]))
					{
					
						$sql = $sql.'"'.$dateversRowEffOuvProcessuscycle .'",';
					}
					else
					{
						$sql = $sql .'null,';
					}
					if(!empty($_POST["datePrevFerProcessuscycle"]))
					{
					
						$sql = $sql.'"'.$dateversRowPrevFerProcessuscycle .'",';
					}
					else
					{
						$sql = $sql .'null,';
					}
					if(!empty($_POST["dateEffFerProcessuscycle"]))
					{
					
						$sql = $sql.'"'.$dateversRowEffFerProcessuscycle .'",';
					}
					else
					{
						$sql = $sql .'null,';
					}
					if(!empty($_POST["datePrevFinProcessuscycle"]))
					{
					
						$sql = $sql.'"'.$dateversRowPrevFinProcessuscycle .'",';
					}
					else
					{
						$sql = $sql .'null,';
					}
					if(!empty($_POST["dateEffFinProcessuscycle"]))
					{
					
						$sql = $sql.'"'.$dateversRowEffFinProcessuscycle .'"';
					}
					else
					{
						$sql = $sql .'null';
					}
							
					$sql = $sql .');'   ;
					 // echo $sql;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
			?>	