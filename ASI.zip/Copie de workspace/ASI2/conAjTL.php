<?php	
include_once('include/ConversionDates.class.php');
				
					$idTraitlocal = null;
					
					if(!empty($_POST["idAppli"]))
					{
						$idAppli=$_POST["idAppli"];
					} else
					{
						$idAppli = null;
					}
						
					if(!empty($_POST["nomTraitlocal"]))
					{
						$nomTraitlocal=$_POST["nomTraitlocal"];
					} else 
					{ 
						$nomTraitlocal = null;
					}
					
										
					
					
					if(!empty($_POST["libelleTraitlocal"]))						
					{
						$libelleTraitlocal=$_POST["libelleTraitlocal"];
					} else
					{
						$libelleTraitlocal = null;
					}
				
					if(!empty($_POST["servTraitlocal"]))
					{
						$servTraitlocal=$_POST["servTraitlocal"];
					} else
					{
						$servTraitlocal = null;
					}
					
					
					if(!empty($_POST["chemTraitlocal"]))
					{
						$chemTraitlocal=$_POST["chemTraitlocal"];
					} else
					{
						$chemTraitlocal = null;
					}
					
					
					if(!empty($_POST["nomprogTraitlocal"]))
					{
						$nomprogTraitlocal=$_POST["nomprogTraitlocal"];
					} else
					{
						$nomprogTraitlocal = null;
					}
					
					if(!empty($_POST["phraseSQLTraitlocal"]))
					{
						$phraseSQLTraitlocal=$_POST["phraseSQLTraitlocal"];
					} else
					{
						$phraseSQLTraitlocal = null;
					}
						
					$dateversRowdemandeTraitlocal  = null;
					$validdatedemandeTraitlocal = true;
						
					if (!empty($_POST["datedemandeTraitlocal"])) 
					{
							
							
						$conversionDate1 = new ConversionDates();
						$conversionDate1->setdt($_POST['datedemandeTraitlocal']);
						
					
						$conversionDate1->convdDate();
					
					
						$dateversRowdemandeTraitlocal = $conversionDate1->getdate() ;
					
						if (!checkdate($conversionDate1->getm(), $conversionDate1->getd(), $conversionDate1->getY()))
						{
					
							$validdatedemandeTraitlocal = false;
							echo $datedemandeTraitlocal. " n'est pas une date et une heure valide <br>";
							?>
													<script language="javascript">
													alert("Date rendez vous de la réunion non conforme au format d'une date");													</script>
													<?php
											}
										} 
										else
										{
												$dateversRowdemandeTraitlocal  = null;
												
										}
						
		/* Mise à jour :
		 * 
		 */
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idTRAITLOCAL) FROM TRAITLOCAL ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idTraitlocal = $gid->fetchColumn();
					
					
					
					$idTraitlocal ++ ;
					
					
					$sql = 'insert into TRAITLOCAL values ("'.$idTraitlocal.'",'.
							'"'.$idAppli.'","'.
							$nomTraitlocal.'","'.
							$libelleTraitlocal.'","'.
							$servTraitlocal.'","'.
							$chemTraitlocal.'","'.
							$nomprogTraitlocal.'","'.
							$phraseSQLTraitlocal.'",';
					
							if(!empty($_POST["datedemandeTraitlocal"]))
							{
							
								$sql = $sql.'"'.$dateversRowdemandeTraitlocal .'"';
							}
							else
							{
								$sql = $sql .'null';
							}
							
							
					$sql = $sql .');'   ;
					// echo $sql;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
			?>	