<!DOCTYPE html PUBLIC "-//W3C//DTD XHTAL 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Tache
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation2.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> A l'appel du menu général, le mode <b> Liste et Edition</b> est le mode par défaut</p>
			<p> Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence de traitement local. </p>
			<p> Cliquez sur l'image de l'oeil pour voir le détail de la ligne spécifiée en consultation dans la liste. 
			
			<p> Cliquez sur l'image du crayon pour voir le détail de la ligne spécifiée en modification dans la liste. 
			</p>
			<p> Cliquez sur l'image de la croix pour voir le détail de la ligne spécifiée en suppression dans la liste</p>
			<p>Cliquez sur l'icône <b>PDF</b> pour voir le détail de la ligne en obtenant son édition PDF </p>
			
			<p>Cliquez sur l'icône <b>PDF</b> à gauche du titre pour obtenir l'édition PDF de la liste</p>
			
	</div><!-- #secondaire -->
		
	<div id="principal"> 
			<h5>Gestion des taches</h5>
			
		
			<div id="tabsF">
				<?php include('include/MHTA.php'); 
					session_start();
				$ses_id = session_id();
				?> 
									
			</div>
		
		<fieldset class="saisie">
			<table BORDER=0>
			
			<tr>
			
				<td>
				<a href="editions/edTAPDF.php">
				<img src="images/pdficon.jpg" height="20" width="20" align = "center" 
				alt="PDF">
				</a>
				</td>
				
				<td>
				<h3>  LISTE DES TACHES </h3>
				</td>
			</tr>
				
				<?php 
				include('include/con2log.php');
	
				$sql = 'select idPROCESSUS, idTACHE, 
					libelleTACHE, descriptifTACHE,
					libellePROCESSUS, libelleCAMPAGNE, nomAPPLI, idAPPLI, idCAMPAGNE,
					synchroEntreeTACHE,
					entreeTACHE,
					sortieTACHE,
					servTACHE,
					nomTraitTACHE,
					chemShellTACHE
					
					from TACHE, PROCESSUS, CAMPAGNE, APPLI';
				if (isset ($adm))
				
				{
					if ($adm == 0)
					{
						$sql=$sql.' , APPLI_has_UTI';
						
					}
				}
				
				$sql=$sql.' where TACHE.PROCESSUS_idPROCESSUS = PROCESSUS.idPROCESSUS
					and PROCESSUS.CAMPAGNE_idCAMPAGNE = CAMPAGNE.idCAMPAGNE
					and APPLI.idAPPLI = CAMPAGNE.APPLI_idAPPLI';
				if (isset ($adm))
					
				{
					if ($adm == 0)
					{
							
						$sql=$sql.' AND APPLI.idAPPLI = APPLI_has_UTI.APPLI_idAPPLI';
						$sql=$sql.' AND APPLI_has_UTI.UTI_idUTI = :idUti';
					}
				}
				$sql=$sql.' order by nomAPPLI, libellePROCESSUS, libelleTACHE';
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				if (isset ($adm))
					
				{
					if ($adm == 0)
					{
							
						$query->bindParam(':idUti', $idUti, PDO::PARAM_INT);
					}
				}
			
				include_once "include/visuConvTA.php";
				
				$i = 0 ;
				$idRowCampagne = null;
				$idTache = null ;
				
				$libelleTache =  null;
				$descriptifTache =  null;
				$libelleProcessus= null;
				$libelleCampagne = null;
				$nomAppli = null;
				
				$idAppli = null;
				$idCampagne = null;
				$synchroEntreeTache =  null;
				$entreeTache =  null;
				$sortieTache =  null;
				$servTache =  null;
				$nomTraitTache =  null;
				$chemShellTache =  null;
				
				while ($i<$maxRow)
				{
					$idRowCampagne =  $tableau [$i][0] ;
					$idTache =  $tableau [$i][1] ;
					
					
					$libelleTache =	$tableau [$i] [2];
					$descriptifTache =  $tableau [$i][3] ;
					
					$libelleProcessus = $tableau [$i] [4];
					$libelleCampagne = $tableau [$i] [5];
					$nomAppli = $tableau [$i] [6];
					$idAppli = $tableau [$i] [7];
					$idCampagne = $tableau [$i] [8];
					$synchroEntreeTache = $tableau [$i] [9];
					$entreeTache = $tableau [$i] [10];
					$sortieTache = $tableau [$i] [11];
					$servTache = $tableau [$i] [12];
					$nomTraitTache = $tableau [$i] [13];
					$chemShellTache = $tableau [$i] [14];
					
					$i++;
					/* Exploitation des lignes dans la liste */
					?>
					
					
				
				<!-- Liste des  Taches - formulaire en lecture -->
									
									
						
							<input type="hidden" name="idTache"
							value="<?php echo htmlspecialchars($idTache); ?>"
							maxlength="3" size="3" ></input>
					
					<tr>
						<td>
							<input type="text" name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="10" readonly></input>
						</td>
						<td>
							<input type="text" name="libelleCampagne" 
							value="<?php echo htmlspecialchars($libelleCampagne); ?>" 
							maxlength="100" size="60" readonly></input>
						</td>
					</tr>
					<tr>
						<td></td>
						<td>
							<input type="text" name="libelleProcessus" 
							value="<?php echo htmlspecialchars($libelleProcessus); ?>" 
							maxlength="100" size="60" readonly></input>
						</td>
					</tr>
					<tr>
						<td></td>
						<td>
							<input type="text" name="libelleTache" 
							value="<?php echo htmlspecialchars($libelleTache); ?>" 
							maxlength="100" size="60" readonly></input>
						</td>
					
					
						
						
						<td>
							<form action="consTA.php" method="post">

			 					<input type="hidden" name="idTache" 
			 					value="<?php echo htmlspecialchars($idTache); ?>">
			 					</input>
			 					<input type="hidden" name="idCampagne" 
								value="<?php echo htmlspecialchars($idCampagne); ?>" 
								></input>
			 				
			 					
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
						</td>
							</form> 
						</td>
						<td>
							<form action="modifTA.php" method="post">

			 					<input type="hidden" name="idTache" 
			 					value="<?php echo htmlspecialchars($idTache); ?>">
			 					</input>
			 					<input type="hidden" name="idCampagne" 
								value="<?php echo htmlspecialchars($idCampagne); ?>" 
								></input>
			 				
								<input border=0 src="images/crayon.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form>
						</td>
						<td> 
							<form action="supprTA.php" method="post">

			 					<input type="hidden" name="idTache" 
			 					value="<?php echo htmlspecialchars($idTache); ?>">
			 					</input>
			 					<input type="hidden" name="idCampagne" 
								value="<?php echo htmlspecialchars($idCampagne); ?>" 
								></input>
								<input border=0 src="images/button-cancel.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form>
						</td> 
						<td> 					
							
							<form action="editions/edElTAPDF.php" method="post">
							
								<input type="hidden" name="nomAppli" 
								value="<?php echo htmlspecialchars($nomAppli); ?>">
								</input>
								
								<input type="hidden" name="libelleCampagne" 
								value="<?php echo htmlspecialchars($libelleCampagne); ?>">
								</input>
			 				
			 						<input type="hidden" name="libelleProcessus" 
								value="<?php echo htmlspecialchars($libelleProcessus); ?>">
								</input>
								
			 					<input type="hidden" name="idTache" 
								value="<?php echo htmlspecialchars($idTache); ?>">
								</input>
			 				
										 				
			 					<input type="hidden" name="libelleTache" 
								value="<?php echo htmlspecialchars($libelleTache); ?>">
								</input>
			 		
								<input type="hidden" name="descriptifTache" 
								value="<?php echo htmlspecialchars($descriptifTache); ?>">
								</input>
							
								<input type="hidden" name="synchroEntreeTache" 
								value="<?php echo htmlspecialchars($synchroEntreeTache); ?>">
								</input>
								
								<input type="hidden" name="entreeTache" 
								value="<?php echo htmlspecialchars($entreeTache); ?>">
								</input>
								
								<input type="hidden" name="sortieTache" 
								value="<?php echo htmlspecialchars($sortieTache); ?>">
								</input>
								
								<input type="hidden" name="servTache" 
								value="<?php echo htmlspecialchars($servTache); ?>">
								</input>
								
								<input type="hidden" name="nomTraitTache" 
								value="<?php echo htmlspecialchars($nomTraitTache); ?>">
								</input>
								
								<input type="hidden" name="chemShellTache" 
								value="<?php echo htmlspecialchars($chemShellTache); ?>">
								</input>
																
			 					<input border=0 src="images/pdficon.jpg" 
								type=image value=submit name = "soumet" align="left" 
								height="20" width="20">
								</input>

										
							</form>
						</td> 
											
					</tr>			
										
							
				<?php 
				}
				$query = null;
				?>
			</table>
		</fieldset>

		</div> <!-- principal-->
	
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
