<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		calendriers
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation2.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p>Cliquez sur l'onglet <b>Liste et Edition </b> pour une autre consultation, 
			une modification, ou une suppression </p>
			<p> Cliquez sur l'onglet <b> Ajout </b> pour créer une occurence de Calendrier</p>
			
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5>Gestion des calendriers </h5>
			
			
			<div id="tabsF">
				<?php include('include/MHCA.php'); ?> 
			</div>
				<?php $cons=1;?>
				<?php include('include/con2CA.php'); ?> 
				<?php include('include/con1APs.php'); ?> 
			<fieldset class="saisie">	
			
					
			<form name="consCalendrier" id="consCalendrierForm" method="post"
				 enctype="multipart/form-data" 
					action="consCA2.php">
				<table border=0>	
				
							<input type="hidden" name="idCalendrier" 
							value="<?php echo htmlspecialchars($idCalendrier); ?>">
							</input>
							<input type="hidden" name="ses_id"
							value="<?php echo htmlspecialchars($ses_id); ?>"
							  ></input>
					<tr>
						<td>Application :</td>
						<td>
						 <select   name="idAppli" disabled>
							<?php
							
							$i = 0;
							while ($i<$index1)
							{
					
								 	echo '<option value="'.
										$tableau1 [$i][0].'"'.$tableau1 [$i][2].'>'.
										$tableau1 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
					
								
				
					<tr>
						<td> Objet du rendez vous :</td>
						<td>
							<input type="text" name="objetRDVCalendrier" 
							value="<?php echo htmlspecialchars($objetRDVCalendrier); ?>"
							 maxlength="80" size="50" readonly></input>
						</td>
					</tr>
						<tr>
						<td> Date du rendez vous : </td>
						<td>
							<INPUT type=text id="calendrier1" 
							name="dateRDVCalendrier" 
							value="<?php echo htmlspecialchars($dRDVCalendrier); ?>" 
							maxlength="10" size="10" readonly>
							</input>
						</td>
					</tr>
					<tr>
						<td> Heure du rendez-vous : </td>
						<td>
							<INPUT type="text" 
							name="HRDVCalendrier" 
							value="<?php echo htmlspecialchars($HRDVCalendrier); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>
					<tr>
						<td> Minutes du rendez-vous : </td>
						<td>
							<INPUT type="text" 
							name="iRDVCalendrier" 
							value="<?php echo htmlspecialchars($iRDVCalendrier); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>			
					<tr>
						<td> Libelle du rendez vous :</td>
						<td>
							<textarea name = "libelleCalendrier" rows="6" cols="50" readonly>
							<?php echo htmlspecialchars($libelleCalendrier); ?>
							</textarea>
						</td>
					</tr>
					
					<?php 
					if ($filenamecrdCalendrier !=null )
					{
					$visu = 
					'<tr>
					
						<td> Compte rendu :</td>
						<td>';
					
					
							$crd = '<object data="'.$ficcrdnom.'" type="'.$mimecrdCalendrier.
								 '" width="400" height="400">'.
								'</object>';
					$visu = $visu . $crd .
					'</tr>';
						echo $visu;
					
						$encadre = '<table width="100%" border ="1" 
									cellspacing="1" cellpadding="1">';
						$encadre = $encadre .
							'<tr><td>
							<div align=center>';
						$encadre = $encadre .
							'Des fichiers ont été générés<br></br>
							dans le répertoire du serveur<br></br>
							nommé blobExtract';
						$encadre = $encadre .
							'</div>
							</td><tr></table>' ;
						echo $encadre;
					 						
					$boutons = 
					'<tr>
						<br></br>
						<td>		
					<input type="submit" name = "soumet"
					value="Nettoyage de tous les fichiers" name="soumet">				
					</input>
						</td>
					
						<td>			
					<input type="submit" name = "soumet2"
					value="Nettoyage de vos fichiers générés" name="soumet">
					</input>			
					
					
						</td>
					</tr>';
					echo $boutons;
					}
						
					?>
				</table>	
			</form>
			
			</fieldset>	
			
			
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	
</div><!-- #global -->

</body>
</html>
