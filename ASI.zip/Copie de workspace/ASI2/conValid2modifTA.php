<?php	

if(!empty($_POST["soumet"]))
{

					$idTache = $_POST["idTache"];
					
					if(!empty($_POST["idProcessus"]))
					{
						$idProcessus=$_POST["idProcessus"];
					} else
					{
						$idProcessus = null;
					}
					
				
					if(!empty($_POST["libelleTache"]))
					{
						$libelleTache=$_POST["libelleTache"];
					} else
					{
						$libelleTache = null;
					}
					if(!empty($_POST["descriptifTache"]))
					{
						$descriptifTache=$_POST["descriptifTache"];
					} else
					{
						$descriptifTache = null;
					}
					if(!empty($_POST["synchroEntreeTache"]))
					{
						$synchroEntreeTache=$_POST["synchroEntreeTache"];
					} else
					{
						$synchroEntreeTache = null;
					}
					if(!empty($_POST["entreeTache"]))
					{
						$entreeTache=$_POST["entreeTache"];
					} else
					{
						$entreeTache = null;
					}
					if(!empty($_POST["sortieTache"]))
					{
						$sortieTache=$_POST["sortieTache"];
					} else
					{
						$sortieTache = null;
					}
					if(!empty($_POST["servTache"]))
					{
						$servTache=$_POST["servTache"];
					} else
					{
						$servTache = null;
					}
					if(!empty($_POST["nomTraitTache"]))
					{
						$nomTraitTache=$_POST["nomTraitTache"];
					} else
					{
						$nomTraitTache = null;
					}
					if(!empty($_POST["chemShellTache"]))
					{
						$chemShellTache=$_POST["chemShellTache"];
					} else
					{
						$chemShellTache = null;
					}
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE TACHE SET '.
							' PROCESSUS_idPROCESSUS ="'.$idProcessus.'",'.
							
							' libelleTACHE ="'.$libelleTache.'",'.
							' descriptifTACHE ="'.$descriptifTache.'",'.
							' synchroEntreeTACHE ="'.$synchroEntreeTache.'",'.
							' entreeTACHE ="'.$entreeTache.'",'.
							' sortieTACHE ="'.$sortieTache.'",'.
							' servTACHE ="'.$servTache.'",'.
							' nomTraitTACHE ="'.$nomTraitTache.'",'.
							' chemShellTACHE ="'.$chemShellTache.'"';
					
					$sql = $sql.' WHERE idTACHE = :idTache ';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idTache', $idTache, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	