<?php	

				
					$idTache = null;
					
					if(!empty($_POST["idProcessus"]))
					{
						$idProcessus=$_POST["idProcessus"];
					} else
					{
						$idProcessus = null;
					}
					
					
					if(!empty($_POST["libelleTache"]))						
					{
						$libelleTache=$_POST["libelleTache"];
					} else
					{
						$libelleTache = null;
					}
				
					if(!empty($_POST["descriptifTache"]))
					{
						$descriptifTache=$_POST["descriptifTache"];
					} else
					{
						$descriptifTache = null;
					}
					if(!empty($_POST["synchroEntreeTache"]))
					{
						$synchroEntreeTache=$_POST["synchroEntreeTache"];
					} else
					{
						$synchroEntreeTache = null;
					}
					if(!empty($_POST["entreeTache"]))
					{
						$entreeTache=$_POST["entreeTache"];
					} else
					{
						$entreeTache = null;
					}
					if(!empty($_POST["sortieTache"]))
					{
						$sortieTache=$_POST["sortieTache"];
					} else
					{
						$sortieTache = null;
					}
					if(!empty($_POST["servTache"]))
					{
						$servTache=$_POST["servTache"];
					} else
					{
						$servTache = null;
					}
					if(!empty($_POST["descriptifTache"]))
					{
						$descriptifTache=$_POST["descriptifTache"];
					} else
					{
						$descriptifTache = null;
					}
					if(!empty($_POST["nomTraitTache"]))
					{
						$nomTraitTache=$_POST["nomTraitTache"];
					} else
					{
						$nomTraitTache = null;
					}
					if(!empty($_POST["chemShellTache"]))
					{
						$chemShellTache=$_POST["chemShellTache"];
					} else
					{
						$chemShellTache = null;
					}
				
					
					
						
		/* Mise à jour :
		 * 
		 */
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idTACHE) FROM TACHE ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idTache = $gid->fetchColumn();
					
					
					
					$idTache ++ ;
					
					
					$sql = 'insert into TACHE values ("'.$idTache.'",'.
							'"'.$idProcessus.'","'.
							
							$libelleTache.'","'.
							$descriptifTache.'","'.
							$synchroEntreeTache.'","'.
							$entreeTache.'","'.
							$sortieTache.'","'.
							$servTache.'","'.
							$nomTraitTache.'","'.
							$chemShellTache.'"';
							
							
					$sql = $sql .');'   ;
					// echo $sql;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
			?>	