<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">


<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>
		rattachements application et projet
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
</meta>
<head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> A l'appel du menu général, le mode <b> Liste et Edition</b> est le mode par défaut</p>
			<p> Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence Appli_idAppli</p>
			<p> Cliquez sur l'image de l'oeil pour voir le détail de la ligne spécifiée en consultation dans la liste</p>
			<p> Cliquez sur l'image de la croix pour voir le détail de la ligne spécifiée en suppression dans la liste</p>
			<p>Cliquez sur l'icône <b>PDF</b> pour voir le détail de la ligne en obtenant son édition PDF </p>
			<p>Cliquez sur l'icône <b>PDF</b> à gauche du titre pour obtenir l'édition PDF de la liste</p>
			
	</div><!-- #secondaire -->
		
	<div id="principal"> 
			<h5>Gestion des rattachements application et projet </h5>
			
		
		<fieldset class="saisie">
			<table BORDER=0>
			
			<tr>
			
				<td>
				<a href="editions/edAPPRPDF.php">
				<img src="images/pdficon.jpg" height="20" width="20" align = "center" 
				alt="PDF">
				</a>
				</td>
				<td>
				<h3>  LISTE DES RATTACHEMENTS DES PROJET(s) PAR APPLICATION </h3>
				</td>
			</tr>
				
				<?php 
				if(!empty($_POST["idAppli"]))
				{
					$idAppli=$_POST["idAppli"];
				}
				else {
					$idAppli = null;
				}
				
				include_once "include/connBase.php" ; 
	
				$sql = 'select APPLI_idAPPLI,PROJET_idPROJET,
					nomAPPLI, 
					nomPROJET
					from APPLI_has_PROJET, APPLI, PROJET
					where APPLI_idAPPLI = idAPPLI 
					and   PROJET_idPROJET = idPROJET
					and   APPLI_idAPPLI = :idAppli
						order by nomAPPLI, nomPROJET';
	
			
				include_once "include/visuConvAPPR.php";
				
				$i = 0 ;
				$Appli_idAppli = null;
				$Projet_idProjet = null;
				$nomAppli =  null;
				$nomProjet =  null;
				
				while ($i<$maxRow)
				{
					$Appli_idAppli = $tableau [$i][0];
					$Projet_idProjet = $tableau [$i][1] ;
					$nomAppli =  $tableau [$i][2] ;
					$nomProjet =  $tableau [$i][3] ;
					
					
					
				
					/* Exploitation des lignes dans la liste */
					
									
					
					
					$i++;
					?>
					<tr>
									
									
						
							<input type="hidden" name="Appli_idAppli"
							value="<?php echo htmlspecialchars($Appli_idAppli); ?>"
							 ></input>
						
													
						
							<input type="hidden" name="Projet_idProjet"
							value="<?php echo htmlspecialchars($Projet_idProjet); ?>"
							></input>
						
														
						<td>
							<input type="text" name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
													
													
														
						<td>
							<input type="text" name="nomProjet" 
							value="<?php echo htmlspecialchars($nomProjet); ?>" 
							maxlength="80" size="40" readonly></input>
						</td>
						
						<td>
							<form action="consAPPR.php" method="post">

			 					<input type="hidden" name="Appli_idAppli" 
			 					value="<?php echo htmlspecialchars($Appli_idAppli); ?>">
			 					</input>
			 					<input type="hidden" name="Projet_idProjet" 
			 					value="<?php echo htmlspecialchars($Projet_idProjet); ?>">
			 					</input>
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form> 
						</td>
						
							<td> 
							<form action="supprAPPR.php" method="post">

			 					<input type="hidden" name="Appli_idAppli" 
			 					value="<?php echo htmlspecialchars($Appli_idAppli); ?>">
			 					</input>
			 					<input type="hidden" name="Projet_idProjet" 
			 					value="<?php echo htmlspecialchars($Projet_idProjet); ?>">
			 					</input>
								<input border=0 src="images/button-cancel.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form>
						</td> 
						<td> 					
							
							<form action="editions/edElAPPRPDF.php" method="post">

			 					<input type="hidden" name="Appli_idAppli" 
								value="<?php echo htmlspecialchars($Appli_idAppli); ?>">
			 					</input>
			 					<input type="hidden" name="Projet_idProjet"
								value="<?php echo htmlspecialchars($Projet_idProjet); ?>">
								</input>
						
								<input type="hidden" name="nomAppli" 
								value="<?php echo htmlspecialchars($nomAppli); ?>">
			 					</input>
			 		
								<input type="hidden" name="nomProjet" 
								value="<?php echo htmlspecialchars($nomProjet); ?>">
								</input>
								
								
			 					<input border=0 src="images/pdficon.jpg" 
								type=image value=submit name = "soumet" align="left" 
								height="20" width="20">
								</input>
										
							</form>
						</td>  							
					</tr>			
										
							
				<?php 
				}
				$query = null;
				?>
			</table>
		</fieldset>

		</div> <!-- principal-->
	
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
