<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Applications et bases de données
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
	<h3>Utilisation</h3>
			
			
			<p> vérifier le message "ajout ... fait"</p>
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5>Gestion des rattachements application et bases de données </h5>
			
			
			
			<br></br>
			<h2>Validation de l'ajout du rattachement applications et base de données </h2>		
			
			<?php include('conAjAPBD.php'); ?> 	
				
			
				
			
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->


</div><!-- #global -->

</body>
</html>
