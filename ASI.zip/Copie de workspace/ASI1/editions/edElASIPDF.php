<?php
require_once('../include/fpdf181/fpdf.php');

class PDF extends FPDF
{
function Header()
{
    global $titre;

    // Arial gras 15
    $this->SetFont('Arial','B',15);
    // Calcul de la largeur du titre et positionnement
    $w = $this->GetStringWidth($titre)+6;
    $this->SetX((210-$w)/2);
    // Couleurs du cadre, du fond et du texte
    $this->SetDrawColor(0,80,180);
    $this->SetFillColor(255,255,255);
    $this->SetTextColor(50,0,0);
    // Epaisseur du cadre (1 mm)
    $this->SetLineWidth(1);
    // Titre
    $this->Cell($w,9,$titre,1,1,'C',true);
    // Saut de ligne
    $this->Ln(10);
}

function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Arial italique 8
    $this->SetFont('Arial','I',8);
    // Couleur du texte en gris
    $this->SetTextColor(128);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
}

function TitreChapitre($num, $libelle)
{
    // Arial 12
    $this->SetFont('Arial','',12);
    // Couleur de fond
    $this->SetFillColor(200,220,255);
    // Titre
    $this->Cell(0,6,$libelle,0,1,'L',true);
    // Saut de ligne
    $this->Ln(4);
}

function CorpsChapitre()
{
    // Lecture du contenuFiche texte
    
  
    // $txt = "Identificateur : ".$_POST['idAsi'];
    // Times 12
    // $this->SetFont('Times','',12);
    // Sortie du texte justifié
    // $this->MultiCell(0,5,$txt);
    // Saut de ligne
	// $this->Ln();
	
	$txt = "Nom de l'ASI: ";
	$arg = $_POST['nomAsi'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
     
    $txt = "Prenom de l'ASI : ";
    $arg= $_POST['prenomAsi'];
    $arg=substr($arg, 0, 62);
    $txtutf8 = utf8_decode($txt);
    $this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
    
    $txt = "Téléphone de l'ASI : ";
    $arg = $_POST['telephoneAsi'];
    $arg=substr($arg, 0, 62);
    $txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
    
    $txt = "Email de l'ASI : ";
    $arg = $_POST['emailAsi'];
    $arg=substr($arg, 0, 62);
   	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
 
    $txt = "Complément : ";
    $arg = $_POST['idAutreIdentASI'];
    $arg=substr($arg, 0, 62);
    $txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
    
 	$txt = "Accés LDAP : ";
 	$arg = $_POST['accesLDAP'];
 	$arg=substr($arg, 0, 62);
 	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Sda LDAP : ";
	$arg = $_POST['sdaLDAP'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
    // Saut de ligne
    $this->Ln();
    
   
    // Mention en italique
    $this->SetFont('','I');
    $this->Cell(0,5,"(fin de la Fiche)");
}

function AjouterChapitre($num, $titre)
{
    $this->AddPage();
    $this->TitreChapitre($num,$titre);
    $this->CorpsChapitre();
}
}

$pdf = new PDF();
$titre = "Fiche d'un ASI";
$pdf->SetTitle($titre);
$idAsi = $_POST["idAsi"];

$pdf->AjouterChapitre(1,'Contenu de la fiche');


$pdf->Output();
?>