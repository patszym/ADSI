	
<?php
require_once('../include/fpdf181/fpdf.php');

class PDF extends FPDF
{
// En-tête
function Header()
{
    // Logo
    $this->Image('../images/acaCreteil.jpg',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $titre = "Application et Projet";
    $titreutf8 = utf8_decode($titre);
    $this->Cell(80,10,$titreutf8,1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

// Instanciation de la classe dérivée
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',14);
$header=array('Application ','Projet');
$entete1 = "Application";
$entete2 = "Projet";

$entete1utf8 = utf8_decode($entete1);
$entete2utf8 = utf8_decode($entete2);
$pdf->Cell(51,7,$entete1utf8,1,0,'C');
$pdf->Cell(130,7,$entete2utf8,1,0,'C');
$pdf->Ln();
	include_once "../include/connBase.php" ; 
	
	$sql = 'select APPLI_idAPPLI, nomAPPLI, 
					nomPROJET
					from APPLI_has_PROJET, APPLI, PROJET
					where APPLI_idAPPLI = idAPPLI and
							PROJET_idPROJET = idPROJET
					order by nomAPPLI, nomPROJET';
	
	include_once "../include/edConV1.php";
	
	
	$i = 0 ;
	
	while ($i<$maxRow) 
	{
		$arg0 =  $tableauEd [$i][0] ;
		$arg1 =  $tableauEd [$i][1] ;
		$arg1=substr($arg1, 0, 13);  
		$arg2 =  $tableauEd [$i][2] ;
		
	
		$i++;
		// Exploitation des lignes dans l'édition 
		
		
		
		$pdf->Cell(51,6,$arg1,'LR');
		
		$pdf->Cell(130,6,$arg2,'LR');
		
		$pdf->Ln();

	}
	$query = null;


$pdf->Cell(16,6,"",'T');
$pdf->Cell(35,6,"",'T');
$pdf->Cell(130,6,"",'T');

$pdf->Output();
?>