<?php
require_once('../include/fpdf181/fpdf.php');

class PDF extends FPDF
{
function Header()
{
    global $titre;

    // Arial gras 15
    $this->SetFont('Arial','B',15);
    // Calcul de la largeur du titre et positionnement
    $w = $this->GetStringWidth($titre)+6;
    $this->SetX((210-$w)/2);
    // Couleurs du cadre, du fond et du texte
    $this->SetDrawColor(0,80,180);
    $this->SetFillColor(255,255,255);
    $this->SetTextColor(50,0,0);
    // Epaisseur du cadre (1 mm)
    $this->SetLineWidth(1);
    // Titre
    $this->Cell($w,9,$titre,1,1,'C',true);
    // Saut de ligne
    $this->Ln(10);
}

function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Arial italique 8
    $this->SetFont('Arial','I',8);
    // Couleur du texte en gris
    $this->SetTextColor(128);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
}

function TitreChapitre($num, $libelle)
{
    // Arial 12
    $this->SetFont('Arial','',12);
    // Couleur de fond
    $this->SetFillColor(200,220,255);
    // Titre
    $this->Cell(0,6,$libelle,0,1,'L',true);
    // Saut de ligne
    $this->Ln(4);
}

function CorpsChapitre()
{
    // Lecture du contenuFiche texte
    
  
    // $txt = "Identificateur : ".$_POST['idAppli'];
    // Times 12
    // $this->SetFont('Times','',12);
    // Sortie du texte justifié
    // $this->MultiCell(0,5,$txt);
    // Saut de ligne
	// $this->Ln();
	
	$txt = "Libellé court de la Division: ";
	$arg = $_POST['libelleCourtDivision'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Nom de l'organisme de diffusion: ";
	$arg = $_POST['nomDiffusion'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Nom de l'application : ";
	$arg = $_POST['nomAppli'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
     
    $txt = "Libellé de l'application : ";
    $arg= $_POST['libelleAppli'];
    $arg=substr($arg, 0, 62);
    $txtutf8 = utf8_decode($txt);
    $this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
  
	$txt = "URL de présentation de l'application : ";
	$arg= $_POST['urlPresAppli'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Type d'application : ";
	$arg= $_POST['libTypeAppli'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Nom de l'académie effectuant la maintenance : ";
	$arg= $_POST['nomAca'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Prestataire extérieur le cas échéant : ";
	$arg= $_POST['prestataireAppli'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
   
	$txt = "Date de diffusion de l'application : ";
	$arg = $_POST['dDiffusAppli'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Date de début de l'application : ";
	$arg = $_POST['dDebutAppli'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Date de fin de l'application : ";
	$arg = $_POST['dFinAppli'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Date de prise en charge de l'application : ";
	$arg = $_POST['dFinAppli'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Date d'installation de l'application : ";
	$arg = $_POST['dInstallationAppli'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Date de mise à disposition de l'application : ";
	$arg = $_POST['dMiseADispoAppli'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Domaine fonctionnel de l'application : ";
	$arg= $_POST['domFoncAppli'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	
	$txt = "Login de l'application : ";
	$arg= $_POST['loginAppli'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	
	
    // Saut de ligne
    $this->Ln();
    
   
    // Mention en italique
    $this->SetFont('','I');
    $this->Cell(0,5,"(fin de la Fiche)");
}

function AjouterChapitre($num, $titre)
{
    $this->AddPage();
    $this->TitreChapitre($num,$titre);
    $this->CorpsChapitre();
}
}

$pdf = new PDF();
$titre = "Fiche d'une application";
$pdf->SetTitle($titre);
$idAppli = $_POST["idAppli"];

$pdf->AjouterChapitre(1,'Contenu de la fiche');


$pdf->Output();
?>