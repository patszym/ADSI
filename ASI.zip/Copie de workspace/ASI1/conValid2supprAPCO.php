<?php	
			  
if(!empty($_POST["soumet"]))
{
					
					
					if(!empty($_POST["Appli_idAppli"]))
					{
						$Appli_idAppli=$_POST["Appli_idAppli"];
						
					}
					if(!empty($_POST["Contact_idContact"]))
					{
						$Contact_idContact=$_POST["Contact_idContact"];
						
					}
					
					
					
					include('include/connBase.php');
					
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					
						$sql = 'DELETE FROM CONTACT_has_APPLI
								WHERE APPLI_idAPPLI = :Appli_idAppli 
						AND CONTACT_idCONTACT = :Contact_idContact ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':Appli_idAppli', $Appli_idAppli, PDO::PARAM_INT);
						$sth->bindValue(':Contact_idContact', $Contact_idContact, PDO::PARAM_INT);
						$sth->execute();
						
						echo "Validation de la suppression faite";
				
					} catch (Exception $e) {
					
						echo "la suppression a échouée: " . $e->getMessage();
					}
				
}
			
				
			?>	