<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Acteurs de la maîtrise d'oeuvre
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	
</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> Il faut valider l'ajout pour achever la tâche (bouton <b> valider </b>)</p>
			
			<p>Cliquez sur l'onglet <b>Liste et Edition </b> pour une consultation, 
			une modification, ou une suppression </p>
			<p> Cliquez sur l'onglet <b> Ajout </b> pour créer une occurence de Moa</p>
			
	</div><!-- #secondaire -->

	<div id="principal"> 
			<h5>Gestion des acteurs de la maîtrise d'oeuvre </h5>
			
		
			<div id="tabsF">
				<?php include('include/MHMOA.php'); ?> 
				<?php $idRowDivision = null ; ?>
				
				<?php include('include/con1MOADV.php'); ?>
			<fieldset class="saisie">
		
			<form name="ajMoa" id="ajMoaForm" method="post"
				 enctype="multipart/form-data" 
					action="ajMOA2.php">
					
				<table BORDER=0>	
					<!-- ajout Moa - formulaire -->
				
					<td>Division :</td>
						<td>
						 <select   name="idDivision">
							<?php
							
							$i = 0;
							while ($i<$index1)
							{
					
								 	echo '<option value="'.
										$tableau1 [$i][0].'"'.$tableau1 [$i][2].'>'.
										$tableau1 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</Tr>
					<tr>
					<tr>
						<td> Nom de l'acteur de la maîtrise d'ouvrage :</td>
						<td>
							<input type="text" name="nomMoa" 
							value="" required="required" maxlength="30" 
							autofocus size="30">
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Prénom de l'acteur de la maîtrise d'ouvrage :</td>
						<td>
							<input type="text" name="prenomMoa" 
							value="" required="required" maxlength="30" size="30">
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Email de l'acteur de la maîtrise d'ouvrage :</td>
						<td>
							<input type="text" name="emailMoa" 
							value="" required="required" maxlength="80" size="50">
							</input>
						</td>
					</tr>					
					<tr>
						<td> Téléphone fixe de l'acteur de la maîtrise d'ouvrage :</td>
						<td>
							<input type="text" name="telFixeMoa" 
							value="" required="required" maxlength="10" size="10">
						</td>
					</tr>
					
					<tr>
						<td>  Téléphone mobile de l'acteur de la maîtrise d'ouvrage :</td>
						<td>
							<input type="text" name="telMobMoa" 
							value="" required="required" maxlength="10" size="10">
							</input>
						</td>
					</tr>
					<tr>
					
						<td>	
					<input type="submit" value="Valider" name="soumet">
					</input>
						</td>
								
						<td>
					<input type="submit" value="Annuler">
					</input>
						
					
						</td>
					</tr>
						
					
				</table>		
					
			</form>
			
		</fieldset>
		</div>
	</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	

</div><!-- #global -->

</body>
</html>
