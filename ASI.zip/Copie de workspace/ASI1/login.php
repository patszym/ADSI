<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Login administrateur
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	
</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
		<a href="logout.php">Deconnexion</a>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

	<div id="principal"> 
			<h5>Login Administrateur</h5>
			
			
			
				
			<fieldset class="saisie">
			
			<form name="logAdm" id="logAdmForm" method="post"
				 enctype="multipart/form-data" 
					action="login2.php">
					
				<table BORDER=0>	
					<!-- ajout Adm - formulaire -->
				
					
					<tr>
						<td> Login administrateur:</td>
						<td>
							<input type="text" name="loginAdm" value="" 
							 maxlength="20" size="20" autofocus>
							</input>
						</td>
					</tr>
					<tr>
						<td> mot de passe :</td>
						<td>
							<input type="password" name="mdpAdm" value="" 
							 maxlength="20" size="20">
							</input>
						</td>
					</tr>
					
					<tr>
						<td>
					
							
					<input type="submit" value="Valider" name="soumet">
					</input>
						</td>
						<td>			
					
					<input type="submit" value="Annuler">
					</input>
						
					
						</td>
					</tr>
						
					
				</table>		
					
			</form>
		
		</fieldset>
		
	</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	

</div><!-- #global -->

</body>
</html>
