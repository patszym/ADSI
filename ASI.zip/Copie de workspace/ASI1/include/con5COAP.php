<?php 
	include('include/connBase.php');
	if (!empty( $_POST['soumet'] ))
	{				
					if(!empty($_POST["idContact"]))
					{
						$Contact_idContact=$_POST["idContact"];
					} else
					{
						$Contact_idContact = 0;
					}
						
		try {
				$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$dbh->beginTransaction();
				$sql = 'DELETE FROM CONTACT_has_APPLI
								WHERE CONTACT_idCONTACT = :Contact_idContact ';
						$sth = $dbh->prepare($sql);
							
						$sth->bindValue(':Contact_idContact', $Contact_idContact, PDO::PARAM_INT);
						$sth->execute();
					
			
				if (isset($_POST['idAp']))
				
				{
					
					foreach($_POST['idAp'] as $idAp)
					{
					
						$Appli_idAppli = $idAp;
						$sql = 'insert into CONTACT_has_APPLI values ('.$Contact_idContact.','
								.$Appli_idAppli.');'   ;
									
								$dbh->exec($sql);
					}
				}
				$dbh->commit();
				echo "la mise à jour a été faite";
			} catch (Exception $e) {
					$dbh->rollBack();
					echo "la mise à jour a échouée: " . $e->getMessage();
				}
				
			
			
	}

?>
				
			