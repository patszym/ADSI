<?php 
if (ISSET($idUti))
{
		
			
				include('include/connBase.php');
				// on crée la requête SQL
				
				
				$sql = 'SELECT idAPPLI, nomAPPLI'; 
				$sql = $sql .'	FROM APPLI';
				
				
				
				$sql = $sql.' ORDER BY nomAPPLI ';
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				
				$query->execute();
			
				$tableau1 = array();
				$index1 = 0;
				// Parcours des résultats
				
				while ($row = $query->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
				{
					
					$arg0 = $row [0];
					$idAppli = $arg0;
					
					$arg1 = $row [1] ;
					
					$arg2=false;
					
					$tableau1[$index1][2] = false;
						
					// Recherche de l'appli en cas de sélection déjà faite,
					
				
						$sql5 = 'SELECT APPLI_idAPPLI ';
						$sql5 = $sql5 .' FROM APPLI_has_UTI ';
						$sql5=$sql5.' WHERE APPLI_has_UTI.UTI_idUTI = :idUti ';
						$sql5=$sql5.' AND APPLI_has_UTI.APPLI_idAPPLI = :idAppli ';
								$sql5=$sql5.'LIMIT 1';
						 // echo $sql5;
						$query5 = $dbh->prepare($sql5, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
					
							
						$query5->bindParam(':idUti', $idUti, PDO::PARAM_INT);
						$query5->bindParam(':idAppli', $idAppli, PDO::PARAM_INT);
					
						$query5->execute();
					
						while ($row5 = $query5->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
						{
							
							$ar0 = $row5 [0];
						
							if ($ar0 == $arg0) 
							{
								$arg2 = true;
								
							}
							
						}
						
						
				
					
					// Parcours des résultats
					
					// -----------------------------------
					
					
					
					$tableau1[$index1] = array($arg0,$arg1,$arg2);
					
					$index1++;
					
				
				}
				
	}		
					
			?> 