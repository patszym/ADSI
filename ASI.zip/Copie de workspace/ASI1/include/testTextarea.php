
<?php 
  //  if ($_POST['submit']) {
        // must work
  //      echo $_POST['contact_list'];
  //  };
?>


 <?php /* and the html */ ?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
       
       <link rel="stylesheet" type="text/css" href="../jquery.cleditor.css" />
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
		<script type="text/javascript" src="../js/CLEditor/jquery.cleditor.min.js"></script>
	<script type="text/javascript">      
		$(document).ready(function() {  $("#input").cleditor();  });  
	</script>
    </head>
    <body>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>">
        <textarea>Easy (and free!) 
			You should check out our premium features.</textarea>
            <textarea id="contact_list" name="contact_list"></textarea>
            <input type="submit" name="submit" value="Send" id="submit"/>
        </form>
    </body>
</html>