	
<ul>
<li><a href="edASI.php" title="Liste et Edition"><span>Liste et Edition</span></a></li>

<li><a href="ajASI.php" title="Ajout"><span>Ajout</span></a></li>

</ul>
