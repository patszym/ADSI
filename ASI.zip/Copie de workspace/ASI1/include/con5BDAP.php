<?php 

	include('include/connBase.php');
	
	if (!empty( $_POST['soumet'] ))
	
	{
	
		
					if(!empty($_POST["idBasdon"]))
					{
						$Basdon_idBasdon=$_POST["idBasdon"];
					} else
					{
						$Basdon_idBasdon = 0;
					}
						
	try {
			$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$dbh->beginTransaction();
			$sql = 'DELETE FROM APPLI_has_BASDON
								WHERE BASDON_idBASDON = :Basdon_idBasdon ';
						$sth = $dbh->prepare($sql);
							
						$sth->bindValue(':Basdon_idBasdon', $Basdon_idBasdon, PDO::PARAM_INT);
						$sth->execute();
					
			
				if (ISSET($_POST['idAp']))
				{
					$size = count($_POST['idAp']);
					$i = 0;
					while ($i < $size)
					{
						
						
						if (!empty($_POST['idAp'][$i]))
						{
							$idAppli = $_POST['idAp'][$i] ;
							
							$indicAppli_has_Basdon = 0;
							
							if(ISSET($_POST["indMAJBD"]))
							{
								if(!empty($_POST["indMAJBD"][$i]))
								{
									if ($_POST["indMAJBD"][$i]==$_POST['idAp'][$i] )
									{
									
										
											$indicAppli_has_Basdon = 1;
									
									}
								}
								if ($indicAppli_has_Basdon==0)
								{
									$indicAppli_has_Basdon==1;
								}
								else 
								{
									$indicAppli_has_Basdon==0;
								}
								
							}
							
							
							$Appli_idAppli = $idAppli;
							$sql = 'insert into APPLI_has_BASDON values ('.$Appli_idAppli.','
								.$Basdon_idBasdon.','.$indicAppli_has_Basdon.');'   ;
							
						
								$dbh->exec($sql);
								$i++;
				
						}
					}
				}
					
					
				
			
				$dbh->commit();
				echo "la mise à jour a été faite";
					
			} catch (Exception $e) {
					$dbh->rollBack();
					echo "la mise à jour a échouée: " . $e->getMessage();
			}
			
			
	}

?>
				
			