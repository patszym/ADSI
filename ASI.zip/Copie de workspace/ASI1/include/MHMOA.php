	
<ul>
<li><a href="edMOA.php" title="Liste et Edition"><span>Liste et Edition</span></a></li>

<li><a href="ajMOA.php" title="Ajout"><span>Ajout</span></a></li>

</ul>
