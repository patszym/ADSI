<?php 
				/* initialisations : */
			
				
				$validId = true;
				
			
				
				
				if(!empty($_POST["idProjet"]))
				{
					$idProjet = $_POST['idProjet'];
					/// $idProjet = filter_var($idProjet), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idProjet))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idProjet = $_POST['idProjet'];
					
				} else {
					$idProjet = null;
					
				}
				
				
				if ($validId == true) 
				{
					
						$authorise = true;
						$tableauPR4 = array();
						$maxRow4 = 0 ;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  APPLI.nomAPPLI, DIFFUSION.nomDIFFUSION, 
					 		CONTACT.nomCONTACT, CONTACT.prenomCONTACT, 
								CONTACT.idCONTACT
					 	
						FROM  APPLI,  APPLI_has_PROJET, CONTACT_has_APPLI, DIFFUSION, CONTACT, PROJET
					 		
    					WHERE PROJET.idPROJET  = :idProjet
					 		
					 		AND APPLI_has_PROJET.PROJET_idPROJET = PROJET.idPROJET
					 		
					 		AND APPLI_has_PROJET.APPLI_idAPPLI = APPLI.idAPPLI
					 		
					 		AND APPLI.DIFFUSION_idDIFFUSION = DIFFUSION.idDIFFUSION
					 		
					 		AND DIFFUSION.idDIFFUSION = CONTACT.DIFFUSION_idDIFFUSION
					 		
					 		AND CONTACT_has_APPLI.APPLI_idAPPLI = APPLI.idAPPLI
					 		
					 		AND CONTACT_has_APPLI.CONTACT_idCONTACT = CONTACT.idCONTACT
					 		
					 	
					 		
					 		";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idProjet, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idProjet' => $idProjet));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								$arg0 = $row [0];
								$arg1 = $row [1];
								$arg2 = $row [2];
								$arg3 = $row [3];
								$arg4 = $row [4];
									
								$tableauPR4[$maxRow4] = array($arg0,$arg1,$arg2, $arg3, $arg4);
								$maxRow4++;
								
							}
						
					
					
				}
				
					
			?> 