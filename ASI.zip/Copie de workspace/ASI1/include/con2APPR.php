<?php 
				/* initialisations : */
			
				
				$validId = true;
				
				if(!empty($_POST["Appli_idAppli"]))
				{
					$Appli_idAppli = $_POST['Appli_idAppli'];
					/// $idAppli = filter_var($idAppli), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($Appli_idAppli))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$Appli_idAppli = $_POST['Appli_idAppli'];
					
				} else {
					$Appli_idAppli = null;
					
				}
				if(!empty($_POST["Projet_idProjet"]))
				{
					$Projet_idProjet = $_POST['Projet_idProjet'];
					/// $idAppli = filter_var($idAppli), FILTER_SANITIZE_NUMBER_INT);
						
					if (is_numeric($Projet_idProjet))
					{
						$validId = true;
					} else {
						$validId = false;
				
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$Projet_idProjet = $_POST['Projet_idProjet'];
					
				} else {
					$Projet_idProjet = null;
									
				}
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="select APPLI_idAPPLI, PROJET_idPROJET
						from APPLI_has_PROJET
							where APPLI_idAPPLI = :Appli_idAppli
							and PROJET_idPROJET = :Projet_idProjet
						";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindValue(':Appli_idAppli', $Appli_idAppli, PDO::PARAM_INT);
						$sth->bindValue(':Projet_idProjet', $Projet_idProjet, PDO::PARAM_INT);
						
						try {
						$sth->execute();
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								
								if (!empty ($row['APPLI_idAPPLI']))
								{
									$idRowAppli=$row['APPLI_idAPPLI'];
									$Appli_idAppli = $idRowAppli;
								}
								else
								{
									$idRowAppli=null;
									$Appli_idAppli = null;
								}
								
								if (!empty ($row['PROJET_idPROJET']))
								{
									$idRowProjet=$row['PROJET_idPROJET'];
									$Projet_idProjet = $idRowProjet;
								}
								else
								{
									$idRowProjet=null;
									$Projet_idProjet = null;
								}
								
								
									
								
								
							}
						
					
					
				}
				
					
			?> 