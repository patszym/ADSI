		<div id="navigation">
			<ul>
				<li><a href="index1.php">Accueil</a></li>
				<li><a href="logout.php">Déconnection</a></li>
				<li><a href="edAD.php">Administrateurs</a></li>
				<li><a href="edUT.php">Utilisateurs</a></li>
				<li><a href="edDI.php">Diffusion</a></li>
				<li><a href="edCO.php">Contacts de la diffusion</a></li>
				<li><a href="edBD.php">Bases de données</a></li>
				<li><a href="edPR.php">Projets</a></li>
				<li><a href="edDV.php">Divisions</a></li>
				<li><a href="edMOA.php">Maîtrise d'ouvrage</a></li>
				<li><a href="edAP.php">Applications</a></li>
				<li><a href="edCY.php">Cycles</a></li>
			</ul>
		</div><!-- #navigation    -->