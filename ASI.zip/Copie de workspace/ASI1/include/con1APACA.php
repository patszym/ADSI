<?php 
		$chaine = 
"Académie le cas échéant;000.
Paris;001.
Aix-Marseille;002.
Besançon;003.
Bordeaux;004.
Caen;005.
Clermont-Ferrand;006.
Dijon;007.
Grenoble;008.
Lille;009.
Lyon;010.
Montpellier;011.
Nancy-Metz;012.
Poitiers;013.
Rennes;014.
Strasbourg;015.
Toulouse;016.
Nantes;017.
Orléans-Tours;018.
Reims;019.
Amiens;020.
Rouen;021.
Limoges;022.
Nice;023.
Créteil;024.
Versailles;025.
Corse;027.
Réunion;028.
Martinique;031.
Guadeloupe;032.
Guyane;033.
Nouvelle Calédonie;040.
Polynésie Française;041.
Wallis et Futuna;042.
Mayotte;043.
St Pierre et Miquelon;044";	
				
				$tableau1 = array();
				$tableau1 = explode(".",$chaine);
				$index1 = 0;
				// Parcours des académies
				
				while (isset($tableau1[$index1]))
				{
					
					$row = explode(";",$tableau1[$index1]);
					$arg0 = $row [1];
					
					$arg1 = $row [0] ;
					
					$arg2=null;
					$tableau1[$index1][2] = null;
					if ($idRowAcaAppli == $arg0)
					{
						$arg2 = "selected";
						$nomAca = $arg1;
					}
					$tableau1[$index1] = array($arg0,$arg1,$arg2);
					
					$index1++;
					// $u représente l'utilisateur courant du jeu de résultats
					// La forme prise par $u pour représenter ce résultat est vue ci-dessous
				
				}
				
				
					
			?> 