<?php 
				/* initialisations : */
			
				
				$validId = true;
				
				
				
				if(!empty($_POST["idProjet"]))
				{
					$idProjet = $_POST['idProjet'];
					/// $idProjet = filter_var($idProjet), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idProjet))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idProjet = $_POST['idProjet'];
					
				} else {
					$idProjet = null;
					
				}
				
				
				if ($validId == true) 
				{
					
						$authorise = true;
						$tableauPR3 = array();
						$maxRow3 = 0 ;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  APPLI.nomAPPLI, BASDON.nomBASDON, 
								indicAPPLI_has_BASDON, BASDON.idBASDON
					 	
						FROM  APPLI, APPLI_has_BASDON, APPLI_has_PROJET, BASDON, PROJET
					 		
    					WHERE PROJET.idPROJET  = :idProjet
					 		
					 		AND APPLI_has_PROJET.PROJET_idPROJET = PROJET.idPROJET
					 		
					 		AND APPLI_has_PROJET.APPLI_idAPPLI = APPLI.idAPPLI
					 		
					 		AND APPLI_has_BASDON.APPLI_idAPPLI = APPLI.idAPPLI
					 		
					 		AND APPLI_has_BASDON.BASDON_idBASDON = BASDON.idBASDON
					 		
					 		";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idProjet, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idProjet' => $idProjet));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								$arg0 = $row [0];
								$arg1 = $row [1];
								$arg3 = null;
								if ($row [2]== 1) $arg2 = "en Consultation excl.";	
								if ($row [2]== 2) $arg2 = "en mise à jour";
								$arg3 = $row [3];
								$tableauPR3[$maxRow3] = array($arg0,$arg1,$arg2, $arg3);
								$maxRow3++;
								
							}
						
					
					
				}
				
					
			?> 