<?php
/* initialisations : */


include('include/connBase.php');
$validId = false;

session_start();
if(isset($_SESSION["idAdm"]))
{
	if(!empty($_SESSION["idAdm"]))
	{
		$idAdm = $_SESSION['idAdm'];
		$validId = true;
	}
}
if(isset($_SESSION["adm"]))
{
	if(!empty($_SESSION["adm"]))
	{
		$adm = $_SESSION['adm'];
		
	}
}
if(isset($_SESSION["ses_id"]))
{
	if(!empty($_SESSION["ses_id"]))
	{
		$ses_id = $_SESSION['ses_id'];

	}
}
if ($validId == true)
{

	
	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$sql="SELECT  idADM, loginADM, mdpADM
	FROM ADM ";
	
if (!empty($adm))
{
		$sql = $sql . " WHERE "."idADM = :idAdm";
		$sql = $sql." LIMIT 1";
		$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
		$sth->bindValue(':idAdm', $idAdm, PDO::PARAM_INT);
			
	
		
	// echo $sql;
	try {
		$sth->execute();
			
	} catch (PDOException $e) {
		echo 'la recherche du login a échouée : ' . $e->getMessage();
			
	}
	while ($row = $sth->fetch())
		
	{

		if (!empty ($row['idADM']))
		{
			$idAdm=$row['idADM'];
			
		}
		else
		{
			$idAdm=null;
		}
		
		if (!empty ($row['loginADM']))
		{
			$loginAdm=$row['loginADM'];

		}
		else
		{
			$loginAdm=null;
		}
		if (!empty ($row['mdpADM']))
		{
			$mdpAdm=$row['mdpADM'];

		}
		else
		{
			$mdpAdm=null;
		}
	

	}
	
}

		
		
}

	
?>