<?php
function access($access, $sda)
   {
      $http = explode("/", $_SERVER['HTTP_REFERER']);
       if ($http[2] == "intranet.in.ac-creteil.fr" or $http[2] == "externet.ac-creteil.fr" or $http[2] == "sconet.in.ac-creteil.fr")
        {
            require_once("../classes/Rsa.php");
            require_once("../classes/classLdap.php");

            $headers = apache_request_headers();
            //    var_dump($headers);
            $condition = "";
            switch ($access)
            {
                case 'ADSI1':
                    $groupe[] = "sda-adsi";
                    $redirect = "admin/index.php";
                    $this->_oVar->setSession('accessGroup', 'adsi');
                    $this->_oVar->setSession('sda', 'premiere');
                    $this->_oVar->setSession('vue', 'admin');
                    $this->_oVar->setSession('rneEtab', '0771941S');
                    break;
                case 'SAIO1':
                    $groupe[] = "sda-saio";
                    $redirect = "saio/index.php";
                    $this->_oVar->setSession('accessGroup', 'saio');
                    $this->_oVar->setSession('sda', 'premiere');
                    $this->_oVar->setSession('vue', 'admin');
                    $this->_oVar->setSession('rne', '0941295X');
                    $this->_oVar->setSession('rneEtab', '0771941S');
                    break;
                case 'DIR1':
                    $groupe[] = "sda-eple";
                    $redirect = "chefetablissement/index.php";
                    $this->_oVar->setSession('accessGroup', 'eple');
                    $this->_oVar->setSession('sda', 'premiere');
                    $this->_oVar->setSession('vue', 'chefetablissement');
                    break;
                case 'DSDEN1':
                    $groupe[] = "sda-dsden";
                    $redirect = "dsden/index.php";
                    $this->_oVar->setSession('accessGroup', 'dsden');
                    $this->_oVar->setSession('sda', 'premiere');
                    $this->_oVar->setSession('vue', 'dsden');
                    break;
                case 'CIO1':
                    $condition = array("fonctm" => "ORI");
                    $groupe[] = "sda-cio";
                    $redirect = "cio/index.php";
                    $this->_oVar->setSession('accessGroup', 'cio');
                    $this->_oVar->setSession('sda', 'premiere');
                    $this->_oVar->setSession('vue', 'cio');
                    break;

                case 'ADSI3':
                    $groupe[] = "sda-adsi";
                    $redirect = "admin/index.php";
                    $this->_oVar->setSession('accessGroup', 'adsi');
                    $this->_oVar->setSession('sda', '3eme');
	                $this->_oVar->setSession('rneEtab', '0771941S');
	                $this->_oVar->setSession('vue', 'admin');
	                break;
	            case 'SAIO3':
	                $groupe[] = "sda-saio";
	                $redirect = "saio/index.php";
	                $this->_oVar->setSession('accessGroup', 'saio');
				    $this->_oVar->setSession('sda', '3eme');
				    $this->_oVar->setSession('rneEtab', '0771941S');
				    $this->_oVar->setSession('vue', 'admin');
				    break;
				case 'DIR3':
                    $groupe[] = "sda-eple";
                    $redirect = "chefetablissement/index.php";
                    $this->_oVar->setSession('accessGroup', 'eple');
                    $this->_oVar->setSession('sda', '3eme');
                    $this->_oVar->setSession('vue', 'chefetablissement');
                    break;
                case 'DSDEN3':
                    $groupe[] = "sda-dsden";
                    $redirect = "dsden/index.php";
                    $this->_oVar->setSession('accessGroup', 'dsden');
                    $this->_oVar->setSession('sda', '3eme');
                    $this->_oVar->setSession('vue', 'dsden');
                    break;
                case 'CIO3':
                    $condition = array("fonctm" => "ORI");
                    $groupe[] = "sda-cio";
                    $redirect = "cio/index.php";
                    $this->_oVar->setSession('accessGroup', 'cio');
                    $this->_oVar->setSession('sda', '3eme');
                    $this->_oVar->setSession('vue', 'cio');
                    break;

                default:
                    return header('Location: ../');
            }


          $RSA = new Rsa($headers, "sda", $groupe, $condition);
          
          if ($RSA->auth)
          	 {
 			   $user = $RSA->ct;
               $rne = $RSA->EtabRne;
               $ldap = new LdapTools();
               $ldap->connect() or die($ldap->error);

               if ($ldap->verify($user))
                {
                 if ($RSA->EtabDel)
                     $rne = array_merge($rne, $RSA->EtabDel);
                 $etabs = $RSA->EtabRne;
                 if ($RSA->EtabDel)
                     $etabs = array_merge($etabs, $RSA->EtabDel);
                 if ($RSA->EtabResp)
                   {
                        $result = array_diff($RSA->EtabResp, $etabs);
                        if ($result != '')
                           $etabs = array_merge($etabs, $result);
	               }
	                    if ($RSA->FrEduRne)
	                    {
	                     $result = array_diff($RSA->FrEduRne, $etabs);
	                     if ($result != '')
	                        $etabs = array_merge($etabs, $result);
	                    }
	
	                    $this->_oVar->setSession('etabs', $etabs);
	                 //    $etabs=array_merge($etabs, $RSA->EtabRespEtendu);
	                 //    $etabs=array_merge($etabs, $RSA->EtabRne);
	                    $infoLDAP = $ldap->user;
	                    $this->_oVar->setSession('access', $access);
	                    $this->_oVar->setSession('uid', $user);
	                    $this->_oVar->setSession('rne', $rne[0]);
	
	                    return header("Location: $redirect");
	         }
	       }
	        else
	       {
	            return header('Location: ../../');
	       }
		}
	  else
      {
         return header('Location: http://sda.in.ac-creteil.fr/');
      }
  }
//initialisation
//access("ADSI1");

