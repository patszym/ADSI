<?php
include_once('ConversionDates.class.php');
$dDiffusAppli = null;
if (!empty ($dateDiffusAppli))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateDiffusAppli);
	$conversionDates->convDated();
	$dDiffusAppli = $conversionDates->getdt() ;
}
$dDebutAppli = null;
if (!empty ($dateDebutAppli))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateDebutAppli);
	$conversionDates->convDated();
	$dDebutAppli = $conversionDates->getdt() ;
}
$dFinAppli = null;
if (!empty ($dateFinAppli))
{ 
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateFinAppli);
	$conversionDates->convDated();
	$dFinAppli = $conversionDates->getdt() ;
}
$dPriseEnChargeAppli = null;
if (!empty ($datePriseEnChargeAppli))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePriseEnChargeAppli);
	$conversionDates->convDated();
	$dPriseEnChargeAppli = $conversionDates->getdt() ;
}
$dPriseEnChargeAppli = null;
if (!empty ($datePriseEnChargeAppli))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePriseEnChargeAppli);
	$conversionDates->convDated();
	$dPriseEnChargeAppli = $conversionDates->getdt() ;
}
$dInstallationAppli = null;
if (!empty ($dateInstallationAppli))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateInstallationAppli);
	$conversionDates->convDated();
	$dInstallationAppli = $conversionDates->getdt() ;
}
$dMiseADispoAppli = null;
if (!empty ($dateMiseADispoAppli))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateMiseADispoAppli);
	$conversionDates->convDated();
	$dMiseADispoAppli = $conversionDates->getdt() ;
}
?>