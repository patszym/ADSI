<?php 
				/* initialisations : */
			
				
				$validId = true;
				$idRowDiffusion = null;
				$nomDiffusion = null;
			
				
				$nomContact=null;
				$prenomContact=null;
				$telephoneContact=null;
				$emailContact = null;
				$ssDomFoncContact = null;
				$FonctionnelContact=null;
				$InformatiqueContact=null;
				
				if(!empty($_POST["idContact"]))
				{
					$idContact = $_POST['idContact'];
					/// $idContact = filter_var($idContact), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idContact))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idContact = $_POST['idContact'];
					
				} else {
					$idContact = null;
					
				}
				if (($idContact == null)&&(!empty($_POST['idSelectContact'])))
				{
					$idContact = $_POST['idSelectContact'];
				}
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  CONTACT.DIFFUSION_idDIFFUSION, DIFFUSION.nomDIFFUSION, 
						CONTACT.nomCONTACT,
						CONTACT.prenomCONTACT, 
					 	CONTACT.telephoneCONTACT,
						CONTACT.emailCONTACT,
					 	CONTACT.ssDomFoncCONTACT,
							CONTACT.FonctionnelCONTACT,
							CONTACT.InformatiqueCONTACT
						FROM CONTACT, DIFFUSION
    					WHERE idCONTACT  = :idContact and
							CONTACT.DIFFUSION_idDIFFUSION = DIFFUSION.idDIFFUSION LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idContact, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idContact' => $idContact));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								if (!empty ($row['DIFFUSION_idDIFFUSION']))
								{
									$idRowDiffusion=$row['DIFFUSION_idDIFFUSION'];
								}
								else
								{
									$idRowDiffusion=null;
								}
								
								if (!empty ($row['nomDIFFUSION']))
								{
									$nomDiffusion=$row['nomDIFFUSION'];
								}
								else
								{
									$nomDiffusion=null;
								}
								
								if (!empty ($row['nomCONTACT']))
								{
									$nomContact=$row['nomCONTACT'];
								}
								else 
								{
									$nomContact=null;
								}
								if (!empty ($row['prenomCONTACT']))
								{
									$prenomContact=$row['prenomCONTACT'];
								}
								else
								{
									$prenomContact=null;
								}
								if (!empty ($row['telephoneCONTACT']))
								{
									$telephoneContact=$row['telephoneCONTACT'];
								}
								else
								{
									$telephoneContact=null;
								}
								if (!empty ($row['emailCONTACT']))
								{
									$emailContact=$row['emailCONTACT'];
								}
								else
								{
									$emailContact=null;
								}
								if (!empty ($row['ssDomFoncCONTACT']))
								{
									$ssDomFoncContact=$row['ssDomFoncCONTACT'];
								}
								else
								{
									$ssDomFoncContact=null;
								}
								if (!empty ($row['FonctionnelCONTACT']))
								{
									$FonctionnelContact=$row['FonctionnelCONTACT'];
								}
								else
								{
									$FonctionnelContact=null;
								}
								if (!empty ($row['InformatiqueCONTACT']))
								{
									$InformatiqueContact=$row['InformatiqueCONTACT'];
								}
								else
								{
									$InformatiqueContact=null;
								}
								
								
							}
						
					
					
				}
				
					
			?> 