<?php 
			
				
				include('include/connBase.php');
				// on crée la requête SQL
				
				$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
				$sql = 'SELECT idBASDON, nomBASDON FROM BASDON
				ORDER BY nomBASDON ';
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				$query->execute();
			
				$tableau2 = array();
				$index2 = 0;
				// Parcours des résultats
				
				while ($row = $query->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
				{
					
					$arg0 = $row [0];
					
					$arg1 = $row [1] ;
					
					$arg2=null;
					$tableau2[$index2][2] = null;
					if ($idRowBasdon == $arg0)
					{
						$arg2 = "selected";
						$nomBasdon = $arg1;
					}
					$tableau2[$index2] = array($arg0,$arg1,$arg2);
					
					$index2++;
					// $u représente l'utilisateur courant du jeu de résultats
					// La forme prise par $u pour représenter ce résultat est vue ci-dessous
				
				}
				
				
					
			?> 