<?php 
				/* initialisations : */

				include 'encrypt_decrypt.php';
				
				$validId = true;
				
				
				if(!empty($_POST["idUti"]))
				{
					$idUti = $_POST['idUti'];
					/// $idUti = filter_var($idUti), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idUti))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idUti = $_POST['idUti'];
					
				} else {
					$idUti = null;
					
				}
				if (($idUti == null)&&(!empty($_POST['idSelectUti'])))
				{
					$idUti = $_POST['idSelectUti'];
				}
				
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  nomUTI,
						prenomUTI,
						telephoneUTI,
					 	emailUTI,
						
					 	loginUTI,
							mdpUTI,
							datemodifUTI
						FROM UTI
    					WHERE idUTI  = :idUti LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idUti, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idUti' => $idUti));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								
								if (!empty ($row['nomUTI']))
								{
									$nomUti=$row['nomUTI'];
								}
								else 
								{
									$nomUti=null;
								}
								if (!empty ($row['prenomUTI']))
								{
									$prenomUti=$row['prenomUTI'];
								}
								else
								{
									$prenomUti=null;
								}
								if (!empty ($row['telephoneUTI']))
								{
									$telephoneUti=$row['telephoneUTI'];
								}
								else
								{
									$telephoneUti=null;
								}
								if (!empty ($row['emailUTI']))
								{
									$emailUti=$row['emailUTI'];
								}
								else
								{
									$emailUti=null;
								}
								
								if (!empty ($row['loginUTI']))
								{
									$loginUti=$row['loginUTI'];
								}
								else
								{
									$loginUti=null;
								}
								if (!empty ($row['mdpUTI']))
								{
									$mdpUti=$row['mdpUTI'];
									$encrypted_txt = $mdpUti;
									$decrypted_txt = encrypt_decrypt('decrypt', $encrypted_txt);
								
									$mdpDecryptUti = $decrypted_txt;
									
								}
								else
								{
									$mdpUti=null;
									$mdpDecryptUti = null;
								}
								if (!empty ($row['datemodifUTI']))
								{
									$datemodifUti=$row['datemodifUTI'];
								}
								else
								{
									$datemodifUti=null;
								}
								
								
							}
						
					
					
				}
				
					
			?> 