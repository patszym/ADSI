<?php 
				/* initialisations : */
			
				
				$validId = true;
				$idDivision = null;
				$libelleCourtDivision = null;
			
				
				$nomMoa=null;
				$prenomMoa=null;
				
				$emailMoa = null;
				$telFixeMoa=null;
				$telMobMoa=null;
				
				if(!empty($_POST["idMoa"]))
				{
					$idMoa = $_POST['idMoa'];
					/// $idMoa = filter_var($idMoa), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idMoa))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idMoa = $_POST['idMoa'];
					
				} else {
					$idMoa = null;
					
				}
				if (($idMoa == null)&&(!empty($_POST['idSelectMoa'])))
				{
					$idMoa = $_POST['idSelectMoa'];
				}
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  MOA.DIVISION_idDIVISION, DIVISION.libelleCourtDIVISION, 
						MOA.nomMOA,
						MOA.prenomMOA, 
					 	
						MOA.emailMOA,
					 	MOA.telFixeMOA,
							MOA.telMobMOA
						FROM MOA, DIVISION
    					WHERE idMOA  = :idMoa and
							MOA.DIVISION_idDIVISION = DIVISION.idDIVISION LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idMoa, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idMoa' => $idMoa));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								if (!empty ($row['DIVISION_idDIVISION']))
								{
									$idRowDivision=$row['DIVISION_idDIVISION'];
								}
								else
								{
									$idRowDivision=null;
								}
								
								if (!empty ($row['libelleCourtDIVISION']))
								{
									$libelleCourtDivision=$row['libelleCourtDIVISION'];
								}
								else
								{
									$libelleCourtDivision=null;
								}
								
								if (!empty ($row['nomMOA']))
								{
									$nomMoa=$row['nomMOA'];
								}
								else 
								{
									$nomMoa=null;
								}
								if (!empty ($row['prenomMOA']))
								{
									$prenomMoa=$row['prenomMOA'];
								}
								else
								{
									$prenomMoa=null;
								}
								
								if (!empty ($row['emailMOA']))
								{
									$emailMoa=$row['emailMOA'];
								}
								else
								{
									$emailMoa=null;
								}
								if (!empty ($row['telFixeMOA']))
								{
									$telFixeMoa=$row['telFixeMOA'];
								}
								else
								{
									$telFixeMoa=null;
								}
								if (!empty ($row['telMobMOA']))
								{
									$telMobMoa=$row['telMobMOA'];
								}
								else
								{
									$telMobMoa=null;
								}
							}
						
					
					
				}
				
					
			?> 