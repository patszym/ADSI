
<ul>
<li><a href="edCO.php" title="Liste et Edition"><span>Liste et Edition</span></a></li>

<li><a href="ajCO.php" title="Ajout"><span>Ajout</span></a></li>

</ul>
