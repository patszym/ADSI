<?php 
				/* initialisations : */

				include 'encrypt_decrypt.php';
				
				$validId = true;
				$nomBasdon=null;
				$libelleBasdon=null;
				$servBasdon=null;
				$emplBasdon=null;
				$chemShellBasdon=null;
			
				$loginBasdon=null;
				$mdpBasdon = null;
				
				if(!empty($_POST["idBasdon"]))
				{
					$idBasdon = $_POST['idBasdon'];
					/// $idBasdon = filter_var($idBasdon), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idBasdon))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idBasdon = $_POST['idBasdon'];
					
				} else {
					$idBasdon = null;
					
				}
				if (($idBasdon == null)&&(!empty($_POST['idSelectBasdon'])))
				{
					$idBasdon = $_POST['idSelectBasdon'];
				}
				
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  nomBASDON,
						libelleBASDON, 
					 	servBASDON,
						emplBASDON,
						chemShellBASDON,
					 	loginBASDON,
							mdpBASDON
						FROM BASDON
    					WHERE idBASDON  = :idBasdon LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idBasdon, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idBasdon' => $idBasdon));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								
								if (!empty ($row['nomBASDON']))
								{
									$nomBasdon=$row['nomBASDON'];
								}
								else 
								{
									$nomBasdon=null;
								}
								if (!empty ($row['libelleBASDON']))
								{
									$libelleBasdon=$row['libelleBASDON'];
								}
								else
								{
									$libelleBasdon=null;
								}
								if (!empty ($row['servBASDON']))
								{
									$servBasdon=$row['servBASDON'];
								}
								else
								{
									$servBasdon=null;
								}
								if (!empty ($row['emplBASDON']))
								{
									$emplBasdon=$row['emplBASDON'];
								}
								else
								{
									$emplBasdon=null;
								}
								if (!empty ($row['chemShellBASDON']))
								{
									$chemShellBasdon=$row['chemShellBASDON'];
								}
								else
								{
									$chemShellBasdon=null;
								}
								if (!empty ($row['loginBASDON']))
								{
									$loginBasdon=$row['loginBASDON'];
								}
								else
								{
									$loginBasdon=null;
								}
								if (!empty ($row['mdpBASDON']))
								{
									$mdpBasdon=$row['mdpBASDON'];
									$encrypted_txt = $mdpBasdon;
									$decrypted_txt = encrypt_decrypt('decrypt', $encrypted_txt);
								
									$mdpDecryptBasdon = $decrypted_txt;
									
								}
								else
								{
									$mdpBasdon=null;
									$mdpDecryptBasdon = null;
								}
								
							}
						
					
					
				}
				
					
			?> 