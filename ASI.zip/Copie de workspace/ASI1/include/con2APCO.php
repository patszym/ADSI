<?php 
				/* initialisations : */
			
				
				$validId = true;
				
				if(!empty($_POST["Appli_idAppli"]))
				{
					$Appli_idAppli = $_POST['Appli_idAppli'];
					/// $idAppli = filter_var($idAppli), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($Appli_idAppli))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$Appli_idAppli = $_POST['Appli_idAppli'];
					
				} else {
					$Appli_idAppli = null;
					
				}
				if(!empty($_POST["Contact_idContact"]))
				{
					$Contact_idContact = $_POST['Contact_idContact'];
					/// $idAppli = filter_var($idAppli), FILTER_SANITIZE_NUMBER_INT);
						
					if (is_numeric($Contact_idContact))
					{
						$validId = true;
					} else {
						$validId = false;
				
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$Contact_idContact = $_POST['Contact_idContact'];
					
				} else {
					$Contact_idContact = null;
									
				}
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="select APPLI_idAPPLI, CONTACT_idCONTACT
						from CONTACT_has_APPLI
							where APPLI_idAPPLI = :Appli_idAppli
							and CONTACT_idCONTACT = :Contact_idContact
						";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindValue(':Appli_idAppli', $Appli_idAppli, PDO::PARAM_INT);
						$sth->bindValue(':Contact_idContact', $Contact_idContact, PDO::PARAM_INT);
						
						try {
						$sth->execute();
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								
								if (!empty ($row['APPLI_idAPPLI']))
								{
									$idRowAppli=$row['APPLI_idAPPLI'];
									$Appli_idAppli = $idRowAppli;
								}
								else
								{
									$idRowAppli=null;
									$Appli_idAppli = null;
								}
								
								if (!empty ($row['CONTACT_idCONTACT']))
								{
									$idRowContact=$row['CONTACT_idCONTACT'];
									$Contact_idContact = $idRowContact;
								}
								else
								{
									$idRowContact=null;
									$Contact_idContact = null;
								}
								
								
									
								
								
							}
						
					
					
				}
				
					
			?> 