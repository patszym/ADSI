<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Applis
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> Il faut valider la suppression pour achever la tâche (bouton <b> valider </b>)</p>
			<p>	Cliquez sur l'onglet <b>Liste et Edition </b> pour une consultation, une modification, ou 
			une autre suppression</p>
			<p>	Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence de Appli </p>
		
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5>Gestion des divisions</h5>
			
			<br><br>
			<div id="tabsF">
				<?php include('include/MHAP.php'); ?> 
			</div>
				<?php include('include/con2AP.php'); ?> 
				
				<?php include('include/con1APACA.php'); ?>
				
				<?php include('include/con1APDV.php'); ?>
				
				<?php include('include/con1APDI.php'); ?>
				
			<fieldset class="saisie">
		
			<form name="supprvalidAppli" id="supprvalidAppliForm" method="post"
				 enctype="multipart/form-data" 
					action="valid2supprAP.php">
				<table BORDER=0>		
				
				
				
					<input type="hidden" name="idAppli" 
						value="<?php echo htmlspecialchars($idAppli); ?>">
						</input>
					<tr>
					<td>Division émettant la demande :</td>
						<td>
						 <select   name="idDivision" disabled>
							<?php
							
							$i = 0;
							while ($i<$index2)
							{
					
								 	echo '<option value="'.
										$tableau2 [$i][0].'"'.$tableau2 [$i][2].'>'.
										$tableau2 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
					
					<tr>
					<td>Organisme de diffusion :</td>
						<td>
						 <select   name="idDiffusion" disabled>
							<?php
							
							$i = 0;
							while ($i<$index3)
							{
					
								 	echo '<option value="'.
										$tableau3 [$i][0].'"'.$tableau3 [$i][2].'>'.
										$tableau3 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
					<tr>
					<tr>
						<td> Nom de l'application :</td>
						<td>
							<input type=text name="nomAppli" readonly
							value="<?php echo htmlspecialchars($nomAppli); ?>"
							 maxlength="50" size="50" readonly></input>
						</td>
					</tr>
									
					
					<tr>
						<td> Libellé de l'application :</td>
						<td>
							<input type="text" name="libelleAppli" readonly
							value="<?php echo htmlspecialchars($libelleAppli); ?>" required="required" maxlength="50" size="50">
							</input>
						</td>
					</tr>
					<tr>
						<td>URL de présentation de l'application :</td>
						<td>
							<input type="text" name="urlPresAppli" readonly
							value="<?php echo htmlspecialchars($urlPresAppli); ?>"  maxlength="300" size="50">
							</input>
						</td>
					</tr>
					<tr>
						<td> Type de l'application :</td>
						</td>
						<td>
							<input type="hidden" name="typeAppli" value="0"><br></br></input>
							<input type="radio" name="typeAppli" disabled = "disabled" value="1"
							<?php if ($typeAppli==1): ?>
							checked="checked"
							<?php endif ?>
							> National<br></br></input>
							<input type="radio" name="typeAppli" disabled = "disabled" value="2"
							<?php if ($typeAppli==2): ?>
							checked="checked"
							<?php endif ?>
							> Local<br></br></input>
							<input type="radio" name="typeAppli" disabled = "disabled" value="3"
							<?php if ($typeAppli==3): ?>
							checked="checked"
							<?php endif ?>
							> Autre Académie<br></br></input>
							<input type="radio" name="typeAppli" disabled = "disabled" value="4"
							<?php if ($typeAppli==4): ?>
							checked="checked"
							<?php endif ?>
							> Prestataire externe<br></br></input>
						</td>
					</tr>
					<tr>
					<td>Académie où l'application est maintenue :</td>
						<td>
						 <select   name="idRowAcaAppli" disabled>
							<?php
							
							$i = 0;
							while ($i<$index1)
							{
					
								 	echo '<option value="'.
										$tableau1 [$i][0].'"'.$tableau1 [$i][2].'>'.
										$tableau1 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
					<tr>
						<td>Nom du prestataire le cas échéant :</td>
						<td>
							<input type="text" name="prestataireAppli" readonly
							value="<?php echo htmlspecialchars($prestataireAppli); ?>"  maxlength="300" size="50">
							</input>
						</td>
					</tr>
					<tr>
						<td> Date de diffusion de l'application : </td>
						<td>
							<INPUT type=text id="calendrier1" 
							name="dateDiffusAppli" readonly
							value="<?php echo htmlspecialchars($dDiffusAppli); ?>" maxlength="10" size="10">
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Date de début de l'application :</td>
						<td>
							<INPUT type=text id="calendrier2" 
							name="dateDebutAppli" readonly
							value="<?php echo htmlspecialchars($dDebutAppli); ?>" maxlength="10" size="10">
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Date de fin de l'application : </td>
						<td>
							<INPUT type=text id="calendrier3" 
							name="dateFinAppli" readonly
							value="<?php echo htmlspecialchars($dFinAppli); ?>" maxlength="10" size="10">
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Date de prise en charge :</td>
						<td>
							<INPUT type=text id="calendrier4" 
							name="datePriseEnChargeAppli" readonly
							value="<?php echo htmlspecialchars($dPriseEnChargeAppli); ?>" maxlength="10" size="10">
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Date d'installation : </td>
						<td>
							<INPUT type=text id="calendrier5" 
							name="dateInstallationAppli" readonly
							value="<?php echo htmlspecialchars($dInstallationAppli); ?>" maxlength="10" size="10">
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Date de mise à disposition :</td>
						<td>
							<INPUT type=text id="calendrier6" 
							name="dateMiseADispoAppli" readonly
							value="<?php echo htmlspecialchars($dMiseADispoAppli); ?>" maxlength="10" size="10">
							</input>
						</td>
					</tr>
					
					<tr>
						<td>Domaine fonctionnel de l'application :</td>
						<td>
							<input type="text" name="domFoncAppli" readonly
							value="<?php echo htmlspecialchars($domFoncAppli); ?>" maxlength="100" size="50">
							</input>
						</td>
					</tr>
					
					<tr>
						<td>login administrateur de l'application :</td>
						<td>
							<input type="text" name="loginAppli" readonly
							value="<?php echo htmlspecialchars($loginAppli); ?>"  maxlength="10" size="10">
							</input>
						</td>
					</tr>
					<tr>
						<td> mot de passe :</td>
						<td>
							<input type="text" name="mdpAppli" readonly
							value="<?php echo htmlspecialchars($mdpDecryptAppli); ?>" 
							 maxlength="20" size="20">
							</input>
						</td>
					</tr>
					
				
					<tr>
						<td> 
							
					<input type="submit" value="Valider" name="soumet">
					</input>
						</td>
								
						<td> 
					<input type="submit" value="Annuler">
					</input>
						
				
						</td>
					</tr>
				</table>
			</form>
			
		</fieldset>
			
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
