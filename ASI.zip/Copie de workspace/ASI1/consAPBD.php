<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		divisions
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p>Cliquez sur l'onglet <b>Liste et Edition </b> pour une autre consultation, 
			une modification, ou une suppression </p>
			<p> Cliquez sur l'onglet <b> Ajout </b> pour créer une occurence de AppliBasdon</p>
			
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5>Gestion des rattachements applications et bases de données </h5>
			
			
			
				<?php include('include/con2APBD.php'); ?>
				
				<?php include('include/con1APAP.php'); ?>
				
				<?php include('include/con1APBDBD.php'); ?> 
			<fieldset class="saisie">	
			
					
			<form name="consAppliBasdon" id="consAppliBasdonForm" method="post"
				 enctype="multipart/form-data" 
					action="">
				<table border=0>	
				
					<table BORDER=0>	
					<!-- ajout Contact - formulaire -->
					<tr>
					<td>Application :</td>
						<td>
						 <select   name="Appli_idAppli" disabled>
							<?php
							
							$i = 0;
							while ($i<$index1)
							{
					
								 	echo '<option value="'.
										$tableau1 [$i][0].'"'.$tableau1 [$i][2].'>'.
										$tableau1 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
					<td>Base de données :</td>
						<td>
						 <select   name="Basdon_idBasdon" disabled>
							<?php
							
							$i = 0;
							while ($i<$index2)
							{
					
								 	echo '<option value="'.
										$tableau2 [$i][0].'"'.$tableau2 [$i][2].'>'.
										$tableau2 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
					<tr>
						<td> indicateur action dans la base :</td>
						</td>
						<td>
						
						<?php if (!$indic_Appli_has_Basdon): ?>
						
							<input type="checkbox" name="indic_Appli_has_Basdon" value="1" disabled="disabled"> MAJ Base
							</input>
							<?php else: ?>
							
							<input type="checkbox" name="indic_Appli_has_Basdon" value="1" checked disabled="disabled"> MAJ Base
							</input>
						<?php endif ?>
						</td>
						
					</tr>
				
							
					
					
				</table>	
			</form>
			
			</fieldset>	
			
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	
</div><!-- #global -->

</body>
</html>
