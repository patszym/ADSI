<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		applications - BD
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	
</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
	<h3>Utilisation</h3>
			<p> il faut valider pour poursuivre </p>
	</div><!-- #secondaire -->

	<div id="principal"> 
			<h5>Gestion des rattachements application et base de données</h5>
			
		
				<?php
				
				
				?>
				<?php $idRowAppli = null ; ?>
				<?php include('include/con1APAP.php'); ?>
					<?php $idRowBasdon = null ; ?>
				<?php include('include/con1APBDBD.php'); ?>
			<fieldset class="saisie">
		
			<form name="ajContact" id="ajContactForm" method="post"
				 enctype="multipart/form-data" 
					action="ajAPBD2.php">
					
				<table BORDER=0>	
					<!-- ajout Contact - formulaire -->
					<tr>
					<td>Application :</td>
						<td>
						 <select   name="Appli_idAppli" >
							<?php
							
							$i = 0;
							while ($i<$index1)
							{
					
								 	echo '<option value="'.
										$tableau1 [$i][0].'"'.$tableau1 [$i][2].'>'.
										$tableau1 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
						
					<td>Base de données :</td>
						<td>
						 <select   name="Basdon_idBasdon">
							<?php
							
							$i = 0;
							while ($i<$index2)
							{
					
								 	echo '<option value="'.
										$tableau2 [$i][0].'"'.$tableau2 [$i][2].'>'.
										$tableau2 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
					
					<tr>
						<td> indicateur action dans la base :</td>
						</td>
						<tr>
						
						<td>
							<input type="checkbox" name="indic_Appli_has_Basdon" value="1"> Mise A jour Base
							</input>
						</td>
					</tr>
					
					
					<tr>
						<td>
					
							
					<input type="submit" value="Valider" name="soumet">
					</input>
						</td>		
						<td>
					<input type="submit" value="Annuler">
					</input>
						
					
						</td>
					</tr>
						
					
				</table>		
					
			</form>
			
		</fieldset>
		</div>
	</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	

</div><!-- #global -->

</body>
</html>
