<?php	
			  
				
					$idDiffusion = null;
					
					
					if(!empty($_POST["nomDiffusion"]))
					{
						$nomDiffusion=$_POST["nomDiffusion"];
					} else 
					{ 
						$nomDiffusion = null;
					}
					
					if(!empty($_POST["libelleDiffusion"]))						
					{
						$libelleDiffusion=$_POST["libelleDiffusion"];
					} else
					{
						$libelleDiffusion = null;
					}
					
					if(!empty($_POST["adresseDiffusion"]))
					{
						$adresseDiffusion=$_POST["adresseDiffusion"];
					} else
					{
						$adresseDiffusion = null;
					}
					if(!empty($_POST["codPostDiffusion"]))
					{
						$codPostDiffusion=$_POST["codPostDiffusion"];
					} else
					{
						$codPostDiffusion = null;
					}
					if(!empty($_POST["communeDiffusion"]))
					{
						$communeDiffusion=$_POST["communeDiffusion"];
					} else
					{
						$communeDiffusion = null;
					}
					if(!empty($_POST["nomEtabDiffusion"]))
					{
						$nomEtabDiffusion=$_POST["nomEtabDiffusion"];
					} else
					{
						$nomEtabDiffusion = null;
					}
					
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idDIFFUSION) FROM DIFFUSION ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idDiffusion = $gid->fetchColumn();
					
					
					
					$idDiffusion ++ ;
					
					
					$sql = 'insert into DIFFUSION values ("'.$idDiffusion.'",'.
							'"'.$nomDiffusion.'","'.$libelleDiffusion.'",'.
							'"'.$adresseDiffusion.'",'.
							'"'.$codPostDiffusion.'",'.
							'"'.$communeDiffusion.'",'.
							'"'.$nomEtabDiffusion.'"'.
							');'   ;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
			?>	