<?php	

if(!empty($_POST["soumet"]))
{

					$idDivision = $_POST["idDivision"];
					
					
					if(!empty($_POST["libelleCourtDivision"]))
					{
						$libelleCourtDivision=$_POST["libelleCourtDivision"];
					} else 
					{ 
						$libelleCourtDivision = null;
					}
					
					if(!empty($_POST["libelleLongDivision"]))						
					{
						$libelleLongDivision=$_POST["libelleLongDivision"];
					} else
					{
						$libelleLongDivision = null;
					}
					
				
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE DIVISION SET '.
							' libelleCourtDIVISION ="'.$libelleCourtDivision.'",'.
							' libelleLongDIVISION ="'.$libelleLongDivision.'"'.
							
								' WHERE idDIVISION = :idDivision ';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idDivision', $idDivision, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	