<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Ecran principal Administrateur de ASI
	</title>
	<!-- La feuille de styles "base.css" doit être appeée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
 
  <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script>
  $(function() {
    $( "#accordion" ).accordion();
  });
  </script>
  <script>
  $(function() {
    $( "#menu" ).menu();
  });
  </script>
  <style>
  .ui-menu { width: 150px; }
  </style>
</head>

<body>

<div id="global">

	<div id="entete">
	<?php session_start(); ?> 
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
		
	</div><!-- #entete -->

	<div id="centre">
	 <div id="centre-bis">

		
		
		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
	
			<h3>Utilisation</h3>
			<p>La liste des fonctionnalités est accessible dans la colonne 
			tout à gauche. Cliquer sur l'option choisie.</p>
			<p> Au centre se précisent les définitions des fonctionnalités attendues.</p>
			
		</div><!-- #secondaire -->

		<div id="principal">
		
		<object type="application/msword" data="doc/ME.doc" width="300" height="200">
			<a href="doc/ME.doc">Mode d'emploi</a>
			</object>
			
			<h1><p>Aide pour les fonctionnalités </p> </h1>
		<h3>par ordre de saisie </h3>
		<div id="accordion">
		<h3>Organismes de Diffusion</h3>
  		<div>
    		<p>
    		Gestion des organismes de diffusion: Ajouter, modifier, supprimer ou consulter dans la liste 
			des organismes de diffusion. Les organismes de diffusion déploient à l'échelle nationale l'installation
			et la maintenance de leurs applications. Ce peut être un prestataire de service en logiciels d'entreprise.
    		</p>
  		</div>
  		
  		
  		<h3>Contact fonctionnels et/ou informatiques d'une 
  		cellule de diffusion pour une application</h3>
  		<div>
    		<p>
    		Gestion des contacts fonctionnels et/ou informatiques: Ajouter, modifier, supprimer ou consulter dans la liste 
			des contacts d'une cellule de diffusion.
    		</p>
  		</div>
  		
  		<h3>Administrateurs ou ASI</h3>
  		<div>
    		<p>
    		Gestion des administrateurs ou ASI: Ajouter, modifier, supprimer ou consulter dans la liste 
			des administrateurs du système d'informations. Identification des administrateurs qui maintiennent l'exploitation 
			de l'application en fonction des actes de gestion.
    		</p>
  		</div>
  		<h3>Bases de données : définitions, emplacements, ...</h3>
  		<div>
    		<p>
    		Gestion des bases de données: Ajouter, modifier, supprimer ou consulter dans la liste 
			des bases de données. Une base de données est associée  à une application, 
			et des sauvegardes sont prévisibles à chaque intervention batch sur la base.
    		</p>
  		</div>
  		
  		<h3>Projets</h3>
  		<div>
    		<p>
    		Gestion des projets: Ajouter, modifier, supprimer ou consulter dans la liste 
			des projets du système d'informations. Il s'agit du projet courant pour 
			lequel un administrateur fait l'analyse et/ou la programmation ainsi que l'exploitation ainsi que les tâches de maintenance.
    		</p>
  		</div>
  		<h3>Divisions</h3>
  		<div>
    		<p>
    		Gestion des divisions: Ajouter, modifier, supprimer ou consulter dans la liste 
			des divisions de la structure de l'établissement du lieu d'exercice des administrateurs.
    		</p>
  		</div>
  		<h3>Maîtrise d'ouvrage</h3>
  		<div>
    		<p>
    		Gestion des acteurs de la maitrise d'ouvrage : Ajouter, modifier, supprimer ou consulter dans la liste 
			des MOA du système d'informations. Identification des acteurs référents de la maîtrise d'ouvrage</p>
  		</div>
  		
  		<h3>Applications</h3>
  		<div>
    		<p>
    		Gestion des applications: Ajouter, modifier, supprimer ou consulter dans la liste 
			des applications du système d'informations. Il s'agit de l'application courante pour 
			laquelle un administrateur fait l'exploitation ainsi que les tâches de maintenance.
    		</p>
  		</div>	
  </div>
		
</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<h3> </h3><BR></BR>
		
		<BR></BR>
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
		
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
