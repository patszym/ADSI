<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">


<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>
		Diffusion
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
</meta>
<head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> A l'appel du menu général, le mode <b> Liste et Edition</b> est le mode par défaut</p>
			<p> Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence Diffusion</p>
			<p> Cliquez sur l'image de l'oeil pour voir le détail de la ligne spécifiée en consultation dans la liste</p>
			<p> Cliquez sur l'image du crayon pour voir le détail de la ligne spécifiée en modification dans la liste</p>
			<p> Cliquez sur l'image de la croix pour voir le détail de la ligne spécifiée en suppression dans la liste</p>
			<p>Cliquez sur l'icône <b>PDF</b> pour voir le détail de la ligne en obtenant son édition PDF </p>
			<p>Cliquez sur l'icône <b>PDF</b> à gauche du titre pour obtenir l'édition PDF de la liste</p>
			
	</div><!-- #secondaire -->
		
	<div id="principal"> 
			<h5>Gestion des organismes de Diffusion </h5>
			
			<br>
			<div id="tabsF">
				<?php include('include/MHDI.php'); ?> 
									
			</div>
		
		<fieldset class="saisie">
			<table BORDER=0>
			
			<tr>
			
				<td>
				<a href="editions/edDIPDF.php">
				<img src="images/pdficon.jpg" height="20" width="20" align = "center" 
				alt="PDF">
				</a>
				</td>
				<td>
				<h3>  LISTE DES ORGANISMES DE DIFFUSION </h3>
				</td>
			</tr>
				
				<?php 
				include_once "include/connBase.php" ; 
	
				$sql = 'select idDIFFUSION, nomDIFFUSION, 
					nomEtabDIFFUSION, libelleDIFFUSION, adresseDIFFUSION, codPostDIFFUSION,
					communeDIFFUSION, nomEtabDIFFUSION, nomEtabDIFFUSION
					from DIFFUSION order by nomDIFFUSION';
	
			
				include_once "include/visuConV1.php";
				
				$i = 0 ;
				$idDiffusion = null ;
				$nomDiffusion =  null;
				$nomEtabDiffusion =  null ;
				$libelleDiffusion =  null;
				$adresseDiffusion =  null;
				$codPostDiffusion =  null;
				$communeDiffusion =  null;	
				$nomEtabDiffusion =  null;
				$nomEtabDiffusion =  null;
				while ($i<$maxRow)
				{
					$idDiffusion =  $tableau [$i][0] ;
					$nomDiffusion =  $tableau [$i][1] ;
					$nomEtabDiffusion =  $tableau [$i][2] ;
					$libelleDiffusion =  $tableau [$i][3] ;
					$adresseDiffusion =  $tableau [$i] [4];
					$codPostDiffusion =  $tableau [$i] [5];
					$communeDiffusion =  $tableau [$i] [6];	
					$nomEtabDiffusion =  $tableau [$i] [7];
					$nomEtabDiffusion =  $tableau [$i] [8];
					
					$i++;
					/* Exploitation des lignes dans la liste */
					?>
									
				
				<!-- Liste des  Diffusions - formulaire en lecture -->
													
						
									
						
							<input type="hidden" name="idDiffusion"
							value="<?php echo htmlspecialchars($idDiffusion); ?>"
							></input>
						
					<tr>
														
						<td>
							<input type=text name="nomDiffusion" 
							value="<?php echo htmlspecialchars($nomDiffusion); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
													
													
														
						<td>
							<input type=text name="nomEtabDiffusion" 
							value="<?php echo htmlspecialchars($nomEtabDiffusion); ?>" 
							maxlength="100" size="40" readonly></input>
						</td>
						
						<td>
							<form action="consDI.php" method="post">

			 					<input type="hidden" name="idDiffusion" 
			 					value="<?php echo htmlspecialchars($idDiffusion); ?>">
			 					</input>
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form> 
						</td>
						<td>
							<form action="modifDI.php" method="post">

			 					<input type="hidden" name="idDiffusion" 
			 					value="<?php echo htmlspecialchars($idDiffusion); ?>">
			 					</input>
								<input border=0 src="images/crayon.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form>
						</td>
							<td> 
							<form action="supprDI.php" method="post">

			 					<input type="hidden" name="idDiffusion" 
			 					value="<?php echo htmlspecialchars($idDiffusion); ?>">
			 					</input>
								<input border=0 src="images/button-cancel.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form>
						</td> 
						<td> 					
							
							<form action="editions/edElDIPDF.php" method="post">

			 					<input type="hidden" name="idDiffusion" 
								value="<?php echo htmlspecialchars($idDiffusion); ?>">
			 					</input>
								<input type="hidden" name="nomDiffusion" 
								value="<?php echo htmlspecialchars($nomDiffusion); ?>">
			 					</input>
			 		
								<input type="hidden" name="libelleDiffusion" 
								value="<?php echo htmlspecialchars($libelleDiffusion); ?>">
								</input>
								<input type="hidden" name="adresseDiffusion" 
								value="<?php echo htmlspecialchars($adresseDiffusion); ?>">
								</input>
								<input type="hidden" name="codPostDiffusion" 
								value="<?php echo htmlspecialchars($codPostDiffusion); ?>">
								</input>
								<input type="hidden" name="communeDiffusion" 
								value="<?php echo htmlspecialchars($communeDiffusion); ?>">
								</input>
								<input type="hidden" name="nomEtabDiffusion" 
								value="<?php echo htmlspecialchars($nomEtabDiffusion); ?>">
			 					</input>
			 					<input border=0 src="images/pdficon.jpg" 
								type=image value=submit name = "soumet" align="left" 
								height="20" width="20">
								</input>
										
							</form>
						</td>  							
					</tr>			
										
							
				<?php 
				}
				$query = null;
				?>
			</table>
		</fieldset>

		</div> <!-- principal-->
	
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
