    <?php
    $dir = "blobExtract/";
    $dh  = opendir($dir);
	
    while (false !== ($filename = readdir($dh))) {
	
    	$files[] = $filename;
		if (($filename != ".") and ($filename != "..")) unlink ("blobExtract/".$filename);
    }
     
    sort($files);
    print_r($files);
   
    ?>