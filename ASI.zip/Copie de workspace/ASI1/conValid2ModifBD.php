<?php	
include 'include/encrypt_decrypt.php';
if(!empty($_POST["soumet"]))
{

					$idBasdon = $_POST["idBasdon"];
					
					
					if(!empty($_POST["nomBasdon"]))
					{
						$nomBasdon=$_POST["nomBasdon"];
					} else 
					{ 
						$nomBasdon = null;
					}
					
					if(!empty($_POST["libelleBasdon"]))						
					{
						$libelleBasdon=$_POST["libelleBasdon"];
					} else
					{
						$libelleBasdon = null;
					}
					
					if(!empty($_POST["servBasdon"]))
					{
						$servBasdon=$_POST["servBasdon"];
					} else
					{
						$servBasdon = null;
					}
					if(!empty($_POST["emplBasdon"]))
					{
						$emplBasdon=$_POST["emplBasdon"];
					} else
					{
						$emplBasdon = null;
					}
					if(!empty($_POST["chemShellBasdon"]))
					{
						$chemShellBasdon=$_POST["chemShellBasdon"];
					} else
					{
						$chemShellBasdon = null;
					}
					if(!empty($_POST["loginBasdon"]))
					{
						$loginBasdon=$_POST["loginBasdon"];
					} else
					{
						$loginBasdon = null;
					}
					$mdpChiffreBasdon = null;
					if(!empty($_POST["mdpDecryptBasdon"]))
					{
						$mdpDecryptBasdon=$_POST["mdpDecryptBasdon"];
					
						
						
						$plain_txt = $mdpDecryptBasdon; 

						$encrypted_txt = encrypt_decrypt('encrypt', $plain_txt);
					
							$mdpChiffreBasdon = $encrypted_txt;


					} else
					{
						$mdpBasdon = null;
					}
					
					
					
					
						
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE BASDON SET '.
							' nomBASDON ="'.$nomBasdon.'",'.
							' libelleBASDON ="'.$libelleBasdon.'",'.
							' servBASDON ="'.$servBasdon.'",'.
							' emplBASDON ="'.$emplBasdon.'",'.
							' chemShellBASDON ="'.$chemShellBasdon.'",'.
							' loginBASDON ="'.$loginBasdon.'", '.
							' mdpBASDON ="'.$mdpChiffreBasdon.'" '.
								' WHERE idBASDON = :idBasdon ';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idBasdon', $idBasdon, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	