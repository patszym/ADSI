<?php	
include 'include/encrypt_decrypt.php';
include_once('include/ConversionDates.class.php');
				
					$idAppli = null;
					
					if(!empty($_POST["idDivision"]))
					{
						$idDivision=$_POST["idDivision"];
					} else
					{
						$idDivision = null;
					}
					if(!empty($_POST["idDiffusion"]))
					{
						$idDiffusion=$_POST["idDiffusion"];
					} else
					{
						$idDiffusion = null;
					}
					
					if(!empty($_POST["nomAppli"]))
					{
						$nomAppli=$_POST["nomAppli"];
					} else 
					{ 
						$nomAppli = null;
					}
					
					if(!empty($_POST["libelleAppli"]))						
					{
						$libelleAppli=$_POST["libelleAppli"];
					} else
					{
						$libelleAppli = null;
					}
					if(!empty($_POST["urlPresAppli"]))
					{
						$urlPresAppli=$_POST["urlPresAppli"];
					} else
					{
						$urlPresAppli = null;
					}
					if(!empty($_POST["typeAppli"]))
					{
						$typeAppli=$_POST["typeAppli"];
					} else
					{
						$typeAppli = null;
					}
					if(!empty($_POST["idRowAcaAppli"]))
					{
						$idRowAcaAppli=$_POST["idRowAcaAppli"];
					} else
					{
						$idRowAcaAppli = null;
					}
					if(!empty($_POST["prestataireAppli"]))
					{
						$prestataireAppli=$_POST["prestataireAppli"];
					} else
					{
						$prestataireAppli = null;
					}
					$dateversRowDiffusAppli  = null;
					$validdateDiffusAppli = true;
					if(!empty($_POST["dateDiffusAppli"]))
					{
							
							
						$conversionDate1 = new ConversionDates();
						$conversionDate1->setdt($_POST['dateDiffusAppli']);
						$conversionDate1->initHeure();
						$conversionDate1->convdDate();
						$dateversRowDiffusAppli = $conversionDate1->getdate() ;
						if (!checkdate($conversionDate1->getm(), $conversionDate1->getd(), $conversionDate1->getY()))
						{
					
							$validdateDiffusAppli = false;
							echo $dateDiffusAppli. " n'est pas une date valide <br>";
							?>
								<script language="javascript">
								alert("Date de demande du projet non conforme au format d'une date");													</script>
	 						<?php
						}
					} 
					else
					{
						$dateversRowDiffusAppli  = null;
					}
					$dateversRowDebutAppli  = null;
					$validdateDebutAppli = true;
					if(!empty($_POST["dateDebutAppli"]))
					{
							
							
						$conversionDate1 = new ConversionDates();
						$conversionDate1->setdt($_POST['dateDebutAppli']);
						$conversionDate1->initHeure();
						$conversionDate1->convdDate();
						$dateversRowDebutAppli = $conversionDate1->getdate() ;
						if (!checkdate($conversionDate1->getm(), $conversionDate1->getd(), $conversionDate1->getY()))
						{
								
							$validdateDebutAppli = false;
							echo $dateDebutAppli. " n'est pas une date valide <br>";
							?>
							<script language="javascript">
							alert("Date de demande du projet non conforme au format d'une date");													</script>
						 	<?php
						}
					} 
					else
					{
						$dateversRowDebutAppli  = null;
					}
					$dateversRowFinAppli  = null;
					$validdateFinAppli = true;
																
					if(!empty($_POST["dateFinAppli"]))
						{
						$conversionDate2 = new ConversionDates();
						$conversionDate2->setdt($_POST['dateFinAppli']);
						$conversionDate2->initHeure();
						$conversionDate2->convdDate();
						$dateversRowFinAppli = $conversionDate2->getdate() ;
													
						if (!checkdate($conversionDate2->getm(), $conversionDate2->getd(), $conversionDate2->getY()))
						{
							$validdateFinAppli = false;
							echo $dateFinAppli. " n'est pas une date valide <br>";
							?>
							<script language="javascript">
							alert("Date de Fin de l'application non conforme au format d'une date");
							</script>
							<?php
						}
																					
					} 
					else
					{
					$dateversRowFinAppli  = null;
																					
					}
					$dateversRowPriseEnChargeAppli  = null;
					$validdatePriseEnChargeAppli = true;
					
					if(!empty($_POST["datePriseEnChargeAppli"]))
					{
						$conversionDate2 = new ConversionDates();
						$conversionDate2->setdt($_POST['datePriseEnChargeAppli']);
						$conversionDate2->initHeure();
						$conversionDate2->convdDate();
						$dateversRowPriseEnChargeAppli = $conversionDate2->getdate() ;
							
						if (!checkdate($conversionDate2->getm(), $conversionDate2->getd(), $conversionDate2->getY()))
						{
							$validdatePriseEnChargeAppli = false;
							echo $datePriseEnChargeAppli. " n'est pas une date valide <br>";
							?>
							<script language="javascript">
							alert("Date de PriseEnCharge de l'application non conforme au format d'une date");
							</script>
							<?php
						}
																										
					} 
					else
					{
						$dateversRowPriseEnChargeAppli  = null;
																										
					}
					$dateversRowInstallationAppli  = null;
					$validdateInstallationAppli = true;
					
					if(!empty($_POST["dateInstallationAppli"]))
					{
						$conversionDate2 = new ConversionDates();
						$conversionDate2->setdt($_POST['dateInstallationAppli']);
						$conversionDate2->initHeure();
						$conversionDate2->convdDate();
						$dateversRowInstallationAppli = $conversionDate2->getdate() ;
							
						if (!checkdate($conversionDate2->getm(), $conversionDate2->getd(), $conversionDate2->getY()))
						{
							$validdateInstallationAppli = false;
							echo $dateInstallationAppli. " n'est pas une date valide <br>";
							?>
							<script language="javascript">
							alert("Date de Installation de l'application non conforme au format d'une date");
							</script>
							<?php
						}
																										
					} 
					else
					{
					$dateversRowInstallationAppli  = null;
																										
					}
					$dateversRowMiseADispoAppli  = null;
					$validdateMiseADispoAppli = true;
						
					if(!empty($_POST["dateMiseADispoAppli"]))
					{
						$conversionDate2 = new ConversionDates();
						$conversionDate2->setdt($_POST['dateMiseADispoAppli']);
						$conversionDate2->initHeure();
						$conversionDate2->convdDate();
						$dateversRowMiseADispoAppli = $conversionDate2->getdate() ;
							
						if (!checkdate($conversionDate2->getm(), $conversionDate2->getd(), $conversionDate2->getY()))
						{
							$validdateMiseADispoAppli = false;
							echo $dateMiseADispoAppli. " n'est pas une date valide <br>";
							?>
							<script language="javascript">
							alert("Date de MiseADispo de l'application non conforme au format d'une date");
							</script>
							<?php
						}
																															
					} 
					else
					{
						$dateversRowMiseADispoAppli  = null;
																															
					}
					if(!empty($_POST["domFoncAppli"]))
					{
						$domFoncAppli=$_POST["domFoncAppli"];
					} else
					{
						$domFoncAppli = null;
					}
											
					if(!empty($_POST["loginAppli"]))
					{
						$loginAppli=$_POST["loginAppli"];
					} else
					{
						$loginAppli = null;
					}
						
					if(!empty($_POST["mdpAppli"]))
					{
						$mdpAppli=$_POST["mdpAppli"];
							
					
					
						$plain_txt = $mdpAppli;
					
						$encrypted_txt = encrypt_decrypt('encrypt', $plain_txt);
							
						$mdpChiffreAppli = $encrypted_txt;
					
					
					} else
					{
						$mdpChiffreAppli = null;
					}
						
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idAPPLI) FROM APPLI ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idAppli = $gid->fetchColumn();
					
					
					
					$idAppli ++ ;
					
					
					$sql = 'insert into APPLI values ("'.$idAppli.'",'.
							'"'.$idDivision.'",'.
							'"'.$idDiffusion.'",'.
							'"'.$nomAppli.'","'.$libelleAppli.'",'.
							'"'.$urlPresAppli.'",'.
							$typeAppli.','.
							'"'.$idRowAcaAppli.'",'.
							'"'.$prestataireAppli.'",';
					
					if(!empty($_POST["dateDiffusAppli"]))
							{
							
								$sql = $sql.'"'.$dateversRowDiffusAppli .'",';
							}
							else
							{
								$sql = $sql .'null,';
							}
					if(!empty($_POST["dateDebutAppli"]))
							{
									
								$sql = $sql.'"'.$dateversRowDebutAppli .'",';
							}
							else
							{
								$sql = $sql .'null,';
							}
					if(!empty($_POST["dateFinAppli"]))
							{
								$sql = $sql.'"'.$dateversRowFinAppli .'",';
							}
							else
							{
								$sql = $sql .'null,';
							}
					if(!empty($_POST["datePriseEnChargeAppli"]))
							{
								$sql = $sql.'"'.$dateversRowPriseEnChargeAppli .'",';
							}
							else
							{
								$sql = $sql .'null,';
							}
					if(!empty($_POST["dateInstallationAppli"]))
							{
								$sql = $sql.'"'.$dateversRowInstallationAppli .'",';
							}
							else
							{
								$sql = $sql .'null,';
							}
					if(!empty($_POST["dateMiseADispoAppli"]))
							{
								$sql = $sql.'"'.$dateversRowMiseADispoAppli .'",';
								
							}
							else
							{
								$sql = $sql .'null,';
							}
					$sql = $sql .'"'.$domFoncAppli.'",';
					$sql = $sql .'"'.$loginAppli.'",';
					$sql = $sql .'"'.$mdpChiffreAppli.'"';
					$sql = $sql .');'   ;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
			?>	