<?php	
include 'include/encrypt_decrypt.php';
include_once('include/ConversionDates.class.php');
if(!empty($_POST["soumet"]))
{

					$idAppli = $_POST["idAppli"];
					
					if(!empty($_POST["idDivision"]))
					{
						$idDivision=$_POST["idDivision"];
					} else
					{
						$idDivision = null;
					}
					if(!empty($_POST["idDiffusion"]))
					{
						$idDiffusion=$_POST["idDiffusion"];
					} else
					{
						$idDiffusion = null;
					}
						
					if(!empty($_POST["nomAppli"]))
					{
						$nomAppli=$_POST["nomAppli"];
					} else
					{
						$nomAppli = null;
					}
						
					if(!empty($_POST["libelleAppli"]))
					{
						$libelleAppli=$_POST["libelleAppli"];
					} else
					{
						$libelleAppli = null;
					}
					if(!empty($_POST["urlPresAppli"]))
					{
						$urlPresAppli=$_POST["urlPresAppli"];
					} else
					{
						$urlPresAppli = null;
					}
					if(!empty($_POST["typemodifAppli"]))
					{
						$typemodifAppli=$_POST["typemodifAppli"];
						
					} else
					{
						$typemodifAppli = null;
					}
					if(!empty($_POST["idmodifAcaAppli"]))
					{
						$idmodifAcaAppli=$_POST["idmodifAcaAppli"];
						
					} else
					{
						$idmodifAcaAppli = null;
					}
					if(!empty($_POST["prestataireAppli"]))
					{
						$prestataireAppli=$_POST["prestataireAppli"];
					} else
					{
						$prestataireAppli = null;
					}
					$dateversRowDiffusAppli  = null;
					$validdateDiffusAppli = true;
					if(!empty($_POST["dateDiffusAppli"]))
					{
							
							
						$conversionDate1 = new ConversionDates();
						$conversionDate1->setdt($_POST['dateDiffusAppli']);
						$conversionDate1->initHeure();
						$conversionDate1->convdDate();
						$dateversRowDiffusAppli = $conversionDate1->getdate() ;
						if (!checkdate($conversionDate1->getm(), $conversionDate1->getd(), $conversionDate1->getY()))
						{
								
							$validdateDiffusAppli = false;
							echo $dateDiffusAppli. " n'est pas une date valide <br>";
							?>
							<script language="javascript">
							alert("Date de demande du projet non conforme au format d'une date");													</script>
						 	<?php
						}
					} 
					else
					{
						$dateversRowDiffusAppli  = null;
					}
					$dateversRowDebutAppli  = null;
					$validdateDebutAppli = true;
					if(!empty($_POST["dateDebutAppli"]))
					{
												
												
						$conversionDate1 = new ConversionDates();
						$conversionDate1->setdt($_POST['dateDebutAppli']);
						$conversionDate1->initHeure();
						$conversionDate1->convdDate();
						$dateversRowDebutAppli = $conversionDate1->getdate() ;
						if (!checkdate($conversionDate1->getm(), $conversionDate1->getd(), $conversionDate1->getY()))
											{
													
												$validdateDebutAppli = false;
												echo $dateDebutAppli. " n'est pas une date valide <br>";
												?>
												<script language="javascript">
												alert("Date de demande du projet non conforme au format d'une date");													</script>
											 	<?php
											}
										} 
										else
										{
											$dateversRowDebutAppli  = null;
										}
										$dateversRowFinAppli  = null;
										$validdateFinAppli = true;
																					
										if(!empty($_POST["dateFinAppli"]))
											{
											$conversionDate2 = new ConversionDates();
											$conversionDate2->setdt($_POST['dateFinAppli']);
											$conversionDate2->initHeure();
											$conversionDate2->convdDate();
											$dateversRowFinAppli = $conversionDate2->getdate() ;
																		
											if (!checkdate($conversionDate2->getm(), $conversionDate2->getd(), $conversionDate2->getY()))
											{
												$validdateFinAppli = false;
												echo $dateFinAppli. " n'est pas une date valide <br>";
												?>
												<script language="javascript">
												alert("Date de Fin de l'application non conforme au format d'une date");
												</script>
												<?php
											}
																										
										} 
										else
										{
										$dateversRowFinAppli  = null;
																										
										}
										$dateversRowPriseEnChargeAppli  = null;
										$validdatePriseEnChargeAppli = true;
										
										if(!empty($_POST["datePriseEnChargeAppli"]))
										{
											$conversionDate2 = new ConversionDates();
											$conversionDate2->setdt($_POST['datePriseEnChargeAppli']);
											$conversionDate2->initHeure();
											$conversionDate2->convdDate();
											$dateversRowPriseEnChargeAppli = $conversionDate2->getdate() ;
												
											if (!checkdate($conversionDate2->getm(), $conversionDate2->getd(), $conversionDate2->getY()))
											{
												$validdatePriseEnChargeAppli = false;
												echo $datePriseEnChargeAppli. " n'est pas une date valide <br>";
												?>
												<script language="javascript">
												alert("Date de PriseEnCharge de l'application non conforme au format d'une date");
												</script>
												<?php
											}
																															
										} 
										else
										{
											$dateversRowPriseEnChargeAppli  = null;
																															
										}
										$dateversRowInstallationAppli  = null;
										$validdateInstallationAppli = true;
										
										if(!empty($_POST["dateInstallationAppli"]))
										{
											$conversionDate2 = new ConversionDates();
											$conversionDate2->setdt($_POST['dateInstallationAppli']);
											$conversionDate2->initHeure();
											$conversionDate2->convdDate();
											$dateversRowInstallationAppli = $conversionDate2->getdate() ;
												
											if (!checkdate($conversionDate2->getm(), $conversionDate2->getd(), $conversionDate2->getY()))
											{
												$validdateInstallationAppli = false;
												echo $dateInstallationAppli. " n'est pas une date valide <br>";
												?>
												<script language="javascript">
												alert("Date de Installation de l'application non conforme au format d'une date");
												</script>
												<?php
											}
																															
										} 
										else
										{
										$dateversRowInstallationAppli  = null;
																															
										}
										$dateversRowMiseADispoAppli  = null;
										$validdateMiseADispoAppli = true;
											
										if(!empty($_POST["dateMiseADispoAppli"]))
										{
											$conversionDate2 = new ConversionDates();
											$conversionDate2->setdt($_POST['dateMiseADispoAppli']);
											$conversionDate2->initHeure();
											$conversionDate2->convdDate();
											$dateversRowMiseADispoAppli = $conversionDate2->getdate() ;
												
											if (!checkdate($conversionDate2->getm(), $conversionDate2->getd(), $conversionDate2->getY()))
											{
												$validdateMiseADispoAppli = false;
												echo $dateMiseADispoAppli. " n'est pas une date valide <br>";
												?>
												<script language="javascript">
												alert("Date de MiseADispo de l'application non conforme au format d'une date");
												</script>
												<?php
											}
																																				
										} 
										else
										{
											$dateversRowMiseADispoAppli  = null;
																																				
										}
										if(!empty($_POST["domFoncAppli"]))
										{
											$domFoncAppli=$_POST["domFoncAppli"];
										} else
										{
											$domFoncAppli = null;
										}
																
										if(!empty($_POST["loginAppli"]))
										{
											$loginAppli=$_POST["loginAppli"];
										} else
										{
											$loginAppli = null;
										}
											
										if(!empty($_POST["mdpAppli"]))
										{
											$mdpAppli=$_POST["mdpAppli"];
												
										
										
											$plain_txt = $mdpAppli;
										
											$encrypted_txt = encrypt_decrypt('encrypt', $plain_txt);
												
											$mdpChiffreAppli = $encrypted_txt;
										
										
										} else
										{
											$mdpChiffreAppli = null;
										}
										
					// Mise a jour dans la base						
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE APPLI SET '.
							'DIVISION_idDIVISION="'.$idDivision.'",'.
							'DIFFUSION_idDIFFUSION="'.$idDiffusion.'",'.
							' nomAPPLI ="'.$nomAppli.'",'.
							' libelleAPPLI ="'.$libelleAppli.'",';
					$sql = $sql .' urlPresAPPLI ="'.$urlPresAppli.'",';
					$sql = $sql .' typeAPPLI ='.$typemodifAppli.',';
					$sql = $sql .' idRowAcaAPPLI ="'.$idmodifAcaAppli.'",';
					$sql = $sql .' prestataireAPPLI ="'.$prestataireAppli.'",';
						
					if(!empty($_POST["dateDiffusAppli"]))
					{
							
						$sql = $sql.' dateDiffusAPPLI ="'.$dateversRowDiffusAppli .'",';
					}
					
					if(!empty($_POST["dateDebutAppli"]))
					{
							
						$sql = $sql.' dateDebutAPPLI ="'.$dateversRowDebutAppli .'",';
					}
					
					if(!empty($_POST["dateFinAppli"]))
					{
						$sql = $sql.' dateFinAPPLI ="'.$dateversRowFinAppli .'",';
					}
					
					if(!empty($_POST["datePriseEnChargeAppli"]))
					{
						$sql = $sql.' datePriseEnChargeAPPLI ="'.$dateversRowPriseEnChargeAppli .'",';
					}
					
					if(!empty($_POST["dateInstallationAppli"]))
					{
						$sql = $sql.' dateInstallationAPPLI ="'.$dateversRowInstallationAppli .'",';
					}
					
					if(!empty($_POST["dateMiseADispoAppli"]))
					{
						$sql = $sql.' dateMiseADispoAPPLI ="'.$dateversRowMiseADispoAppli .'",';
						
					}
					
					$sql = $sql .' domFoncAPPLI ="'.$domFoncAppli.'",';
					$sql = $sql .' loginAPPLI ="'.$loginAppli.'",';
					$sql = $sql .' mdpAPPLI ="'.$mdpChiffreAppli.'"';
					
						
					$sql = $sql.' WHERE idAPPLI = :idAppli ;';
					

					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	