<!DOCTYPE html PUBLIC "-//W3C//Dtd XHTML 1.0 Strict//EN"
	"http://www.w3.org/tr/xhtml1/Dtd/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		reinitialisation du mot de passe - 1
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />


</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
		
		<a href="logout.php">Deconnexion</a>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">
		<?php include('include/con2log.php'); ?> 
		<?php if ($adm == true)    
		{
		?>
		<?php include('include/ADMnavigation.php'); ?> 
		<div id="secondaire">
			<h3>Utilisation</h3>
			<p> Choisissez l'option ou l'une des options sur le menu à gauche <p>
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5> Vous etes administrateur,  
							de login <?php echo $loginAdm; ?> </h5>
			
			<?php
			
			include 'include/encrypt_decrypt.php';
			
			if(!empty($_SESSION["idAdm"]))
			{
				$idAdm = $_SESSION['idAdm'];
					
			}
			
			if(!empty($_POST["mdpAdm"]))
			{
				$mdpAdm=$_POST["mdpAdm"];
			
			
			
				$plain_txt = $mdpAdm;
			
				$encrypted_txt = encrypt_decrypt('encrypt', $plain_txt);
			
				$mdpChiffreAdm = $encrypted_txt;
					
			
			} else
			{
				$mdpChiffreAdm = null;
			}
			
			
			include('include/connBase.php');
			$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql='UPDATE ADM set mdpADM ="'.$mdpChiffreAdm.'"';
			
			
			if (!empty($idAdm))
			{
				$sql = $sql . " WHERE "."idADM = :idAdm";
				
				$sql = $sql." LIMIT 1";
				$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				$sth->bindValue(':idAdm', $idAdm, PDO::PARAM_INT);
			
					
					
			
				//  echo $sql;
				try {
					$sth->execute();
					echo "mise à jour administrateur faite";
						
				} catch (PDOException $e) {
					echo 'la recherche du login a échouée : ' . $e->getMessage();
						
				}
					
				
					
			}
			
				
			
			?>
			
		</div><!-- #principal -->
	<?php }?>
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	
</div><!-- #global -->

</body>
</html>
