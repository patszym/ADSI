<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">


<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Contact
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> A l'appel du menu général, le mode <b> Liste et Edition</b> est le mode par défaut</p>
			<p> Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence Contact</p>
			<p> Cliquez sur l'image de l'oeil pour voir le détail de la ligne spécifiée en consultation dans la liste</p>
			<p> Cliquez sur l'image du crayon pour voir le détail de la ligne spécifiée en modification dans la liste</p>
			<p> Cliquez sur l'image de la croix pour voir le détail de la ligne spécifiée en suppression dans la liste</p>
			<p>Cliquez sur l'icône <b>PDF</b> pour voir le détail de la ligne en obtenant son édition PDF </p>
			<p>Cliquez sur l'icône <b>PDF</b> à gauche du titre pour obtenir l'édition PDF de la liste</p>
			
	</div><!-- #secondaire -->
		
	<div id="principal"> 
			<h5>Gestion des  contacts de la diffusion </h5>
			
			<br>
			<div id="tabsF">
				<?php include('include/MHCO.php'); ?> 
									
			</div>
			
	
		<fieldset class="saisie">
			<table BORDER=0>
			
			<tr>
			
				<td>
				<a href="editions/edCOPDF.php">
				<img src="images/pdficon.jpg" height="20" width="20" align = "center" 
				alt="PDF">
				</a>
				</td>
				<td>
				<h3>  LISTE DES  CONTACTS de la DIFFUSION </h3>
				</td>
			</tr>
			
			
				
				
				<?php 
				include_once "include/connBase.php" ; 
	
				$sql = 'select DIFFUSION_idDIFFUSION, idCONTACT, nomCONTACT, 
					prenomCONTACT,telephoneCONTACT,emailCONTACT,
					ssDomFoncCONTACT, FonctionnelCONTACT, InformatiqueCONTACT,
					DIFFUSION.nomDIFFUSION
					from CONTACT, DIFFUSION
					where CONTACT.DIFFUSION_idDIFFUSION = DIFFUSION.idDIFFUSION
					order by nomDIFFUSION, nomCONTACT';
	
			
				include_once "include/visuConvCO.php";
				
				$i = 0 ;
				$idRowDiffusion = null;
				$idContact = null ;
				$nomContact =  null;
				$prenomContact =  null ;
				$telephoneCONTACT = null ;
				$emailCONTACT = null;
				$ssDomFoncCONTACT = null ;
				$FonctionnelCONTACT = null;
				$InformatiqueCONTACT = null;
				$nomDiffusion = null;
				

				while ($i<$maxRow)
				{
					
					$idRowDiffusion = $tableau [$i][0];
					$idContact =  $tableau [$i][1] ;
					$nomContact =  $tableau [$i][2] ;
					$prenomContact =  $tableau [$i][3] ;
					$telephoneContact = $tableau [$i][4] ;
					$emailContact = $tableau [$i][5];
					$ssDomFoncContact = $tableau [$i][6] ;
					$FonctionnelContact = $tableau [$i][7];
					$InformatiqueContact = $tableau [$i][8];
					$nomDiffusion = $tableau [$i][9];
					
					
					$i++;
					/* Exploitation des lignes dans la liste */
					?>
									
				
				<!-- Liste des  Contacts - formulaire en lecture -->
													
					<tr>
									
									
						
							<input type="hidden" name="idContact"
							value="<?php echo htmlspecialchars($idContact); ?>"
							></input>
						
						<td>
							<input type=text name="nomDiffusion" 
							value="<?php echo htmlspecialchars($nomDiffusion); ?>" 
							maxlength="20" size="12" readonly></input>
						</td>							
														
						<td>
							<input type=text name="nomContact" 
							value="<?php echo htmlspecialchars($nomContact); ?>" 
							maxlength="30" size="30" readonly></input>
						</td>
													
													
														
						<td>
							<input type=text name="PrenomContact" 
							value="<?php echo htmlspecialchars($prenomContact); ?>" 
							maxlength="30" size="30" readonly></input>
						</td>
						
						<td>
							<form action="consCO.php" method="post">

			 					<input type="hidden" name="idContact" 
			 					value="<?php echo htmlspecialchars($idContact); ?>">
			 					</input>
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form> 
						</td>
						<td>
							<form action="modifCO.php" method="post">

			 					<input type="hidden" name="idContact" 
			 					value="<?php echo htmlspecialchars($idContact); ?>">
			 					</input>
								<input border=0 src="images/crayon.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form>
						</td>
							<td> 
							<form action="supprCO.php" method="post">

			 					<input type="hidden" name="idContact" 
			 					value="<?php echo htmlspecialchars($idContact); ?>">
			 					</input>
								<input border=0 src="images/button-cancel.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form>
						</td> 
						<td> 					
							
							
							<form action="editions/edElCOPDF.php" method="post">

								<input type="hidden" name="nomDiffusion" 
								value="<?php echo htmlspecialchars($nomDiffusion); ?>">
								</input>
			 					<input type="hidden" name="idContact" 
								value="<?php echo htmlspecialchars($idContact); ?>">
			 					</input>
								<input type="hidden" name="nomContact" 
								value="<?php echo htmlspecialchars($nomContact); ?>">
			 					</input>
			 		
								<input type="hidden" name="prenomContact" 
								value="<?php echo htmlspecialchars($prenomContact); ?>">
								</input>
								<input type="hidden" name="telephoneContact" 
								value="<?php echo htmlspecialchars($telephoneContact); ?>">
								</input>
								<input type="hidden" name="emailContact" 
								value="<?php echo htmlspecialchars($emailContact); ?>">
								</input>
								<input type="hidden" name="ssDomFoncContact" 
								value="<?php echo htmlspecialchars($ssDomFoncContact); ?>">
								</input>
								<input type="hidden" name="FonctionnelContact" 
								value="<?php echo htmlspecialchars($FonctionnelContact); ?>">
			 					</input>
			 					<input type="hidden" name="InformatiqueContact" 
								value="<?php echo htmlspecialchars($InformatiqueContact); ?>">
			 					</input>
			 					<input border=0 src="images/pdficon.jpg" 
								type=image value=submit name = "soumet" align="left" 
								height="20" width="20"></input>

										
							</form>
							
						</td> 
						<td> 
							<form action="ajAPsCO.php" method="post">

			 					<input type="hidden" name="idContact" 
			 					value="<?php echo htmlspecialchars($idContact); ?>">
			 					</input>
								<input border=0 src="images/applications.jpg" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
							</form>
						</td>     				
					</tr>			
										
							
				<?php 
				}
				$query = null;
				?>
			</table>
		</fieldset>

		</div> <!-- principal-->
	
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
