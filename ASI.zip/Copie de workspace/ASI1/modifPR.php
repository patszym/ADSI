<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		 Projets
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css">
	<style type="text/css">    
		div.ui-datepicker{
		font-size: 12px;
	}
	</style>
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
	<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
	<script src="jquery.ui.datepicker-fr.js"></script>
	<script>
		$(function() {
		$("#calendrier1").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		$(function() {
		$("#calendrier2").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
	</script>
</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> Il faut valider la modification pour achever la tâche (bouton <b> valider </b>)</p>
			
			<p>	Cliquez sur l'onglet <b>Liste et Edition </b>pour une consultation, une autre modification, 
			ou une suppression </p>
			<p>	Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence de Projet </p>
			
			
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5>Gestion des Projets </h5>
			
		
			<div id="tabsF">
				<?php include('include/MHPR.php'); ?>
			</div> 
				<?php $cons = 2; ?>
				<?php include('include/con2PR.php'); ?> 
				
			<fieldset class="saisie">
			
			<form name="modifProjet" id="modifProjetForm" method="post"
				 enctype="multipart/form-data" 
					action="valid2modifPR.php">
					
				<table BORDER=0>	
					<!-- ^consultation Projet - formulaire -->
					<br>
					
					<input type="hidden" name="idProjet" 
						value="<?php echo htmlspecialchars($idProjet); ?>">
						</input>
						<td> Nom du projet :</td>
						<td>
							<input type="text" name="nomProjet" 
							value="<?php echo htmlspecialchars($nomProjet); ?>"
							 maxlength="20" size="20" ></input>
						</td>
					</tr>
						<tr>
						<td> Libelle du projet :</td>
						<td>
							<input type="text" name="libelleProjet" 
							value="<?php echo htmlspecialchars($libelleProjet); ?>"
							 maxlength="100" size="60" ></input>
						</td>
					</tr>				
					<tr>
						<td> Contexte du projet :</td>
						<td>
							<textarea readonly name = "contexteProjet" rows="11" cols="50">
							<?php echo htmlspecialchars($contexteProjet); ?>
							</textarea>
						</td>
					</tr>
					<tr>
						
						<td>
							<?php if (!$indLocalProjet): ?>
						
							<input type="checkbox" name="choixLocal" value="1" >
							Indicateur Projet local
							</input>
							<?php else: ?>
						
							<input type="checkbox" name="choixLocal" value="2" checked disabled="disabled">
							Indicateur Projet local
							</input>
						<?php endif ?>
						</td>
					<tr>
						<td>
							<?php if (!$indNationalProjet): ?>
						
							<input type="checkbox" name="choixNational" value="1" >
							Indicateur projet national
							</input>
							<?php else: ?>
						
							<input type="checkbox" name="choixNational" value="2" checked disabled="disabled">
							Indicateur projet national
							</input>
						<?php endif ?>
						</td>
					<tr>
						<td>
							<?php if (!$indInterAcaProjet): ?>
						
							<input type="checkbox" name="choixInterAca" value="1" >
							Indicateur projet inter-académique
							</input>
							<?php else: ?>
						
							<input type="checkbox" name="choixInterAca" value="2" checked disabled="disabled">
							Indicateur projet inter-académique
							</input>
						<?php endif ?>
						</td>
					</tr>
					<tr>
						<td> Date de la demande : </td>
						<td>
							<INPUT type=text id="calendrier1" 
							name="dateDemandeProjet" 
							value="<?php echo htmlspecialchars($dDemandeProjet); ?>" 
							maxlength="10" size="10" >
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Date de Fin :</td>
						<td>
							<INPUT type=text id="calendrier2" 
							name="dateFinProjet" 
							value="<?php echo htmlspecialchars($dFinProjet); ?>" 
							maxlength="10" size="10" >
							</input>
						</td>
					</tr>
					
					<tr>
						
						 <td>
						 </td>
						 <td>
						 	<?php  
						 		echo "Les binaires des fichiers numérisés associés à l'origine, 
								respectivement ci-dessous : "; 
						 		echo "Demande, cahier de charges, et documentation, sont présentés ici avec leurs noms d'origine 
									et leurs extensions ";
						 	?>
						 </td>
					
					</tr>
					<tr>
						<td> 		
								<input type="text" name="filenamedemProjet" 
								value="<?php echo htmlspecialchars($filenamedemProjet); ?>" readonly>
								</input>
						</td>
						<td> 	
								<input type="text" name="extensiondemProjet"  size="4"
								value="<?php echo htmlspecialchars($extensiondemProjet); ?>" readonly>
								</input>
						</td>
					</tr>
					<tr>
						<td> Demande :</td>
						<td>
							
							<input type="file" name="demFormProjet" id="demFormProjet" />
							</input> 
						</td>
					</tr>
					<tr>
						<td> 		
								<input type="text" name="filenamecdcProjet" 
								value="<?php echo htmlspecialchars($filenamecdcProjet); ?>" readonly>
								</input>
						</td>
						<td> 	
								<input type="text" name="extensioncdcProjet" size="4"
								value="<?php echo htmlspecialchars($extensioncdcProjet); ?>" readonly>
								</input>
						</td>
					</tr>
					<tr>
						<td> Cahier de charges :</td>
						<td>
							
							<input type="file" name="cdcFormProjet">
							</input>
						</td>
					</tr>
					<tr>
						<td> 	
								<input type="text" name="filenamedocProjet" 
								value="<?php echo htmlspecialchars($filenamedocProjet); ?>" readonly>
								</input>
						</td>
						<td> 	
								<input type="text" name="extensiondocProjet" size="4"
								value="<?php echo htmlspecialchars($extensiondocProjet); ?>" readonly>
								</input>
						</td>
				
					</tr>
					<tr>
						<td> Documentation :</td>
						<td>
							
							<input type="file" name="docFormProjet">
							</input>
						</td>
					</tr>
					<tr>
						<td> 		
						<input type="submit" value="Valider" name="soumet">
						</input>
						</td>
						<td> 	
						<input type="submit" value="Annuler">
					    </input>
						
				
						</td>
					</tr>
					</table>	
			</form>
		
		</fieldset>	
			
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
