<?php	
			  
				
					if(!empty($_POST["Appli_idAppli"]))

					{
						$Appli_idAppli=$_POST["Appli_idAppli"];
					} else 
					{ 
						$Appli_idAppli = 0;
					}
									
					
					if(!empty($_POST["Contact_idContact"]))
					{
						$Contact_idContact=$_POST["Contact_idContact"];
					} else 
					{ 
						$Contact_idContact = 0;
					}
					
										
					
						
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
					$validBase = true;
					$nbOccur = 0;
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT count(*) FROM CONTACT_has_APPLI
							where APPLI_idAPPLI = :Appli_idAppli
							and CONTACT_idCONTACT = :Contact_idContact";
					
					$gid = $dbh->prepare($sql1);
					$gid->bindValue(':Appli_idAppli', $Appli_idAppli, PDO::PARAM_INT);
					$gid->bindValue(':Contact_idContact', $Contact_idContact, PDO::PARAM_INT);
					$gid->execute();
					$nbOccur  = $gid->fetchColumn();
					
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table APPLI_has_CONTACT utilise(nt) cette réference APPLI et cette référence CONTACT <br>";
						?>
						<script language="javascript">
						alert("L'ajout est impossible car il y a au moins une référence identique dans la table des rattachements application et contact");
						</script>
						<?php
					}
					$sql1= "SELECT count(*) FROM APPLI, DIFFUSION, CONTACT
							where APPLI.idAPPLI = :Appli_idAppli
							and CONTACT.idCONTACT = :Contact_idContact
							and APPLI.DIFFUSION_idDIFFUSION = DIFFUSION.idDIFFUSION
							and CONTACT.DIFFUSION_idDIFFUSION = DIFFUSION.idDIFFUSION
							";
						
					$gid = $dbh->prepare($sql1);
					$gid->bindValue(':Appli_idAppli', $Appli_idAppli, PDO::PARAM_INT);
					$gid->bindValue(':Contact_idContact', $Contact_idContact, PDO::PARAM_INT);
					$gid->execute();
					$nbOccur = $gid->fetchColumn();
						
					if ($nbOccur ==0)
					{
						$validBase = false;
						echo " Il n'y a pas un lien avec l'organisme de diffusion correct <br>";
						?>
						<script language="javascript">
						alert("L'ajout est impossible car il n'y a pas de référence avec la diffusion correcte ");
						</script>
						<?php
					}
					
			
					if ($validBase)
					{
					
						$sql = 'insert into CONTACT_has_APPLI values ('.$Contact_idContact.','
							.$Appli_idAppli.');'   ;
						
						$dbh->exec($sql);
					
      				
						$dbh->commit();
						echo "Validation de l'Ajout faite";
					}
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
				
			}
				
	?>	