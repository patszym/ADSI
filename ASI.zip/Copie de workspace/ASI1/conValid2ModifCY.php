<?php	

if(!empty($_POST["soumet"]))
{

					$idCycle = $_POST["idCycle"];
					
					
					if(!empty($_POST["libelleCourtCycle"]))
					{
						$libelleCourtCycle=$_POST["libelleCourtCycle"];
					} else 
					{ 
						$libelleCourtCycle = null;
					}
					
					if(!empty($_POST["libelleLongCycle"]))						
					{
						$libelleLongCycle=$_POST["libelleLongCycle"];
					} else
					{
						$libelleLongCycle = null;
					}
					
				
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE CYCLE SET '.
							' libelleCourtCYCLE ="'.$libelleCourtCycle.'",'.
							' libelleLongCYCLE ="'.$libelleLongCycle.'"'.
							
								' WHERE idCYCLE = :idCycle ';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idCycle', $idCycle, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	