<?php	
			  
if(!empty($_POST["soumet"]))
{
					$idCycle = null;
					
					
					if(!empty($_POST["idCycle"]))
					{
						$idCycle=$_POST["idCycle"];
					} 
					
					include('include/connBase.php');
					
					// Contrôles de cohérence de la base pour les clés étrangères déclarées dans les autres tables
					// à la suppression. Normalement c'est fait des triggers (sous Oracle), mais pas sur Mysql
					// donc la cohérence de la base est assurée au niveau de la programmation
					// ---> clé étrangère de CYCLE dans la table APPLI
					
					$validBase = true;
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM CAMPAGNESCYCLE WHERE CYCLE_idCYCLE = :idCycle ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idCycle', $idCycle, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
						
					
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table CAMPAGNESCYCLE utilise(nt) cette réference CYCLE <br>";
						?>
								<script language="javascript">
								alert("La suppression est impossible car il y a une référence dans la table application exploitant cette occurence de Diffusion");
								</script>
							<?php
					}
				
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM PROCESSUSCYCLE WHERE CYCLE_idCYCLE = :idCycle ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idCycle', $idCycle, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
					
							
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table PROCESSUSCYCLE utilise(nt) cette réference CYCLE <br>";
						?>
							<script language="javascript">
							alert("La suppression est impossible car il y a une référence dans la table application exploitant cette occurence de Diffusion");
							</script>
						<?php
					}
					
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM TACHECYCLE WHERE CYCLE_idCYCLE = :idCycle ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idCycle', $idCycle, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
					
							
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table TACHECYCLE utilise(nt) cette réference CYCLE <br>";
						?>
						<script language="javascript">
						alert("La suppression est impossible car il y a une référence dans la table application exploitant cette occurence de Diffusion");
						</script>
						<?php
					}
				if ($validBase)
				{
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					
						$sql = 'DELETE FROM CYCLE WHERE idCYCLE = :idCycle ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idCycle', $idCycle, PDO::PARAM_INT);
					
						$sth->execute();
					
						echo "Validation de la suppression faite";
				
					} catch (Exception $e) {
					
						echo "la suppression a échouée: " . $e->getMessage();
					}
				}
}
			
				
			?>	