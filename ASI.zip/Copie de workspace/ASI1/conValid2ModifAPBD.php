<?php	

if(!empty($_POST["soumet"]))
{

					$Appli_idAppli = $_POST["Appli_idAppli"];
					$Basdon_idBasdon = $_POST["Basdon_idBasdon"];
					
					
					
					$indic_Appli_has_Basdon = 0;
						
					if(!empty($_POST["indic_Appli_has_Basdon"]))
					{
						$indic_Appli_has_Basdon=1;
							
					}
				
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE APPLI_has_BASDON SET '.
							' indicAPPLI_has_BASDON ="'.$indic_Appli_has_Basdon.'"'.
							
								' WHERE APPLI_idAPPLI = :Appli_idAppli
										AND BASDON_idBASDON = :Basdon_idBasdon';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':Appli_idAppli', $Appli_idAppli, PDO::PARAM_INT);
					$sth->bindValue(':Basdon_idBasdon', $Basdon_idBasdon, PDO::PARAM_INT);
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	