<?php	

if(!empty($_POST["soumet"]))
{

					$idDiffusion = $_POST["idDiffusion"];
					
					
					if(!empty($_POST["nomDiffusion"]))
					{
						$nomDiffusion=$_POST["nomDiffusion"];
					} else 
					{ 
						$nomDiffusion = null;
					}
					
					if(!empty($_POST["libelleDiffusion"]))						
					{
						$libelleDiffusion=$_POST["libelleDiffusion"];
					} else
					{
						$libelleDiffusion = null;
					}
					
					if(!empty($_POST["adresseDiffusion"]))
					{
						$adresseDiffusion=$_POST["adresseDiffusion"];
					} else
					{
						$adresseDiffusion = null;
					}
					if(!empty($_POST["codPostDiffusion"]))
					{
						$codPostDiffusion=$_POST["codPostDiffusion"];
					} else
					{
						$codPostDiffusion = null;
					}
					if(!empty($_POST["communeDiffusion"]))
					{
						$communeDiffusion=$_POST["communeDiffusion"];
					} else
					{
						$communeDiffusion= null;
					}
					if(!empty($_POST["nomEtabDiffusion"]))
					{
						$nomEtabDiffusion=$_POST["nomEtabDiffusion"];
					} else
					{
						$nomEtabDiffusion = null;
					}
					
					
						
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE DIFFUSION SET '.
							' nomDIFFUSION ="'.$nomDiffusion.'",'.
							' libelleDIFFUSION ="'.$libelleDiffusion.'",'.
							' adresseDIFFUSION ="'.$adresseDiffusion.'",'.
							' codPostDIFFUSION ="'.$codPostDiffusion.'",'.
							' communeDIFFUSION ="'.$communeDiffusion.'",'.
							' nomEtabDIFFUSION ="'.$nomEtabDiffusion.'" '.
								' WHERE idDIFFUSION = :idDiffusion ';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idDiffusion', $idDiffusion, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	