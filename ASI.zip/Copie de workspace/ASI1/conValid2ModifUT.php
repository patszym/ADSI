<?php	
include 'include/encrypt_decrypt.php';
if(!empty($_POST["soumet"]))
{

					$idUti = $_POST["idUti"];
					
					
					if(!empty($_POST["nomUti"]))
					{
						$nomUti=$_POST["nomUti"];
					} else 
					{ 
						$nomUti = null;
					}
					
					if(!empty($_POST["prenomUti"]))						
					{
						$prenomUti=$_POST["prenomUti"];
					} else
					{
						$prenomUti = null;
					}
					if(!empty($_POST["telephoneUti"]))
					{
						$telephoneUti=$_POST["telephoneUti"];
					} else
					{
						$telephoneUti = null;
					}
					if(!empty($_POST["emailUti"]))
					{
						$emailUti=$_POST["emailUti"];
					} else
					{
						$emailUti = null;
					}
					if(!empty($_POST["datemodifUti"]))
					{
						$datemodifUti=$_POST["datemodifUti"];
					} else
					{
						$datemodifUti = null;
					}
					
					if(!empty($_POST["loginUti"]))
					{
						$loginUti=$_POST["loginUti"];
					} else
					{
						$loginUti = null;
					}
					$mdpChiffreUti = null;
					if(!empty($_POST["mdpDecryptUti"]))
					{
						$mdpDecryptUti=$_POST["mdpDecryptUti"];
					
						
						
						$plain_txt = $mdpDecryptUti; 

						$encrypted_txt = encrypt_decrypt('encrypt', $plain_txt);
					
							$mdpChiffreUti = $encrypted_txt;


					} else
					{
						$mdpUti = null;
					}
					
					$datemodifUti = date("Y-m-d H:i:s");
					
					$adm = 0;
					
					if(!empty($_POST["choix1"]))
					{
						$adm=1;
					
							
					}
						
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE UTI SET '.
							' nomUTI ="'.$nomUti.'",'.
							' prenomUTI ="'.$prenomUti.'",'.
							' telephoneUTI ='.$telephoneUti.','.
							' emailUTI ="'.$emailUti.'",'.
							' datemodifUTI ="'.$datemodifUti.'",'.
							
							' loginUTI ="'.$loginUti.'", '.
							' mdpUTI ="'.$mdpChiffreUti.'" '.
								' WHERE idUTI = :idUti ';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idUti', $idUti, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	