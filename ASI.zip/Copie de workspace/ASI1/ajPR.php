<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Projets
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css">
	<style type="text/css">    
		div.ui-datepicker{
		font-size: 12px;
	}
	</style>
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
	<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
	<script src="jquery.ui.datepicker-fr.js"></script>
	<script>
		$(function() {
		$("#calendrier1").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		$(function() {
		$("#calendrier2").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
	</script>
	
</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> Il faut valider l'ajout pour achever la tâche (bouton <b> valider </b>)</p>
			
			<p>Cliquez sur l'onglet <b>Liste et Edition </b> pour une consultation, 
			une modification, ou une suppression </p>
			<p> Cliquez sur l'onglet <b> Ajout </b> pour créer une occurence de Projet</p>
			
	</div><!-- #secondaire -->

	<div id="principal"> 
			<h5>Gestion des projets</h5>
			
			
			<div id="tabsF">
				<?php include('include/MHPR.php'); ?> 
			<fieldset class="saisie">
			
			<form name="ajPR" id="ajPRForm" method="post"
				 enctype="multipart/form-data" 
					action="ajPR2.php">
					
				<table BORDER=0>	
					<!-- ajout Projet - formulaire -->
				
					<tr>
						<td> nom du projet :</td>
						<td>
							<input type="text" name="nomProjet" 
							value="" required="required" maxlength="25" 
							autofocus size="20">
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Libellé du projet :</td>
						<td>
							<input type="text" name="libelleProjet" 
							value="" required="required" maxlength="100" size="60">
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Contexte du projet :</td>
						<td>
							<textarea name = "contexteProjet" rows="11" cols="50" >
							</textarea>
						</td>
					</tr>
					<tr>
						
						<td>
							<input type="checkbox" name="indLocalProjet" value="1"> 
							Indicateur projet local
							</input>
						</td>
					</tr>
					<tr>
						
						<td>
							<input type="checkbox" name="indNationalProjet" value="1"> 
							Indicateur projet national
							</input>
						</td>
					</tr>
					<tr>
						
						<td>
							<input type="checkbox" name="indInterAcaProjet" value="1"> 
							Indicateur projet inter-académique
							</input>
						</td>
					</tr>
					<tr>
						<td> Date de la demande : </td>
						<td>
							<INPUT type=text id="calendrier1" 
							name="dateDemandeProjet" value="" maxlength="10" size="10">
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Date de Fin :</td>
						<td>
							<INPUT type=text id="calendrier2" 
							name="dateFinProjet" value="" maxlength="10" size="10">
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Demande :</td>
						<td>
							
							<input type="file" name="demFormProjet" id="demFormProjet" />
							</input> 
						</td>
					</tr>
					<tr>
						<td> Cahier de charges :</td>
						<td>
							
							<input type="file" name="cdcFormProjet">
							</input>
						</td>
					</tr>
					<tr>
						<td> Documentation :</td>
						<td>
							
							<input type="file" name="docFormProjet">
							</input>
						</td>
					</tr>
					<tr>
						<td>
						
					<input type="submit" value="Valider" name="soumet">
					</input>
						</td>
						<td>
					
					<input type="submit" value="Annuler">
					</input>
						</td>
					</tr>
				</table>			
					
					
					
			</form>
			
		</fieldset>
		</div>
	</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	

</div><!-- #global -->

</body>
</html>
