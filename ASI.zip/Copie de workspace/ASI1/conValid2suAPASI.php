<?php	
			  
if(!empty($_POST["soumet"]))
{
					
					
					if(!empty($_POST["Appli_idAppli"]))
					{
						$Appli_idAppli=$_POST["Appli_idAppli"];
						
					}
					if(!empty($_POST["Asi_idAsi"]))
					{
						$Asi_idAsi=$_POST["Asi_idAsi"];
						
					}
					
					
					
					include('include/connBase.php');
					
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					
						$sql = 'DELETE FROM APPLI_has_ASI 
								WHERE APPLI_idAPPLI = :Appli_idAppli 
						AND ASI_idASI = :Asi_idAsi ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':Appli_idAppli', $Appli_idAppli, PDO::PARAM_INT);
						$sth->bindValue(':Asi_idAsi', $Asi_idAsi, PDO::PARAM_INT);
						$sth->execute();
						
						echo "Validation de la suppression faite";
				
					} catch (Exception $e) {
					
						echo "la suppression a échouée: " . $e->getMessage();
					}
				
}
			
				
			?>	