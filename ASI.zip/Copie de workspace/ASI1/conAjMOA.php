<?php	
			  
				
					$idMoa = null;
					
					if(!empty($_POST["idDivision"]))
					{
						$idDivision=$_POST["idDivision"];
					} else
					{
						$idDivision = null;
					}
					
					if(!empty($_POST["nomMoa"]))
					{
						$nomMoa=$_POST["nomMoa"];
					} else 
					{ 
						$nomMoa = null;
					}
					
					if(!empty($_POST["prenomMoa"]))						
					{
						$prenomMoa=$_POST["prenomMoa"];
					} else
					{
						$prenomMoa = null;
					}
					
					
					if(!empty($_POST["emailMoa"]))
					{
						$emailMoa=$_POST["emailMoa"];
					} else
					{
						$emailMoa = null;
					}
					if(!empty($_POST["telFixeMoa"]))
					{
						$telFixeMoa=$_POST["telFixeMoa"];
					
					
					} else
					{
						$telFixeMoa = null;
					}
					if(!empty($_POST["telMobMoa"]))
					{
						$telMobMoa=$_POST["telMobMoa"];
							
							
					} else
					{
						$telMobMoa = null;
					}
						
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idMOA) FROM MOA ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idMoa = $gid->fetchColumn();
					
					
					
					$idMoa ++ ;
					
					
					
					$sql = 'insert into MOA values ("'.$idMoa.'",'.
							'"'.$idDivision.'",'.
							'"'.$nomMoa.'",'.
							'"'.$prenomMoa.'",'.
							'"'.$emailMoa.'",'.
							'"'.$telFixeMoa.'",'.
							'"'.$telMobMoa.'"'.
							
							");"   ;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
	?>	