<!DOCTYPE html PUBLIC "-//W3C//Dtd XHTML 1.0 Strict//EN"
	"http://www.w3.org/tr/xhtml1/Dtd/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Contacts - consultation
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />


</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Contactlisation</h3>
			<p>Cliquez sur l'onglet <b>Liste et Edition </b> pour une autre consultation, 
			une modification, ou une suppression </p>
			<p> Cliquez sur l'onglet <b> Ajout </b> pour créer une occurence de Base de données</p>
			
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5>Gestion des contacts de la diffusion </h5>
			
			<div id="tabsF">
				<?php include('include/MHCO.php'); ?> 
			</div>
				<?php
				include('include/con2CO.php');
				include('include/con1CODI.php'); 
				include('include/con5COAP.php');
				include('include/con4COAP.php');
				?> 	
			<fieldset class="saisie">	
			
					
			<form name="consContact" id="consContactForm" method="post"
				 enctype="multipart/form-data" 
					action="ajAPsCO.php">
				<table border=0>
								<input type="hidden" name="idContact" 
			 					value="<?php echo htmlspecialchars($idContact); ?>">
			 					</input>	
					<tr>
					<td>Organisme de diffusion du contact :</td>
						<td>
						 <select   name="idDiffusion" disabled>
							<?php
							
							$i = 0;
							while ($i<$index1)
							{
					
								 	echo '<option value="'.
										$tableau1 [$i][0].'"'.$tableau1 [$i][2].'>'.
										$tableau1 [$i][1].'</option>';
										
								$i++;
							}
							?>
						</select>
						</td>
					</tr>
					
					<tr>
						<td> Nom du contact :</td>
						<td>
							<input type=text name="nomContact" 
							value="<?php echo htmlspecialchars($nomContact); ?>"
							 maxlength="50" size="50" readonly></input>
						</td>
					</tr>
						<tr>
						<td> prénom du contact :</td>
						<td>
							<input type=text name="prenomContact" 
							value="<?php echo htmlspecialchars($prenomContact); ?>"
							 maxlength="50" size="50" readonly></input>
						</td>
					</tr>				
					
					<tr>
						<td> téléphone du contact :</td>
						<td>
						<input type=text name="telephoneContact" 
							value="<?php echo htmlspecialchars($telephoneContact); ?>" 
							maxlength="80" size="50" readonly></input>
						</td>
					</tr>
					<tr>
						<td> email du contact :</td>
						<td>
						<input type=text name="emailContact" 
							value="<?php echo htmlspecialchars($emailContact); ?>" 
							maxlength="80" size="50" readonly></input>
						</td>
					</tr>
					<tr>
						<td>Sous domaine Fonctionnel du contact :</td>
						<td>
						<input type=text name="ssDomFoncContact" 
							value="<?php echo htmlspecialchars($ssDomFoncContact); ?>" 
							maxlength="80" size="50" readonly></input>
						</td>
					</tr>
					<tr>
						
						<td>
						
						<?php if (!$FonctionnelContact): ?>
						
							<input type="checkbox" name="choix1" value="1" disabled="disabled"> Fonctionnel
							</input>
							<?php else: ?>
							
							<input type="checkbox" name="choix1" value="1" checked disabled="disabled"> Fonctionnel
							</input>
						<?php endif ?>
						</td>
					</tr>
					<tr>
						
						<td>
							<?php if (!$InformatiqueContact): ?>
						
							<input type="checkbox" name="choix2" value="1" disabled="disabled"> Informatique
							</input>
							<?php else: ?>
						
							<input type="checkbox" name="choix2" value="1" checked disabled="disabled"> Informatique
							</input>
						<?php endif ?>
						</td>
					</tr>
					
					
					
					<?php 
							$i = 0 ;
						
							while ($i < $index9) 
							{
								$idAppli = $tableau9[$i][0];
								
						?>
					<tr>
						<td></td>
						<td>
							<input type="checkbox" name=
							"<?php echo "idAp[]" ?>" 
							value="
							
							<?php
							
								echo $tableau9[$i][0] ;
							?>
							"
							<?php 
								if ($tableau9[$i][2]== true) 
								{
									echo " checked ";
									
								}
								
								
							?>
									
							> 
							<?php
							
								echo $tableau9[$i][1] ; 
							?>
							</input>
						</td>
					</tr>
					<tr>	
						<?php 
							$i++;
							
							}
							?>
							
						<td>
							<input type="submit" value="Valider" name="soumet">
							</input>
							<input type="submit" value="Annuler" name="annule">
							</input>
						</td>
					</tr>
					
				</table>	
			</form>
			
			
			</fieldset>	
			
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	
</div><!-- #global -->

</body>
</html>
<?php
/*

When using checkboxes as an array:

<input type="checkbox" name="food[]" value="Orange">
<input type="checkbox" name="food[]" value="Apple">

You should use in_array():

if(in_array('Orange', $_POST['food'])){
	echo 'Orange was checked!';
}

Remember to check the array is set first, such as:

if(isset($_POST['food']) && in_array(...

		shareimprove this answer

*/
?>
