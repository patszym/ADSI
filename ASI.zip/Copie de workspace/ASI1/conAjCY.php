<?php	
			  
				
					$idCycle = null;
					
					
					if(!empty($_POST["libelleCourtCycle"]))
					{
						$libelleCourtCycle=$_POST["libelleCourtCycle"];
					} else 
					{ 
						$libelleCourtCycle = null;
					}
					
					if(!empty($_POST["libelleLongCycle"]))						
					{
						$libelleLongCycle=$_POST["libelleLongCycle"];
					} else
					{
						$libelleLongCycle = null;
					}
					
					
					
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idCYCLE) FROM CYCLE ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idCycle = $gid->fetchColumn();
					
					
					
					$idCycle ++ ;
					
					
					$sql = 'insert into CYCLE values ("'.$idCycle.'",'.
							'"'.$libelleCourtCycle.'","'.$libelleLongCycle.'"'.
							
							');'   ;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
			?>	