<?php	
			  
if(!empty($_POST["soumet"]))
{
					$idAppli = null;
					
					
					if(!empty($_POST["idAppli"]))
					{
						$idAppli=$_POST["idAppli"];
					} 
					
					include('include/connBase.php');
					
					// Contrôles de cohérence de la base pour les clés étrangères déclarées dans les autres tables
					// à la suppression. Normalement c'est fait des triggers (sous Oracle), mais pas sur Mysql
					// donc la cohérence de la base est assurée au niveau de la programmation
					// ---> clé étrangère de APPLI dans la table APPLI
					
					$validBase = true;
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM APPLI_has_BASDON WHERE APPLI_idAPPLI = :idAppli ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
						
					
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table APPLI_has_BASDON utilise(nt) cette réference APPLI <br>";
						?>
								<script language="javascript">
								alert("La suppression est impossible car il y a une référence dans la table application exploitant cette occurence de Diffusion");
								</script>
							<?php
					}
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM APPLI_has_BASDON WHERE APPLI_idAPPLI = :idAppli ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
					
							
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table APPLI_has_BASDON utilise(nt) cette réference APPLI <br>";
						?>
						<script language="javascript">
						alert("La suppression est impossible car il y a une référence dans la table APPLI_has_BASDON exploitant cette occurence de Diffusion");
						</script>
						<?php
					}
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM APPLI_has_PROJET WHERE APPLI_idAPPLI = :idAppli ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
							
							
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table APPLI_has_PROJET utilise(nt) cette réference APPLI <br>";
						?>
						<script language="javascript">
						alert("La suppression est impossible car il y a une référence dans la table APPLI_has_PROJET exploitant cette occurence de Diffusion");
						</script>
						<?php
					}
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM APPLI_has_PROJET WHERE APPLI_idAPPLI = :idAppli ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
							
							
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table APPLI_has_PROJET utilise(nt) cette réference APPLI <br>";
						?>
						<script language="javascript">
						alert("La suppression est impossible car il y a une référence dans la table APPLI_has_PROJET exploitant cette occurence de Diffusion");
						</script>
						<?php
					}
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM APPLI_has_ASI WHERE APPLI_idAPPLI = :idAppli ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
							
							
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table APPLI_has_ASI utilise(nt) cette réference APPLI <br>";
						?>
						<script language="javascript">
						alert("La suppression est impossible car il y a une référence dans la table APPLI_has_ASI exploitant cette occurence de Diffusion");
						</script>
						<?php
					}
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM TRAITMAJ WHERE APPLI_idAPPLI = :idAppli ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
							
							
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table TRAITMAJ utilise(nt) cette réference APPLI <br>";
						?>
						<script language="javascript">
						alert("La suppression est impossible car il y a une référence dans la table TRAITMAJ exploitant cette occurence de Diffusion");
						</script>
						<?php
					}
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM TRAITLOCAL WHERE APPLI_idAPPLI = :idAppli ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
							
							
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table TRAITLOCAL utilise(nt) cette réference APPLI <br>";
						?>
						<script language="javascript">
						alert("La suppression est impossible car il y a une référence dans la table TRAITLOCAL exploitant cette occurence de Diffusion");
						</script>
						<?php
					}
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM CALENDRIER WHERE APPLI_idAPPLI = :idAppli ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
							
							
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table CALENDRIER utilise(nt) cette réference APPLI <br>";
						?>
						<script language="javascript">
						alert("La suppression est impossible car il y a une référence dans la table CALENDRIER exploitant cette occurence de Diffusion");
						</script>
						<?php
					}
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM CAMPAGNE WHERE APPLI_idAPPLI = :idAppli ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
							
							
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table CAMPAGNE utilise(nt) cette réference APPLI <br>";
						?>
						<script language="javascript">
						alert("La suppression est impossible car il y a une référence dans la table CAMPAGNE exploitant cette occurence de Diffusion");
						</script>
						<?php
					}
					
					
					
					
					
					// Si la suppression est possible
					
				if ($validBase)
				{
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					
						$sql = 'DELETE FROM APPLI WHERE idAPPLI = :idAppli ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
					
						$sth->execute();
					
						echo "Validation de la suppression faite";
				
					} catch (Exception $e) {
					
						echo "la suppression a échouée: " . $e->getMessage();
					}
				}
}
			
				
			?>	