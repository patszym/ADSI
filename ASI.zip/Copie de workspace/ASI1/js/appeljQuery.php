
<script type="text/javascript"
		src="/js/jquery.js"></script>
		