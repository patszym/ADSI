<?php	
if (!empty( $_POST['soumet'] ))
{
	include 'include/encrypt_decrypt.php';			  
				
					$idUti = null;
					
					
					if(!empty($_POST["nomUti"]))
					{
						$nomUti=$_POST["nomUti"];
					} else 
					{ 
						$nomUti = null;
					}
					
					if(!empty($_POST["prenomUti"]))						
					{
						$prenomUti=$_POST["prenomUti"];
					} else
					{
						$prenomUti = null;
					}
					if(!empty($_POST["telephoneUti"]))
					{
						$telephoneUti=$_POST["telephoneUti"];
					} else
					{
						$telephoneUti = null;
					}
					if(!empty($_POST["emailUti"]))
					{
						$emailUti=$_POST["emailUti"];
					} else
					{
						$emailUti = null;
					}
					
					if(!empty($_POST["loginUti"]))
					{
						$loginUti=$_POST["loginUti"];
					} else
					{
						$loginUti = null;
					}
					
					if(!empty($_POST["mdpUti"]))
					{
						$mdpUti=$_POST["mdpUti"];
					
						
						
						$plain_txt = $mdpUti; 

						$encrypted_txt = encrypt_decrypt('encrypt', $plain_txt);
					
							$mdpChiffreUti = $encrypted_txt;


					} else
					{
						$mdpChiffreUti = null;
					}
					
					$datemodifUti = date("Y-m-d H:i:s");
				
					
					
				
					
					include('include/connBase.php');
					$validBase = true;
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM UTI WHERE nomUTI = :nomUti
								AND prenomUTI = :prenomUti';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':nomUti', $nomUti, PDO::PARAM_INT);
						$sth->bindValue(':prenomUti', $prenomUti, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
							
							
							
							
							
					} catch (Exception $e) {
							
						echo "une occurence de meme nom et de meme prenom a été trouvée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo  " au moins 1 occurence(s) dans la table UTI utilise(nt) ces réferences, mêmes nom et prénom <br>";
							
						?>
																															<script language="javascript">
																															alert("au moins 1 occurence(s) dans la table UTI utilise(nt) ces réferences, mêmes nom et prénom ");
																															</script>
																				<?php
																				}
																									
																				
										
				if ($validBase)
				{
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idUTI) FROM UTI ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idUti = $gid->fetchColumn();
					
					
					
					$idUti ++ ;
					
					
					$sql = 'insert into UTI values ("'.$idUti.'",'.
							'"'.$nomUti.'","'.$prenomUti.'",'.
							'"'.$telephoneUti.'",'.
							'"'.$emailUti.'",'.
							
							'"'.$loginUti.'",'.
							'"'.$mdpChiffreUti.'",null,null,'.
							'"'.$datemodifUti.'"'.
							
							');'   ;
					 // echo $sql;
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
					$mdpDecryptUti = $mdpUti;
					// include 'include/envoiMail.php';
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
}
				
			?>	