<?php	
			  
if(!empty($_POST["soumet"]))
{
					$idContact = null;
					
					
					if(!empty($_POST["idContact"]))
					{
						$idContact=$_POST["idContact"];
					} 
					
					include('include/connBase.php');
					
					// Contrôles de cohérence de la base pour les clés étrangères déclarées dans les autres tables
					// à la suppression. Normalement c'est fait des triggers (sous Oracle), mais pas sur Mysql
					// donc la cohérence de la base est assurée au niveau de la programmation
					// ---> clé étrangère de COFFUSION dans la table APPLI
					
					$validBase = true;
					
				if ($validBase)
				{
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					
						$sql = 'DELETE FROM CONTACT WHERE idCONTACT = :idContact ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idContact', $idContact, PDO::PARAM_INT);
					
						$sth->execute();
					
						echo "Validation de la suppression faite";
				
					} catch (Exception $e) {
					
						echo "la suppression a échouée: " . $e->getMessage();
					}
				}
}
			
				
			?>	