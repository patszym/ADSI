<?php	

include 'include/encrypt_decrypt.php';			  
				
					$idBasdon = null;
					
					
					if(!empty($_POST["nomBasdon"]))
					{
						$nomBasdon=$_POST["nomBasdon"];
					} else 
					{ 
						$nomBasdon = null;
					}
					
					if(!empty($_POST["libelleBasdon"]))						
					{
						$libelleBasdon=$_POST["libelleBasdon"];
					} else
					{
						$libelleBasdon = null;
					}
					
					if(!empty($_POST["servBasdon"]))
					{
						$servBasdon=$_POST["servBasdon"];
					} else
					{
						$servBasdon = null;
					}
					if(!empty($_POST["emplBasdon"]))
					{
						$emplBasdon=$_POST["emplBasdon"];
					} else
					{
						$emplBasdon = null;
					}
					if(!empty($_POST["chemShellBasdon"]))
					{
						$chemShellBasdon=$_POST["chemShellBasdon"];
					} else
					{
						$chemShellBasdon = null;
					}
					if(!empty($_POST["loginBasdon"]))
					{
						$loginBasdon=$_POST["loginBasdon"];
					} else
					{
						$loginBasdon = null;
					}
					
					if(!empty($_POST["mdpBasdon"]))
					{
						$mdpBasdon=$_POST["mdpBasdon"];
					
						
						
						$plain_txt = $mdpBasdon; 

						$encrypted_txt = encrypt_decrypt('encrypt', $plain_txt);
					
							$mdpChiffreBasdon = $encrypted_txt;


					} else
					{
						$mdpChiffreBasdon = null;
					}
					
					
					
					
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idBASDON) FROM BASDON ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idBasdon = $gid->fetchColumn();
					
					
					
					$idBasdon ++ ;
					
					
					$sql = 'insert into BASDON values ("'.$idBasdon.'",'.
							'"'.$nomBasdon.'","'.$libelleBasdon.'",'.
							'"'.$servBasdon.'",'.
							'"'.$emplBasdon.'",'.
							'"'.$chemShellBasdon.'",'.
							'"'.$loginBasdon.'",'.
							'"'.$mdpChiffreBasdon.'"'.
							');'   ;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
			?>	