<?php
if (!empty( $_POST['soumet'] ))
{
				include 'include/encrypt_decrypt.php';
				
					if(!empty($_POST["loginAdm"]))

					{
						$loginAdm=$_POST["loginAdm"];
					} else 
					{ 
						$loginAdm = 0;
					}
									
					
					
					if(!empty($_POST["mdpAdm"]))
					{
						$mdpAdm=$_POST["mdpAdm"];
							
					
					
						$plain_txt = $mdpAdm;
					
						$encrypted_txt = encrypt_decrypt('encrypt', $plain_txt);
							
						$mdpChiffreAdm = $encrypted_txt;
					
					
					} else
					{
						$mdpChiffreAdm = null;
					}
											
					
						
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
					$validBase = true;
					$nbOccur = 0;
				
				
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT count(*) FROM ADM where loginADM = :loginAdm";
							
					
					$gid = $dbh->prepare($sql1);
					$gid->bindValue(':loginAdm', $loginAdm, PDO::PARAM_INT);
					
					$gid->execute();
					$nbOccur  = $gid->fetchColumn();
					
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table concernée utilise(nt) cette réference administrateur <br>";
						?>
						<script language="javascript">
						alert("L'ajout est impossible car il y a au moins une référence identique administrateur");
						</script>
						<?php
					}
					
					
			
					if ($validBase)
					{
						// ajout
						include('include/connBase.php');
						
						try {
							$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						
							$dbh->beginTransaction();
								
							$sql1= "SELECT max(idADM) FROM ADM ";
								
							$gid = $dbh->prepare($sql1);
							$gid->execute();
							$idAdm = $gid->fetchColumn();
								
								
								
							$idAdm ++ ;
								
								
							$sql = 'insert into ADM values ('.$idAdm.',"'
							.$loginAdm.'", "'.$mdpChiffreAdm.'");'   ;
						
							$dbh->exec($sql);
						
									$dbh->commit();
									echo "Validation de l'Ajout faite";
						
						} catch (Exception $e) {
							$dbh->rollBack();
							echo "la saisie a échouée: " . $e->getMessage();
						}
						// fin de l'ajout
					
					}
				
			}
}		
	?>	