<?php	
	  
if(!empty($_POST["soumet"]))
{
					$idUti = null;
					
					
					if(!empty($_POST["idUti"]))
					{
						$idUti=$_POST["idUti"];
					} 
					
					include('include/connBase.php');
					
					// Contrôles de cohérence de la base pour les clés étrangères déclarées dans les autres tables
					// à la suppression. Normalement c'est fait des triggers (sous Oracle), mais pas sur Mysql
					// donc la cohérence de la base est assurée au niveau de la programmation
					// ---> clé étrangère de UTI dans la table APPLI
					
					$validBase = true;
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM APPLI_has_UTI WHERE UTI_idUTI = :idUti ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idUti', $idUti, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
							
						
							
						
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table APPLI_has_UTI utilise(nt) cette réference UTI <br>";
						echo "Remède : Aller dans Application et supprimer le lien avec l'application concernée";
						echo " Puis revennir ici pour procéder à la suppression de l'occurence de la base de données.";
						?>
											<script language="javascript">
											alert("La suppression est impossible car il y a une référence dans la table application exploitant cette occurence de Uti");
											</script>
							
						<?php
					}
				if ($validBase)
				{
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					
						$sql = 'DELETE FROM UTI WHERE idUTI = :idUti ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idUti', $idUti, PDO::PARAM_INT);
					
						$sth->execute();
					
						echo "Validation de la suppression faite";
				
					} catch (Exception $e) {
					
						echo "la suppression a échouée: " . $e->getMessage();
					}
				}
}
			
				
			?>	