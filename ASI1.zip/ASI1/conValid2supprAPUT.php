<?php	
			  
if(!empty($_POST["soumet"]))
{
					
					
					if(!empty($_POST["Appli_idAppli"]))
					{
						$Appli_idAppli=$_POST["Appli_idAppli"];
						
					}
					if(!empty($_POST["Uti_idUti"]))
					{
						$Uti_idUti=$_POST["Uti_idUti"];
						
					}
					
					
					
					include('include/connBase.php');
					
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					
						$sql = 'DELETE FROM APPLI_has_UTI 
								WHERE APPLI_idAPPLI = :Appli_idAppli 
						AND UTI_idUTI = :Uti_idUti ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':Appli_idAppli', $Appli_idAppli, PDO::PARAM_INT);
						$sth->bindValue(':Uti_idUti', $Uti_idUti, PDO::PARAM_INT);
						$sth->execute();
						
						echo "Validation de la suppression faite";
				
					} catch (Exception $e) {
					
						echo "la suppression a échouée: " . $e->getMessage();
					}
				
}
			
				
			?>	