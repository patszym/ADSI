<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		APCOs
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> Il faut valider la suppression pour achever la tâche (bouton <b> valider </b>)</p>
			<p>	Cliquez sur l'onglet <b>Liste et Edition </b> pour une consultation, une modification, ou 
			une autre suppression</p>
			<p>	Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence de APCO </p>
		
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5>Gestion des rattachements application et projet</h5>
			
			<br><br>
			
				<?php include('include/con2APCO.php'); ?>
				
				
				<?php include('include/con1APAP.php'); ?>
				
				<?php include('include/con1APCOCO.php'); ?>  
			<fieldset class="saisie">
		
			<form name="supprvalidAPCO" id="supprvalidAPCOForm" method="post"
				 enctype="multipart/form-data" 
					action="valid2supprAPCO.php">
				<table BORDER=0>		
				
				
				
					<tr>
					<td>Application :</td>
						<td>
						 <select   name="idRowAppli" disabled>
							<?php
							
							$i = 0;
							while ($i<$index1)
							{
					
								 	echo '<option value="'.
										$tableau1 [$i][0].'"'.$tableau1 [$i][2].'>'.
										$tableau1 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
					<input type="hidden" name="Appli_idAppli" 
						value="<?php echo htmlspecialchars($Appli_idAppli); ?>">
						</input>
						
					<td>Base de données :</td>
						<td>
						 <select   name="idRowContact" disabled>
							<?php
							
							$i = 0;
							while ($i<$index2)
							{
					
								 	echo '<option value="'.
										$tableau2 [$i][0].'"'.$tableau2 [$i][2].'>'.
										$tableau2 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
					<input type="hidden" name="Contact_idContact" 
						value="<?php echo htmlspecialchars($Contact_idContact); ?>">
						</input>
					
				
							
					<tr>
						<td> 
							
					<input type="submit" value="Valider" name="soumet">
					</input>
						</td>
								
						<td> 
					<input type="submit" value="Annuler">
					</input>
						
				
						</td>
					</tr>
				</table>
			</form>
			
		</fieldset>
			
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
