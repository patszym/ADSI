<?php	
			  
				
					$idContact = null;
					
					if(!empty($_POST["idDiffusion"]))
					{
						$idDiffusion=$_POST["idDiffusion"];
					} else
					{
						$idDiffusion = null;
					}
					
					if(!empty($_POST["nomContact"]))
					{
						$nomContact=$_POST["nomContact"];
					} else 
					{ 
						$nomContact = null;
					}
					
					if(!empty($_POST["prenomContact"]))						
					{
						$prenomContact=$_POST["prenomContact"];
					} else
					{
						$prenomContact = null;
					}
					
					if(!empty($_POST["telephoneContact"]))
					{
						$telephoneContact=$_POST["telephoneContact"];
						
						
					} else
					{
						$telephoneContact = null;
					}
					if(!empty($_POST["emailContact"]))
					{
						$emailContact=$_POST["emailContact"];
					} else
					{
						$emailContact = null;
					}
					if(!empty($_POST["ssDomFoncContact"]))
					{
						$ssDomFoncContact=$_POST["ssDomFoncContact"];
					} else
					{
						$ssDomFoncContact = null;
					}
					$fonctionnel = 0;
					$informatique = 0;
					if(!empty($_POST["FonctionnelContact"]))
					{
						$fonctionnel=1;
					
					}
					if(!empty($_POST["InformatiqueContact"]))
					{
						$informatique=1;
						
					}
					
						
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idCONTACT) FROM CONTACT ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idContact = $gid->fetchColumn();
					
					
					
					$idContact ++ ;
					
					
					
					$sql = 'insert into CONTACT values ("'.$idContact.'",'.
							'"'.$idDiffusion.
							'","'.$nomContact.
							'","'.$prenomContact.
							'","'.$telephoneContact.'",'.
							'"'.$emailContact.'",'.
							'"'.$ssDomFoncContact.'",'.
				
							$fonctionnel.",".$informatique.
							");"   ;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
	?>	