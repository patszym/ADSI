<!DOCTYPE html PUBLIC "-//W3C//Dtd XHTML 1.0 Strict//EN"
	"http://www.w3.org/tr/xhtml1/Dtd/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Basdons - consultation
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />


</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p>Cliquez sur l'onglet <b>Liste et Edition </b> pour une autre consultation, 
			une modification, ou une suppression </p>
			<p> Cliquez sur l'onglet <b> Ajout </b> pour créer une occurence de Base de données</p>
			
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5>Gestion des bases de données </h5>
			
			<div id="tabsF">
				<?php include('include/MHBD.php'); ?> 
			</div>
				<?php
				include('include/con2BD.php');
				include('include/con5BDAP.php');
				include('include/con4BDAP.php');
				?> 	
			<fieldset class="saisie">	
			
					
			<form name="consBasdon" id="consBasdonForm" method="post"
				 enctype="multipart/form-data" 
					action="ajAPsBD.php">
				<table border=0>
								<input type="hidden" name="idBasdon" 
			 					value="<?php echo htmlspecialchars($idBasdon); ?>">
			 					</input>	
					<tr>
						<td> Nom de la base de données :</td>
						<td>
							<input type=text name="nomBasdon" 
							value="<?php echo htmlspecialchars($nomBasdon); ?>"
							 maxlength="20" size="20" readonly></input>
						</td>
					</tr>
					<tr>
						<td> Libellé du la base de données :</td>
						<td>
							<input type=text name="libelleBasdon" 
							value="<?php echo htmlspecialchars($libelleBasdon); ?>"
							 maxlength="100" size="50" readonly></input>
						</td>
					</tr>				
					
					<tr>
						<td> Serveur de la base de données  :</td>
						<td>
						<input type=text name="servBasdon" 
							value="<?php echo htmlspecialchars($servBasdon); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
					</tr>
					<tr>
						<td> Emplacement :</td>
						<td>
						<input type=text name="emplBasdon" 
							value="<?php echo htmlspecialchars($emplBasdon); ?>" 
							maxlength="80" size="50" readonly></input>
						</td>
					</tr>
					<tr>
						<td> Chemin vers le shell de sauvegarde :</td>
						<td>
						<input type=text name="chemShellBasdon" 
							value="<?php echo htmlspecialchars($chemShellBasdon); ?>" 
							maxlength="100" size="50" readonly></input>
						</td>
					</tr>
					<tr>
						<td> Login :</td>
						<td>
							<input type=text name="loginBasdon" 
							value="<?php echo htmlspecialchars($loginBasdon); ?>" 
							maxlength="10" size="10" readonly></input>
						</td>
					</tr>
					<tr>
						<td> Mot de passe :</td>
						<td>
							<input type=text name="mdpDecryptBasdon" 
							value="<?php echo $mdpDecryptBasdon; ?>" 
							maxlength="40" size="40" readonly></input>
						</td>
					</tr>
					
					<?php 
							$i = 0 ;
						
							while ($i < $index1) 
							{
								$idAppli = $tableau1[$i][0];
								
						?>
					<tr>
						
						<td>
							<input type="checkbox" name=
							 "idAp[]"  
							value="
							
							<?php
							
								echo $tableau1[$i][0] ;
							?>
							"
							<?php 
								if ($tableau1[$i][2]== true) 
								{
									echo " checked ";
									
								}
								
								
							?>
									
							> 
							<?php
							
								echo $tableau1[$i][1] ; 
							?>
							</input>
							
						
						</td>
						<td>
							<label>
							<input type="checkbox" name=
							"indMAJBD[]" 
							value="
							
							<?php
							
								echo $tableau1[$i][0] ;
							?>
							"
							<?php  
							if ($tableau1[$i][3] == "1") 
							{ 
								echo "checked"; 
							}  
							?>
							
							> MAJ dans la base<br></br></input>
							
							</label>
						</td>
						
					</tr>
					<tr>	
						<?php 
							$i++;
							
							}
							
						?>
						
						<td>
							<input type="submit" value="Valider" name="soumet">
							</input>
							<input type="submit" value="Annuler" name="annule">
							</input>
						</td>
					</tr>
					
				</table>	
			</form>
			
			
			</fieldset>	
			
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	
</div><!-- #global -->

</body>
</html>
<?php
/*

When using checkboxes as an array:

<input type="checkbox" name="food[]" value="Orange">
<input type="checkbox" name="food[]" value="Apple">

You should use in_array():

if(in_array('Orange', $_POST['food'])){
	echo 'Orange was checked!';
}

Remember to check the array is set first, such as:

if(isset($_POST['food']) && in_array(...

		shareimprove this answer

*/
?>
