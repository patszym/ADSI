<?php	
			  
if(!empty($_POST["soumet"]))
{
					$idDiffusion = null;
					
					
					if(!empty($_POST["idDiffusion"]))
					{
						$idDiffusion=$_POST["idDiffusion"];
					} 
					
					include('include/connBase.php');
					
					// Contrôles de cohérence de la base pour les clés étrangères déclarées dans les autres tables
					// à la suppression. Normalement c'est fait des triggers (sous Oracle), mais pas sur Mysql
					// donc la cohérence de la base est assurée au niveau de la programmation
					// ---> clé étrangère de DIFFUSION dans la table APPLI
					
					$validBase = true;
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM APPLI WHERE DIFFUSION_idDIFFUSION = :idDiffusion ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idDiffusion', $idDiffusion, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
							
					
							
					
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table APPLI utilise(nt) cette réference DIFFUSION <br>";
						?>
																<script language="javascript">
																alert("La suppression est impossible car il y a une référence dans la table application exploitant cette occurence de Diffusion");
																</script>
											<?php
					}
					$nbOccur = 0;
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
							
						$sql = 'SELECT COUNT(*) FROM CONTACT WHERE DIFFUSION_idDIFFUSION = :idDiffusion ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idDiffusion', $idDiffusion, PDO::PARAM_INT);
						$sth->execute();
						$nbOccur = $sth->fetchColumn();
							
					
							
					
							
					} catch (Exception $e) {
							
						echo "le contrôle de la clé étrangère a échouée: " . $e->getMessage();
					}
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table CONTACT utilise(nt) cette réference DIFFUSION <br>";
						?>
																<script language="javascript">
																alert("La suppression est impossible car il y a une référence dans la table CONTACT exploitant cette occurence de Diffusion");
																</script>
											<?php
										}
				if ($validBase)
				{
					try {
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					
						$sql = 'DELETE FROM DIFFUSION WHERE idDIFFUSION = :idDiffusion ';
						$sth = $dbh->prepare($sql);
						$sth->bindValue(':idDiffusion', $idDiffusion, PDO::PARAM_INT);
					
						$sth->execute();
					
						echo "Validation de la suppression faite";
				
					} catch (Exception $e) {
					
						echo "la suppression a échouée: " . $e->getMessage();
					}
				}
}
			
				
			?>	