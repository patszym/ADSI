<?php	
include_once('include/ConversionDates.class.php');			  
				
					$idProjet = null;
					
					
					if(!empty($_POST["nomProjet"]))
					{
						$nomProjet=$_POST["nomProjet"];
					} else 
					{ 
						$nomProjet = null;
					}
					
					if(!empty($_POST["libelleProjet"]))						
					{
						$libelleProjet=$_POST["libelleProjet"];
					} else
					{
						$libelleProjet = null;
					}
					if(!empty($_POST["contexteProjet"]))
					{
						$contexteProjet=$_POST["contexteProjet"];
					} else
					{
						$contexteProjet = null;
					}
					$indLocal= 1;
					
					if(!empty($_POST["indLocalProjet"]))
					{
						$indLocal=2;
							
					}
					$indNational= 1;
						
					if(!empty($_POST["indNationalProjet"]))
					{
						$indNational=2;
							
					}
					$indInterAca= 1;
					
					if(!empty($_POST["indInterAcaProjet"]))
					{
						$indInterAca=2;
							
					}
					$dateversRowDemandeProjet  = null;
					$validdateDemandeProjet = true;
					
					if(!empty($_POST["dateDemandeProjet"]))
					{
							
							
						$conversionDate1 = new ConversionDates();
						$conversionDate1->setdt($_POST['dateDemandeProjet']);
						$conversionDate1->initHeure();
						$conversionDate1->convdDate();
						$dateversRowDemandeProjet = $conversionDate1->getdate() ;
						if (!checkdate($conversionDate1->getm(), $conversionDate1->getd(), $conversionDate1->getY()))
						{
								
							$validdateDemandeProjet = false;
							echo $dateDemandeProjet. " n'est pas une date valide <br>";
							?>
								<script language="javascript">
								alert("Date de demande du projet non conforme au format d'une date");													</script>
								<?php
						}
					} 
					else
					{
							$dateversRowDemandeProjet  = null;
					}
					$dateversRowFinProjet  = null;
					$validdateFinProjet = true;
											
					if(!empty($_POST["dateFinProjet"]))
					{
						$conversionDate2 = new ConversionDates();
						$conversionDate2->setdt($_POST['dateFinProjet']);
						$conversionDate2->initHeure();
						$conversionDate2->convdDate();
						$dateversRowFinProjet = $conversionDate2->getdate() ;
								
							if (!checkdate($conversionDate2->getm(), $conversionDate2->getd(), $conversionDate2->getY()))
							{
								$validdateFinProjet = false;
								echo $dateFinProjet. " n'est pas une date valide <br>";
							?>
								<script language="javascript">
								alert("Date de Fin de l'application non conforme au format d'une date");
								</script>
							<?php
							}
																
					} 
					else
					{
						$dateversRowFinProjet  = null;
																
					}
						
						
						// initialisation des attibuts en ajout de table PROJET
						
						$demProjet = null;
						$mimedemProjet = null;
						$sizedemProjet = null;
						$filenamedemProjet = null;
						$extensiondemProjet = null;
						$cdcProjet = null;
						$mimecdcProjet = null;
						$sizecdcProjet = null;
						$filenamecdcProjet = null;
						$extensioncdcProjet = null;
						$docProjet = null;
						$mimedocProjet = null;
						$sizedocProjet = null;
						$filenamedocProjet = null;
						$extensiondocProjet = null;
						
						
						include('include/tailleMaxi.php');
						$content_blob = null;
						$mime_type = null;
						$fic_taille = 0;
						$content_nom = null;
						if(!empty($_FILES["demFormProjet"]))
						{
							if ($_FILES["demFormProjet"]["error"] > 0)
							{
								echo "Erreur Return Code: " . $_FILES["demFormProjet"]["error"] . "<br />";
							}
							else
							{
							
								if(!empty($_FILES['demFormProjet']['tmp_name']))
									{
						
									echo $_FILES['demFormProjet']['tmp_name'];
								
									$content_temp_nom = $_FILES['demFormProjet']['tmp_name'];
									$nom_fichier_origine = $_FILES['demFormProjet']['name'];
									
									$ret = is_uploaded_file ($_FILES['demFormProjet']['tmp_name']);
									if ( !$ret )
									{
										echo "Problème de transfert";
										return false;
									}
									else
									{
										$nom_fichier_origine = $_FILES['demFormProjet']['name'];
									// Le fichier a bien été reçu
										$fic_taille = $_FILES['demFormProjet']['size'];
										if ( $fic_taille > $taille_max )
										{
											echo "Fichier téléchargé trop important - taille maxi dépassée !";
											return false;
										}
									
										$mime_type = $_FILES['demFormProjet']['type'];
								
									
									
										$fp = fopen ($content_temp_nom, "rb");
									
										$content_blob = fread($fp, $fic_taille);
										fclose ($fp);
										$demProjet = addslashes($content_blob);
									
										$sizedemProjet = $fic_taille;
										$mimedemProjet = $mime_type;
									
										$path_parts = pathinfo($nom_fichier_origine);
									
									// echo $path_parts['dirname'], "\n";
									// echo $path_parts['basename'], "\n";
										$extensiondemProjet = $path_parts['extension'];
										$filenamedemProjet = $path_parts['filename']; // depuis PHP 5.2.0
									
									
									
									
									}
								}
								
							}
						}
						// cdc
						$content_blob = null;
						$mime_type = null;
						$fic_taille = 0;
						$content_nom = null;
						if(!empty($_FILES["cdcFormProjet"]))
						{
							if ($_FILES["cdcFormProjet"]["error"] > 0)
							{
								echo "Erreur Return Code: " . $_FILES["cdcFormProjet"]["error"] . "<br />";
							}
							else
							{
									
								if(!empty($_FILES['cdcFormProjet']['tmp_name']))
								{
						
									echo $_FILES['cdcFormProjet']['tmp_name'];
						
									$content_temp_nom = $_FILES['cdcFormProjet']['tmp_name'];
									$nom_fichier_origine = $_FILES['cdcFormProjet']['name'];
									
									$ret = is_uploaded_file ($_FILES['cdcFormProjet']['tmp_name']);
									if ( !$ret )
									{
										echo "Problème de transfert";
										return false;
									}
									else
									{
										$nom_fichier_origine = $_FILES['cdcFormProjet']['name'];
										// Le fichier a bien été reçu
										$fic_taille = $_FILES['cdcFormProjet']['size'];
										if ( $fic_taille > $taille_max )
										{
											echo "Fichier téléchargé trop important - taille maxi dépassée !";
											return false;
										}
											
										$mime_type = $_FILES['cdcFormProjet']['type'];
						
											
											
										$fp = fopen ($content_temp_nom, "rb");
											
										$content_blob = fread($fp, $fic_taille);
										fclose ($fp);
										$cdcProjet = addslashes($content_blob);
											
										$sizecdcProjet = $fic_taille;
										$mimecdcProjet = $mime_type;
											
										$path_parts = pathinfo($nom_fichier_origine);
											
										// echo $path_parts['dirname'], "\n";
										// echo $path_parts['basename'], "\n";
										$extensioncdcProjet = $path_parts['extension'];
										$filenamecdcProjet = $path_parts['filename']; // depuis PHP 5.2.0
											
											
											
											
									}
								}
						
							}
						}
						// doc
						$content_blob = null;
						$mime_type = null;
						$fic_taille = 0;
						$content_nom = null;
						if(!empty($_FILES["docFormProjet"]))
						{
							if ($_FILES["docFormProjet"]["error"] > 0)
							{
								echo "Erreur Return Code: " . $_FILES["docFormProjet"]["error"] . "<br />";
							}
							else
							{
									
								if(!empty($_FILES['docFormProjet']['tmp_name']))
								{
						
									echo $_FILES['docFormProjet']['tmp_name'];
						
									$content_temp_nom = $_FILES['docFormProjet']['tmp_name'];
									$nom_fichier_origine = $_FILES['docFormProjet']['name'];
									
									$ret = is_uploaded_file ($_FILES['docFormProjet']['tmp_name']);
									if ( !$ret )
									{
										echo "Problème de transfert";
										return false;
									}
									else
									{
										$nom_fichier_origine = $_FILES['docFormProjet']['name'];
										// Le fichier a bien été reçu
										$fic_taille = $_FILES['docFormProjet']['size'];
										if ( $fic_taille > $taille_max )
										{
											echo "Fichier téléchargé trop important - taille maxi dépassée !";
											return false;
										}
											
										$mime_type = $_FILES['docFormProjet']['type'];
						
											
											
										$fp = fopen ($content_temp_nom, "rb");
											
										$content_blob = fread($fp, $fic_taille);
										fclose ($fp);
										$docProjet = addslashes($content_blob);
											
										$sizedocProjet = $fic_taille;
										$mimedocProjet = $mime_type;
										
										$path_parts = pathinfo($nom_fichier_origine);
											
										// echo $path_parts['dirname'], "\n";
										// echo $path_parts['basename'], "\n";
										$extensiondocProjet = $path_parts['extension'];
										$filenamedocProjet = $path_parts['filename']; // depuis PHP 5.2.0
											
											
											
											
									}
								}
						
							}
						}
						
		/* Mise à jour :
		 * 
		 */
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idPROJET) FROM PROJET ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idProjet = $gid->fetchColumn();
					
					
					
					$idProjet ++ ;
					
					
					$sql = 'insert into PROJET values ("'.$idProjet.'",'.
							'"'.$nomProjet.'","'.
							$libelleProjet.'","'.
							$contexteProjet.'",'.
							$indLocal.','.
							$indNational.','.
							$indInterAca.',';
									
									
					if(!empty($_POST["dateDemandeProjet"]))
					{
						
						$sql = $sql.'"'.$dateversRowDemandeProjet .'",';
					}
					else
					{
					$sql = $sql .'null,';
					}
					if(!empty($_POST["dateFinProjet"]))
					{
					$sql = $sql.'"'.$dateversRowFinProjet .'",';
					}
					else
					{
					$sql = $sql .'null,';
					}
					if(!empty($demProjet))
					{
						
						$sql = $sql .'"'.$demProjet.'","'.
								$mimedemProjet.'",'.
								$sizedemProjet.',"'.
								$filenamedemProjet.'","'.
								$extensiondemProjet.'",';
							
						
					}
					else
					{
						$sql = $sql .'null, null, null, null, null'.',';
					}
							
					if(!empty($cdcProjet))
					{
						$sql = $sql .'"'.$cdcProjet.'","'.
									$mimecdcProjet.'",'.
									$sizecdcProjet.',"'.
									$filenamecdcProjet.'","'.
									$extensioncdcProjet.'",';
					}
					else
					{
						$sql = $sql .'null, null, null, null, null'.',';
					}
					if(!empty($docProjet))
					{
						$sql = $sql .'"'.$docProjet.'","'.
									$mimedocProjet.'",'.
									$sizedocProjet.',"'.
									$filenamedocProjet.'","'.
									$extensiondocProjet.'"';
							
					}
					else
					{
						$sql = $sql .'null, null, null, null, null';
					}			
					$sql = $sql .');'   ;
					// echo $sql;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
			?>	