<!DOCTYPE html PUBLIC "-//W3C//Dtd XHTML 1.0 Strict//EN"
	"http://www.w3.org/tr/xhtml1/Dtd/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Projets - consultation
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />


</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Projetlisation</h3>
			<p>Cliquez sur l'onglet <b>Liste et Edition </b> pour une autre consultation, 
			une modification, ou une suppression </p>
			<p> Cliquez sur l'onglet <b> Ajout </b> pour créer une occurence de Base de données</p>
			
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5>Gestion des projets </h5>
			
			<div id="tabsF">
				<?php include('include/MHPR.php'); ?> 
			</div>
				<?php $cons=0;
				include('include/con2PR.php');
				include('include/con5PRAP.php');
				include('include/con4PRAP.php');
				?> 	
			<fieldset class="saisie">	
			
					
			<form name="consProjet" id="consProjetForm" method="post"
				 enctype="multipart/form-data" 
					action="ajAPsPR.php">
				<table border=0>
								<input type="hidden" name="idProjet" 
			 					value="<?php echo htmlspecialchars($idProjet); ?>">
			 					</input>	
					<tr>
						<td> Nom du projet :</td>
						<td>
							<input type="text" name="nomProjet" 
							value="<?php echo htmlspecialchars($nomProjet); ?>"
							 maxlength="20" size="20" readonly></input>
						</td>
					</tr>
						<tr>
						<td> Libelle du projet :</td>
						<td>
							<input type="text" name="libelleProjet" 
							value="<?php echo htmlspecialchars($libelleProjet); ?>"
							 maxlength="100" size="60" readonly></input>
						</td>
					</tr>				
					<tr>
						<td> Contexte du projet :</td>
						<td>
							<textarea readonly name = "contexteProjet" rows="11" cols="50" readonly>
							<?php echo htmlspecialchars($contexteProjet); ?>
							</textarea>
						</td>
					</tr>
				
					<?php 
							$i = 0 ;
						
							while ($i < $index1) 
							{
								$idAppli = $tableau1[$i][0];
								
						?>
					<tr>
						<td></td>
						<td>
							<input type="checkbox" name=
							"<?php echo "idAp[]" ?>" 
							value="
							
							<?php
							
								echo $tableau1[$i][0] ;
							?>
							"
							<?php 
								if ($tableau1[$i][2]== true) 
								{
									echo " checked ";
									
								}
								
								
							?>
									
							> 
							<?php
							
								echo $tableau1[$i][1] ; 
							?>
							</input>
						</td>
					</tr>
					<tr>	
						<?php 
							$i++;
							
							}
							?>
							
						<td>
							<input type="submit" value="Valider" name="soumet">
							</input>
							<input type="submit" value="Annuler" name="annule">
							</input>
						</td>
					</tr>
					
				</table>	
			</form>
			
			
			</fieldset>	
			
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	
</div><!-- #global -->

</body>
</html>

