<?php	
			  
				
					if(!empty($_POST["Appli_idAppli"]))

					{
						$Appli_idAppli=$_POST["Appli_idAppli"];
					} else 
					{ 
						$Appli_idAppli = 0;
					}
									
					
					if(!empty($_POST["Uti_idUti"]))
					{
						$Uti_idUti=$_POST["Uti_idUti"];
					} else 
					{ 
						$Uti_idUti = 0;
					}
					
				
					
					
						
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
					$validBase = true;
					$nbOccur = 0;
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT count(*) FROM APPLI_has_UTI
							where APPLI_idAPPLI = :Appli_idAppli
							and UTI_idUTI = :Uti_idUti";
					
					$gid = $dbh->prepare($sql1);
					$gid->bindValue(':Appli_idAppli', $Appli_idAppli, PDO::PARAM_INT);
					$gid->bindValue(':Uti_idUti', $Uti_idUti, PDO::PARAM_INT);
					$gid->execute();
					$nbOccur  = $gid->fetchColumn();
					
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table APPLI_has_UTI utilise(nt) cette réference APPLI et cette référence UTI <br>";
						?>
						<script language="javascript">
						alert("L'ajout est impossible car il y a au moins une référence identique dans la table des rattachements application et utilisateur");
						</script>
						<?php
					}
					
					
			
					if ($validBase)
					{
					
						$sql = 'insert into APPLI_has_UTI values ('.$Appli_idAppli.','
							.$Uti_idUti.
							
							
							');'   ;
						
						$dbh->exec($sql);
					
      				
						$dbh->commit();
						echo "Validation de l'Ajout faite";
					}
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
				
			}
				
	?>	