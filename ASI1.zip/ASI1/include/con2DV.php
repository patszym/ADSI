<?php 
				/* initialisations : */
			
				
				$validId = true;
				$libelleCourtDivision=null;
				$libelleLongDivision=null;
			
				
				
				if(!empty($_POST["idDivision"]))
				{
					$idDivision = $_POST['idDivision'];
					/// $idDivision = filter_var($idDivision), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idDivision))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idDivision = $_POST['idDivision'];
					
				} else {
					$idDivision = null;
					
				}
				
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  libelleCourtDIVISION,
						libelleLongDIVISION 
					 	
						FROM DIVISION
    					WHERE idDIVISION  = :idDivision LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idDivision, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idDivision' => $idDivision));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								
								if (!empty ($row['libelleCourtDIVISION']))
								{
									$libelleCourtDivision=$row['libelleCourtDIVISION'];
								}
								else 
								{
									$libelleCourtDivision=null;
								}
								if (!empty ($row['libelleLongDIVISION']))
								{
									$libelleLongDivision=$row['libelleLongDIVISION'];
								}
								else
								{
									$libelleLongDivision=null;
								}
								
								
								
							}
						
					
					
				}
				
					
			?> 