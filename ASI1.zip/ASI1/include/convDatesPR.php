<?php
include_once('ConversionDates.class.php');
$dDemandeProjet = null;
$dFinProjet = null;
if (!empty ($dateDemandeProjet))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateDemandeProjet);
	$conversionDates->convDated();
	$dDemandeProjet = $conversionDates->getdt() ;
}
 

if (!empty ($dateFinProjet))
{ 
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateFinProjet);
	$conversionDates->convDated();
	$dFinProjet = $conversionDates->getdt() ;
}


?>