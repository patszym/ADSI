<?php
echo '<div id="navigation">';
echo '<ul>';

if (!(isset($loginAdm)))
{
	$loginAdm = null;
}
if (!(isset($mdpAdm)))
{
	$mdpAdm = 0;
}
if (!(isset($adm))) 
{
	$adm = false;
}
if ($adm == true)
{
	echo '<li><a href="index1.php">Accueil ADMINISTRATEUR</a></li>';
	echo '<li><a href="../ASI2/index2.php">Accueil UTILISATEUR</a></li>';
}
echo '<li><a href="../ASI2/login.php">connection UTILISATEUR</a></li>';
echo '	<li><a href="logout.php">Déconnection</a></li>';
echo '</ul>';
echo '	</div><!-- #navigation    -->';

?> 

		