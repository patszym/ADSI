<?php 
				/* initialisations : */
			
				
				$validId = true;
				$nomAsi=null;
				$prenomAsi=null;
				$telephoneAsi=null;
				$emailAsi=null;
				$idAutreIdentASI=null;
			
				$accesLDAP=null;
				$sdaLDAP=null;
				
				
				if(!empty($_POST["idAsi"]))
				{
					$idAsi = $_POST['idAsi'];
					/// $idAsi = filter_var($idAsi), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idAsi))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idAsi = $_POST['idAsi'];
					
				} else {
					$idAsi = null;
					
				}
				if (($idAsi == null)&&(!empty($_POST['idSelectAsi'])))
				{
					$idAsi = $_POST['idSelectAsi'];
				}
				
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  nomASI,
						prenomASI, 
					 	telephoneASI,
						emailASI,
						idAutreIdentASI,
					 	accesLDAP,
					 		sdaLDAP
						FROM ASI
    					WHERE idASI  = :idAsi LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idAsi, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idAsi' => $idAsi));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								
								if (!empty ($row['nomASI']))
								{
									$nomAsi=$row['nomASI'];
								}
								else 
								{
									$nomAsi=null;
								}
								if (!empty ($row['prenomASI']))
								{
									$prenomAsi=$row['prenomASI'];
								}
								else
								{
									$prenomAsi=null;
								}
								if (!empty ($row['telephoneASI']))
								{
									$telephoneAsi=$row['telephoneASI'];
								}
								else
								{
									$telephoneAsi=null;
								}
								if (!empty ($row['emailASI']))
								{
									$emailAsi=$row['emailASI'];
								}
								else
								{
									$emailAsi=null;
								}
								if (!empty ($row['idAutreIdentASI']))
								{
									$idAutreIdentASI=$row['idAutreIdentASI'];
								}
								else
								{
									$idAutreIdentASI=null;
								}
								if (!empty ($row['accesLDAP']))
								{
									$accesLDAP=$row['accesLDAP'];
								}
								else
								{
									$accesLDAP=null;
								}
								if (!empty ($row['sdaLDAP']))
								{
									$sdaLDAP=$row['sdaLDAP'];
								}
								else
								{
									$sdaLDAP=null;
								}
								
							}
						
					
					
				}
				
					
			?> 