<?php 
				/* initialisations : */
			
				
				$validId = true;
					
				
				$indic_Appli_has_Basdon=null;
				
				
				if(!empty($_POST["Appli_idAppli"]))
				{
					$Appli_idAppli = $_POST['Appli_idAppli'];
					/// $idAppli = filter_var($idAppli), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($Appli_idAppli))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$Appli_idAppli = $_POST['Appli_idAppli'];
					
				} else {
					$Appli_idAppli = null;
					
				}
				if(!empty($_POST["Basdon_idBasdon"]))
				{
					$Basdon_idBasdon = $_POST['Basdon_idBasdon'];
					/// $idAppli = filter_var($idAppli), FILTER_SANITIZE_NUMBER_INT);
						
					if (is_numeric($Basdon_idBasdon))
					{
						$validId = true;
					} else {
						$validId = false;
				
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$Basdon_idBasdon = $_POST['Basdon_idBasdon'];
					
				} else {
					$Basdon_idBasdon = null;
									
				}
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="select APPLI_idAPPLI, BASDON_idBASDON,
							indicAPPLI_has_BASDON
						from APPLI_has_BASDON
							where APPLI_idAPPLI = :Appli_idAppli
							and BASDON_idBASDON = :Basdon_idBasdon
						";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindValue(':Appli_idAppli', $Appli_idAppli, PDO::PARAM_INT);
						$sth->bindValue(':Basdon_idBasdon', $Basdon_idBasdon, PDO::PARAM_INT);
						
						try {
						$sth->execute();
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								
								if (!empty ($row['APPLI_idAPPLI']))
								{
									$idRowAppli=$row['APPLI_idAPPLI'];
									$Appli_idAppli = $idRowAppli;
								}
								else
								{
									$idRowAppli=null;
									$Appli_idAppli = null;
								}
								
								if (!empty ($row['BASDON_idBASDON']))
								{
									$idRowBasdon=$row['BASDON_idBASDON'];
									$Basdon_idBasdon = $idRowBasdon;
								}
								else
								{
									$idRowBasdon=null;
									$Basdon_idBasdon = null;
								}
								
								if (!empty ($row['indicAPPLI_has_BASDON']))
								{
									$indic_Appli_has_Basdon=$row['indicAPPLI_has_BASDON'];
								}
								else 
								{
									$indic_Appli_has_Basdon=null;
								}
							
									
								
								
							}
						
					
					
				}
				
					
			?> 