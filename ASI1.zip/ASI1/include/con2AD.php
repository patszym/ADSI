<?php 
				/* initialisations : */

				include 'encrypt_decrypt.php';
				
				$validId = true;
				
				
				if(!empty($_POST["idAdm"]))
				{
					$idAdm = $_POST['idAdm'];
					/// $idAdm = filter_var($idAdm), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idAdm))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idAdm = $_POST['idAdm'];
					
				} else {
					$idAdm = null;
					
				}
				if (($idAdm == null)&&(!empty($_POST['idSelectAdm'])))
				{
					$idAdm = $_POST['idSelectAdm'];
				}
				
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  
					 	loginADM,
							mdpADM
						FROM ADM
    					WHERE idADM  = :idAdm LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idAdm, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idAdm' => $idAdm));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								
								
								
								if (!empty ($row['loginADM']))
								{
									$loginAdm=$row['loginADM'];
								}
								else
								{
									$loginAdm=null;
								}
								if (!empty ($row['mdpADM']))
								{
									$mdpAdm=$row['mdpADM'];
									$encrypted_txt = $mdpAdm;
									$decrypted_txt = encrypt_decrypt('decrypt', $encrypted_txt);
								
									$mdpDecryptAdm = $decrypted_txt;
									
								}
								else
								{
									$mdpAdm=null;
									$mdpDecryptAdm = null;
								}
								
							}
						
					
					
				}
				
					
			?> 