<?php 
			
				
				include('include/connBase.php');
				// on crée la requête SQL
				
				$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
				$sql = 'SELECT idDIFFUSION, nomDIFFUSION FROM DIFFUSION
				ORDER BY nomDIFFUSION ';
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				$query->execute();
			
				$tableau1 = array();
				$index1 = 0;
				// Parcours des résultats
				
				while ($row = $query->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
				{
					
					$arg0 = $row [0];
					
					$arg1 = $row [1] ;
					
					$arg2=null;
					$tableau1[$index1][2] = null;
					if ($idRowDiffusion == $arg0)
					{
						$arg2 = "selected";
						$nomDiffusion = $arg1;
					}
					$tableau1[$index1] = array($arg0,$arg1,$arg2);
					
					$index1++;
					// $u représente l'utilisateur courant du jeu de résultats
					// La forme prise par $u pour représenter ce résultat est vue ci-dessous
				
				}
				
				
					
			?> 