<ul>
<li><a href="edCY.php" title="Liste et Edition"><span>Liste et Edition</span></a></li>

<li><a href="ajCY.php" title="Ajout"><span>Ajout</span></a></li>

</ul>
