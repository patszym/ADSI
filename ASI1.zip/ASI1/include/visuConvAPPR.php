<?php
try
	{   
		$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
		$query = $dbh->prepare($sql);
		
		$query->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
		$query->execute();
		$maxRow = 0 ;
		$tableau = array();
		while ($row = $query->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
		{
			
			$arg0 = $row [0];
			$arg1 = $row [1];
			
			$arg2 = $row [2] ;
			$arg3 = $row [3] ;
			
			
			$tableau[$maxRow] = array($arg0,$arg1,$arg2, $arg3);
			$maxRow++;
		}
	}
	
	
	
	
	catch (PDOException $e)
	{
		print $e->getMessage();
	}
	
?>