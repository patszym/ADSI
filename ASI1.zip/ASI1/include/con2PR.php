<?php 
include_once('include/ConversionDates.class.php');
				/* initialisations : */
			
				
				$validId = true;
				$nomProjet=null;
				$libelleProjet = null;
				$contexteProjet=null;
				$indLocalProjet=null;
				$indNationalProjet=null;
				$indInterAcaProjet=null;
				$dateDemandeProjet=null;
				$dateFinProjet=null;
				$demProjet=null;
				$mimedemProjet=null;
				$sizedemProjet=null;
				$filenamedemProjet = null;
				$extensiondemProjet = null;
				$cdcProjet=null;
				$mimecdcProjet=null;
				$sizecdcProjet=null;
				$filenamecdcProjet = null;
				$extensioncdcProjet = null;
				$docProjet=null;
				$mimedocProjet=null;
				$sizedocProjet=null;
				$filenamedocProjet = null;
				$extensiondocProjet = null;
				
				if(!empty($_POST["idProjet"]))
				{
					$idProjet = $_POST['idProjet'];
					/// $idProjet = filter_var($idProjet), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idProjet))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idProjet = $_POST['idProjet'];
					
				} else {
					$idProjet = null;
					
				}
				
				// Initialisation de la session :
				session_start();
				$ses_id = session_id();
				
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  nomPROJET,
						libellePROJET, contextePROJET, indLocalPROJET,
						indNationalPROJET, indInterAcaPROJET,
						dateDemandePROJET, dateFinPROJET,
						demPROJET, mimedemPROJET,sizedemPROJET,filenamedemPROJET,extensiondemPROJET, 
						cdcPROJET, mimecdcPROJET,sizecdcPROJET,filenamecdcPROJET,extensioncdcPROJET, 
						docPROJET, mimedocPROJET,sizedocPROJET,filenamedocPROJET,extensiondocPROJET 
					 	
						FROM PROJET
    					WHERE idPROJET  = :idProjet LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idProjet, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idProjet' => $idProjet));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								
								if (!empty ($row['nomPROJET']))
								{
									$nomProjet=$row['nomPROJET'];
								}
								else 
								{
									$nomProjet=null;
								}
								if (!empty ($row['libellePROJET']))
								{
									$libelleProjet=$row['libellePROJET'];
								}
								else
								{
									$libelleProjet=null;
								}
								
								if (!empty ($row['contextePROJET']))
								{
									$contexteProjet=$row['contextePROJET'];
								}
								else
								{
									$contexteProjet=null;
								}
								if (!empty ($row['indLocalPROJET']))
								{
									$indLocalProjet=$row['indLocalPROJET'];
								}
								else
								{
									$indLocalProjet=null;
								}
								if (!empty ($row['indLocalPROJET']))
								{
									$indLocalProjet=$row['indLocalPROJET'];
								}
								else
								{
									$indLocalProjet=null;
								}
								if (!empty ($row['indNationalPROJET']))
								{
									$indNationalProjet=$row['indNationalPROJET'];
								}
								else
								{
									$indNationalProjet=null;
								}
								if (!empty ($row['indInterAcaPROJET']))
								{
									$indInterAcaProjet=$row['indInterAcaPROJET'];
								}
								else
								{
									$indInterAcaProjet=null;
								}
								if (!empty ($row['dateDemandePROJET']))
								{
								
									$dateDemandeProjet=$row['dateDemandePROJET'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateDemandeProjet);
									$conversionDates->convDated();
									$dDemandeProjet = $conversionDates->getdt() ;
								
								}
								else
								{
									$dDemandeProjet=null;
								}
								
								if (!empty ($row['dateFinPROJET']))
								{
								
									$dateFinProjet=$row['dateFinPROJET'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateFinProjet);
									$conversionDates->convDated();
									$dFinProjet = $conversionDates->getdt() ;
								
								}
								else
								{
									$dFinProjet=null;
								}
								
								
											
								// Traitement de dem
								
								if (!empty ($row['demPROJET']))
								{
									$demProjet=$row['demPROJET'];
								}
								else
								{
									$demProjet=null;
								}
								if (!empty ($row['mimedemPROJET']))
								{
									$mimedemProjet=$row['mimedemPROJET'];
										
								}
								else
								{
									$mimedemProjet=null;
									
										
								}
								
								if (!empty ($row['sizedemPROJET']))
								{
									$sizedemProjet=$row['sizedemPROJET'];
								}
								else
								{
									$sizedemProjet=null;
								}
								if (!empty ($row['filenamedemPROJET']))
								{
									$filenamedemProjet=$row['filenamedemPROJET'];
								}
								else
								{
								$filenamedemProjet=null;
								}
								if (!empty ($row['extensiondemPROJET']))
								{
									$extensiondemProjet=$row['extensiondemPROJET'];
								}
								else
								{
									$extensiondemProjet=null;
								}
								
								
								if ($cons == 1)
								{
											
									
								
									$ficdemnom = "blobExtract/".$ses_id.$filenamedemProjet.".".$extensiondemProjet;
								
									$fp = fopen($ficdemnom, 'w');
									
									if (fwrite($fp,$demProjet)) {
										echo "Le fichier de la demande à été créé avec succès.";
									} else {
										// Erreur
										echo "Impossible de créer le fichier de la demande.";
									}
									fclose($fp);
								}
									
									
									// traitement de cdc :
								if (!empty ($row['cdcPROJET']))
								{
									$cdcProjet=$row['cdcPROJET'];
								}
								else
								{
									$cdcProjet=null;
								}
								if (!empty ($row['mimecdcPROJET']))
								{
									$mimecdcProjet=$row['mimecdcPROJET'];
											
								}
								else
								{
									$mimecdcProjet=null;
											
									
								}
									
								if (!empty ($row['sizecdcPROJET']))
								{
									$sizecdcProjet=$row['sizecdcPROJET'];
								}
								else
								{
									$sizecdcProjet=null;
								}
								if (!empty ($row['filenamecdcPROJET']))
								{
									$filenamecdcProjet=$row['filenamecdcPROJET'];
								}
								else
								{
									$filenamecdcProjet=null;
								}
								if (!empty ($row['extensioncdcPROJET']))
								{
									$extensioncdcProjet=$row['extensioncdcPROJET'];
								}
								else
								{
									$extensioncdcProjet=null;
								}
									
									
									
								
									
								if ($cons == 1)
								{
												
									
									$ficcdcnom = "blobExtract/".$ses_id.$filenamecdcProjet.".".$extensioncdcProjet;
									
									$fp = fopen($ficcdcnom, 'w');
										
									if (fwrite($fp,$cdcProjet)) {
										echo "Le fichier du cahier de charge à été créé avec succès.";
									} else {
										// Erreur
										echo "Impossible de créer le fichier du cahier de charge.";
									}
									fclose($fp);
								}
									
									
								// traitement de doc :
								if (!empty ($row['docPROJET']))
								{
									$docProjet=$row['docPROJET'];
								}
								else
								{
									$docProjet=null;
								}
								if (!empty ($row['mimedocPROJET']))
								{
									$mimedocProjet=$row['mimedocPROJET'];
											
								}
								else
								{
									$mimedocProjet=null;
								}
									
								if (!empty ($row['sizedocPROJET']))
								{
									$sizedocProjet=$row['sizedocPROJET'];
								}
								else
								{
									$sizedocProjet=null;
								}
								if (!empty ($row['filenamedocPROJET']))
								{
									$filenamedocProjet=$row['filenamedocPROJET'];
								}
								else
								{
									$filenamedocProjet=null;
								}
								if (!empty ($row['extensiondocPROJET']))
								{
									$extensiondocProjet=$row['extensiondocPROJET'];
								}
								else
								{
									$extensiondocProjet=null;
								}
									
									
									
									
								if ($cons == 1)
								{
											
									
									$ficdocnom = "blobExtract/".$ses_id.$filenamedocProjet.".".$extensiondocProjet;
									
									$fp = fopen($ficdocnom, 'w');
										
									if (fwrite($fp,$docProjet)) {
										echo "Le fichier de la documentation du projet à été créé avec succès.";
									} else {
										// Erreur
										echo "Impossible de créer le fichier de la documentation.";
									}
									fclose($fp);
								echo " --> Confection en fichiers des binaires faite ...";
								echo " Les fichiers se trouvent dans le repertoire du serveur /blobExtract";
								
								}
													
								
							}
						
					
					
				}
				
					
			?> 