<?php 
				/* initialisations : */
			
				
				$validId = true;
				$nomDiffusion=null;
				$libelleDiffusion=null;
				$adresseDiffusion=null;
				$codPostDiffusion=null;
				$communeDiffusion=null;
			
				$nomEtabDiffusion=null;
				
				
				if(!empty($_POST["idDiffusion"]))
				{
					$idDiffusion = $_POST['idDiffusion'];
					/// $idDiffusion = filter_var($idDiffusion), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idDiffusion))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idDiffusion = $_POST['idDiffusion'];
					
				} else {
					$idDiffusion = null;
					
				}
				if (($idDiffusion == null)&&(!empty($_POST['idSelectDiffusion'])))
				{
					$idDiffusion = $_POST['idSelectDiffusion'];
				}
				
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  nomDIFFUSION,
						libelleDIFFUSION, 
					 	adresseDIFFUSION,
						codPostDIFFUSION,
						communeDIFFUSION,
					 	nomEtabDIFFUSION
						FROM DIFFUSION
    					WHERE idDIFFUSION  = :idDiffusion LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idDiffusion, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idDiffusion' => $idDiffusion));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								
								if (!empty ($row['nomDIFFUSION']))
								{
									$nomDiffusion=$row['nomDIFFUSION'];
								}
								else 
								{
									$nomDiffusion=null;
								}
								if (!empty ($row['libelleDIFFUSION']))
								{
									$libelleDiffusion=$row['libelleDIFFUSION'];
								}
								else
								{
									$libelleDiffusion=null;
								}
								if (!empty ($row['adresseDIFFUSION']))
								{
									$adresseDiffusion=$row['adresseDIFFUSION'];
								}
								else
								{
									$adresseDiffusion=null;
								}
								if (!empty ($row['codPostDIFFUSION']))
								{
									$codPostDiffusion=$row['codPostDIFFUSION'];
								}
								else
								{
									$codPostDiffusion=null;
								}
								if (!empty ($row['communeDIFFUSION']))
								{
									$communeDiffusion=$row['communeDIFFUSION'];
								}
								else
								{
									$communeDiffusion=null;
								}
								if (!empty ($row['nomEtabDIFFUSION']))
								{
									$nomEtabDiffusion=$row['nomEtabDIFFUSION'];
								}
								else
								{
									$nomEtabDiffusion=null;
								}
								
								
							}
						
					
					
				}
				
					
			?> 