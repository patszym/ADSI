
<ul>
<li><a href="edAD.php" title="Liste et Edition"><span>Liste et Edition</span></a></li>

<li><a href="ajAD.php" title="Ajout"><span>Ajout</span></a></li>

</ul>
