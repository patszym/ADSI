<?php 
				/* initialisations : */
			
				
				$validId = true;
				$libelleCourtCycle=null;
				$libelleLongCycle=null;
			
				
				
				if(!empty($_POST["idCycle"]))
				{
					$idCycle = $_POST['idCycle'];
					/// $idCycle = filter_var($idCycle), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idCycle))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idCycle = $_POST['idCycle'];
					
				} else {
					$idCycle = null;
					
				}
				
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  libelleCourtCYCLE,
						libelleLongCYCLE 
					 	
						FROM CYCLE
    					WHERE idCYCLE  = :idCycle LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idCycle, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idCycle' => $idCycle));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								
								if (!empty ($row['libelleCourtCYCLE']))
								{
									$libelleCourtCycle=$row['libelleCourtCYCLE'];
								}
								else 
								{
									$libelleCourtCycle=null;
								}
								if (!empty ($row['libelleLongCYCLE']))
								{
									$libelleLongCycle=$row['libelleLongCYCLE'];
								}
								else
								{
									$libelleLongCycle=null;
								}
								
								
								
							}
						
					
					
				}
				
					
			?> 