<?php 
	include('include/connBase.php');
	if (!empty( $_POST['soumet'] ))
	{				
					if(!empty($_POST["idProjet"]))
					{
						$Projet_idProjet=$_POST["idProjet"];
					} else
					{
						$Projet_idProjet = 0;
					}
	try {
		$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$dbh->beginTransaction();
		$sql = 'DELETE FROM APPLI_has_PROJET
								WHERE PROJET_idPROJET = :Projet_idProjet ';
						$sth = $dbh->prepare($sql);
							
						$sth->bindValue(':Projet_idProjet', $Projet_idProjet, PDO::PARAM_INT);
						$sth->execute();
					
					
			
				if (isset($_POST['idAp']))
				
				{
					
					foreach($_POST['idAp'] as $idAp)
					{
						
						$Appli_idAppli = $idAp;
						$sql = 'insert into APPLI_has_PROJET values ('.$Appli_idAppli.','
								.$Projet_idProjet.');'   ;
									
								$dbh->exec($sql);
					}
					
					
				
				}
				$dbh->commit();
				echo "la mise à jour a été faite";
		} catch (Exception $e) {
					$dbh->rollBack();
					echo "la mise à jour a échouée: " . $e->getMessage();
		}
			
	}

?>
				
			