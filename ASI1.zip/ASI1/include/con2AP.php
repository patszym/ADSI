<?php 
include_once('include/ConversionDates.class.php');
include 'encrypt_decrypt.php';
				/* initialisations : */
			
				
				$validId = true;
				$idRowDivision = null;
				$idRowDiffusion = null;
				
				$nomAppli=null;
				$libelleAppli=null;
				$urlPresAppli=null;
				$typeAppli = null;
				$idRowAcaAppli = null;
				$prestataireAppli=null;
				$dateDiffusAppli=null;
				$dateDebutAppli = null;
				$dateFinAppli = null;
				$datePriseEnChargeAppli = null;
				$dateInstallationAppli = null;
				$dateMiseADispoAppli = null;
				$domFoncAppli = null;
				$loginAppli = null;
				$mdpAppli = null;
				
				if(!empty($_POST["idAppli"]))
				{
					$idAppli = $_POST['idAppli'];
					/// $idAppli = filter_var($idAppli), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idAppli))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idAppli = $_POST['idAppli'];
					
				} else {
					$idAppli = null;
					
				}
				if (($idAppli == null)&&(!empty($_POST['idSelectAppli'])))
				{
					$idAppli = $_POST['idSelectAppli'];
				}
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT DIVISION_idDIVISION, 
							DIFFUSION_idDIFFUSION,
						nomAPPLI,
						libelleAPPLI, 
					 	urlPresAPPLI,
						typeAPPLI,
					 	idRowAcaAPPLI,
						prestataireAPPLI,
							dateDiffusAPPLI,
							dateDebutAPPLI,
							dateFinAPPLI,
							datePriseEnChargeAPPLI,
							dateInstallationAPPLI,
							dateMiseADispoAPPLI,
						domFoncAPPLI,
							loginAPPLI,
							mdpAPPLI
							
						FROM APPLI
    					WHERE idAPPLI  = :idAppli 
							LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idAppli, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idAppli' => $idAppli));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								if (!empty ($row['DIVISION_idDIVISION']))
								{
									$idRowDivision=$row['DIVISION_idDIVISION'];
								}
								else
								{
									$idRowDivision=null;
								}
								if (!empty ($row['DIFFUSION_idDIFFUSION']))
								{
									$idRowDiffusion=$row['DIFFUSION_idDIFFUSION'];
								}
								else
								{
									$idRowDiffusion=null;
								}
								
													
								if (!empty ($row['nomAPPLI']))
								{
									$nomAppli=$row['nomAPPLI'];
								}
								else 
								{
									$nomAppli=null;
								}
								if (!empty ($row['libelleAPPLI']))
								{
									$libelleAppli=$row['libelleAPPLI'];
								}
								else
								{
									$libelleAppli=null;
								}
								if (!empty ($row['urlPresAPPLI']))
								{
									$urlPresAppli=$row['urlPresAPPLI'];
								}
								else
								{
									$urlPresAppli=null;
								}
								if (!empty ($row['typeAPPLI']))
								{
									$typeAppli=$row['typeAPPLI'];
								}
								else
								{
									$typeAppli=null;
								}
								
								if (!empty ($row['idRowAcaAPPLI']))
								{
									$idRowAcaAppli=$row['idRowAcaAPPLI'];
								}
								else
								{
									$idRowAcaAppli=null;
								}
							
								if (!empty ($row['prestataireAPPLI']))
								{
									$prestataireAppli=$row['prestataireAPPLI'];
								}
								else
								{
									$prestataireAppli=null;
								}
								if (!empty ($row['dateDiffusAPPLI']))
								{
								
									$dateDiffusAppli=$row['dateDiffusAPPLI'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateDiffusAppli);
									$conversionDates->convDated();
									$dDiffusAppli = $conversionDates->getdt() ;
								
								}
								else
								{
									$dDiffusAppli=null;
								}
								if (!empty ($row['dateDebutAPPLI']))
								{
								
									$dateDebutAppli=$row['dateDebutAPPLI'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateDebutAppli);
									$conversionDates->convDated();
									$dDebutAppli = $conversionDates->getdt() ;
								
								}
								else
								{
									$dDebutAppli=null;
								}
								if (!empty ($row['dateFinAPPLI']))
								{
								
									$dateFinAppli=$row['dateFinAPPLI'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateFinAppli);
									$conversionDates->convDated();
									$dFinAppli = $conversionDates->getdt() ;
								
								}
								else
								{
									$dFinAppli=null;
								}
								if (!empty ($row['datePriseEnChargeAPPLI']))
								{
								
									$datePriseEnChargeAppli=$row['datePriseEnChargeAPPLI'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($datePriseEnChargeAppli);
									$conversionDates->convDated();
									$dPriseEnChargeAppli = $conversionDates->getdt() ;
								
								}
								else
								{
									$dPriseEnChargeAppli=null;
								}
								
								if (!empty ($row['dateInstallationAPPLI']))
								{
								
									$dateInstallationAppli=$row['dateInstallationAPPLI'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateInstallationAppli);
									$conversionDates->convDated();
									$dInstallationAppli = $conversionDates->getdt() ;
								
								}
								else
								{
									$dInstallationAppli=null;
								}
								
								if (!empty ($row['dateMiseADispoAPPLI']))
								{
									
								
									$dateMiseADispoAppli=$row['dateMiseADispoAPPLI'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateMiseADispoAppli);
									$conversionDates->convDated();
									$dMiseADispoAppli = $conversionDates->getdt() ;
									
								
								}
								else
								{
									$dMiseADispoAppli=null;
								}
								if (!empty ($row['domFoncAPPLI']))
								{
									$domFoncAppli=$row['domFoncAPPLI'];
								}
								else
								{
									$domFoncAppli=null;
								}
								if (!empty ($row['loginAPPLI']))
								{
									$loginAppli=$row['loginAPPLI'];
								}
								else
								{
									$loginAppli=null;
								}
								if (!empty ($row['mdpAPPLI']))
								{
									$mdpAppli=$row['mdpAPPLI'];
									$encrypted_txt = $mdpAppli;
									$decrypted_txt = encrypt_decrypt('decrypt', $encrypted_txt);
								
									$mdpDecryptAppli = $decrypted_txt;
										
								}
								else
								{
									$mdpAppli=null;
									$mdpDecryptAppli = null;
								}
								
								
								
							}
						
					
					
				}
				
					
			?> 