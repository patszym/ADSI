<?php 
				/* initialisations : */

			include 'encrypt_decrypt.php';
			$idAdm = null;	
			$adm = false;
				
				
				if(!empty($_POST["loginAdm"]))
				{
					$loginAdm = $_POST['loginAdm'];
					
				}
				
				if(!empty($_POST["mdpAdm"]))
				{
					$mdpAdm=$_POST["mdpAdm"];
						
				
				
					$plain_txt = $mdpAdm;
				
					$encrypted_txt = encrypt_decrypt('encrypt', $plain_txt);
						
					$mdpChiffreAdm = $encrypted_txt;
					
				
				} else
				{
					$mdpChiffreAdm = null;
				}
				
				
				
			
					include('include/connBase.php');
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql="SELECT  idADM, 
								
								loginADM,
								mdpADM
								
								
							FROM ADM ";
				if ((!empty($_POST['loginAdm'])) and (!empty($_POST['mdpAdm'])))  
					{
    				$sql = $sql . " WHERE "."loginADM = :loginAdm";
					$sql = $sql ." AND mdpADM = :mdpChiffreAdm";
					$sql = $sql." LIMIT 1";
					$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
					$sth->bindValue(':loginAdm', $loginAdm, PDO::PARAM_INT);
					$sth->bindValue(':mdpChiffreAdm', $mdpChiffreAdm, PDO::PARAM_INT);
					
					
				
					 //  echo $sql;
					try {
						$sth->execute();
							
					} catch (PDOException $e) {
						echo 'la recherche du login a échouée : ' . $e->getMessage();
							
					}
					
							while ($row = $sth->fetch())
							
							{ 
								
							if (!empty ($row['idADM']))
								{
									$idAdm=$row['idADM'];
									$adm = true;
								
									
								}
								else
								{
									$idAdm=null;
								}
								
								if (!empty ($row['loginADM']))
								{
									$loginAdm=$row['loginADM'];
								
								}
								else
								{
									$loginAdm=null;
								}
								if (!empty ($row['mdpADM']))
								{
									$mdpAdm=$row['mdpADM'];
								
								}
								else
								{
									$mdpAdm=null;
								}
								
								
								
							}
							
							
					}
						
					
					
				
				
			?> 