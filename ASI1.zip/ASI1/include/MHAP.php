
<ul>
<li><a href="edAP.php" title="Liste et Edition"><span>Liste et Edition</span></a></li>

<li><a href="ajAP.php" title="Ajout"><span>Ajout</span></a></li>

<li><a href="ajAPUT.php" title="Ajout UTI"><span>Ajout UTI</span></a></li>


<li><a href="ajAPBD.php" title="Ajout BD"><span>Ajout BD</span></a></li>

<li><a href="ajAPASI.php" title="Ajout ASI"><span>Ajout ASI</span></a></li>

<li><a href="ajAPPR.php" title="Ajout Projet"><span>Ajout Projet</span></a></li>

<li><a href="ajAPCO.php" title="Ajout Contact"><span>Ajout Contact</span></a></li>

</ul>
