<?php 
	include('include/connBase.php');
	if (!empty( $_POST['soumet'] ))
	{				
					if(!empty($_POST["idUti"]))
					{
						$Uti_idUti=$_POST["idUti"];
					} else
					{
						$Uti_idUti = 0;
					}
						
	try {
			$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$dbh->beginTransaction();
			$sql = 'DELETE FROM APPLI_has_UTI
								WHERE UTI_idUTI = :Uti_idUti ';
						$sth = $dbh->prepare($sql);
							
						$sth->bindValue(':Uti_idUti', $Uti_idUti, PDO::PARAM_INT);
						$sth->execute();
					
			
				if (isset($_POST['idAp']))
				
				{
					
					foreach($_POST['idAp'] as $idAp)
					{
						
						$Appli_idAppli = $idAp;
						$sql = 'insert into APPLI_has_UTI values ('.$Appli_idAppli.','
								.$Uti_idUti.');'   ;
									
								$dbh->exec($sql);
					}
					
				
				}
				$dbh->commit();
				echo "la mise à jour a été faite";
					
			} catch (Exception $e) {
					$dbh->rollBack();
					echo "la mise à jour a échouée: " . $e->getMessage();
			}
			
			
	}

?>
				
			