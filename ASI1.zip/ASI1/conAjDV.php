<?php	
			  
				
					$idDivision = null;
					
					
					if(!empty($_POST["libelleCourtDivision"]))
					{
						$libelleCourtDivision=$_POST["libelleCourtDivision"];
					} else 
					{ 
						$libelleCourtDivision = null;
					}
					
					if(!empty($_POST["libelleLongDivision"]))						
					{
						$libelleLongDivision=$_POST["libelleLongDivision"];
					} else
					{
						$libelleLongDivision = null;
					}
					
					
					
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idDIVISION) FROM DIVISION ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idDivision = $gid->fetchColumn();
					
					
					
					$idDivision ++ ;
					
					
					$sql = 'insert into DIVISION values ("'.$idDivision.'",'.
							'"'.$libelleCourtDivision.'","'.$libelleLongDivision.'"'.
							
							');'   ;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
			?>	