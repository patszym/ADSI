<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">


<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>
		Applis
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
</meta>
<head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> A l'appel du menu général, le mode <b> Liste et Edition</b> est le mode par défaut</p>
			<p> Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence Appli</p>
			<p> Cliquez sur l'onglet  <b>Ajout UTI </b> pour ajouter un rattachement application - utilisateur</p>
			<p> Cliquez sur l'onglet  <b>Ajout BD </b> pour ajouter un rattachement application - base de données</p>
			<p> Cliquez sur l'onglet  <b>Ajout ASI </b> pour ajouter un rattachement application - ASI</p>
			<p> Cliquez sur l'onglet  <b>Ajout PR </b> pour ajouter un rattachement application - projet</p>
			
			<p> Cliquez sur l'image de l'oeil pour voir le détail de la ligne spécifiée en consultation dans la liste</p>
			<p> Cliquez sur l'image du crayon pour voir le détail de la ligne spécifiée en modification dans la liste</p>
			<p> Cliquez sur l'image de la croix pour voir le détail de la ligne spécifiée en suppression dans la liste</p>
			<p>Cliquez sur l'icône <b>PDF</b> pour voir le détail de la ligne en obtenant son édition PDF </p>
			<p>Cliquez sur l'image des utilisateurs pour voir le détail de la ligne en obtenant la liste des utilisateurs rattachées </p>
			<p>Cliquez sur l'image des disques pour voir le détail de la ligne en obtenant la liste des bases de données rattachées </p>

			<p>Cliquez sur l'image du process pour voir le détail de la ligne en obtenant la liste des projets rattachés </p>
			<p>Cliquez sur l'image du téléphone pour voir le détail de la ligne en obtenant la liste des contacts rattachés</p>
			<p>Cliquez sur l'icône <b>PDF</b> à gauche du titre pour obtenir l'édition PDF de la liste</p>
			
	</div><!-- #secondaire -->
		
	<div id="principal"> 
			<h5>Gestion des applications </h5>
			
			<br>
			<div id="tabsF">
				<?php include('include/MHAP.php'); ?> 
									
			</div>
	
		<fieldset class="saisie">
			<table BORDER=0>
			
			<tr>
			
				<td>
				<a href="editions/edAPPDF.php">
				<img src="images/pdficon.jpg" height="20" width="20" align = "center" 
				alt="PDF">
				</a>
				</td>
				<td>
				<h3>  LISTE DES APPLICATIONS </h3>
				</td>
			</tr>
				
				<?php 
				include_once "include/connBase.php" ; 
	
				$sql = 'select idAPPLI, libelleCourtDIVISION, nomDIFFUSION, nomAPPLI, 
					libelleAPPLI,
					urlPresAPPLI,
					typeAPPLI,
					idRowAcaAPPLI,
					prestataireAPPLI,
					dateDiffusAPPLI,
					dateDebutAPPLI,
					dateFinAPPLI,
					datePriseEnChargeAPPLI,
					dateInstallationAPPLI,
					dateMiseADispoAPPLI,
					domFoncAPPLI,
					loginAPPLI,
					mdpAPPLI
			
					from APPLI, DIVISION, DIFFUSION
					where DIVISION_idDIVISION = idDIVISION and
							DIFFUSION_idDIFFUSION = idDIFFUSION
					order by nomAPPLI';
	
			
				include_once "include/visuConVAP.php";
				
				$i = 0 ;
				$idAppli = null ;
				$libelleCourtDivision = null;
				$nomDiffusion = null;
				$nomAppli =  null;
				$libelleAppli =  null;
				$urlPresAppli = null;
				$typeAppli = null;
				$idRowAcaAppli = null;
				$prestataireAppli = null;
				$dateDiffusAppli = null;
				$dateDebutAppli = null;
				$dateFinAppli = null;
				$datePriseEnChargeAppli = null;
				$dateInstallationAppli = null;
				$dateMiseADispoAppli = null;
				$domFoncAppli = null;
				$loginAppli = null;
				$mdpAppli = null;
				
				
				while ($i<$maxRow)
				{
					$idAppli =  $tableau [$i][0];
					$libelleCourtDivision = $tableau [$i][1];
					$nomDiffusion = $tableau [$i][2];
					$nomAppli =  $tableau [$i][3];
					$libelleAppli =  $tableau [$i][4];
					$urlPresAppli = $tableau [$i][5];
					$typeAppli = $tableau [$i][6];
					$idRowAcaAppli = $tableau [$i][7];
					$prestataireAppli = $tableau [$i][8];
					$dateDiffusAppli = $tableau [$i][9];
					$dateDebutAppli = $tableau [$i][10];
					$dateFinAppli = $tableau [$i][11];
					$datePriseEnChargeAppli = $tableau [$i][12];
					$dateInstallationAppli = $tableau [$i][13];
					$dateMiseADispoAppli = $tableau [$i][14];
					$domFoncAppli =$tableau [$i][15];
					$loginAppli = $tableau [$i][16];
					$mdpAppli = $tableau [$i][17];
					
					
					$i++;
					/* Exploitation des lignes dans la liste */
					?>
									
					<?php 
					
						include "include/convDatesAP.php" ;
					
					
						$libTypeAppli = null;
						if ($typeAppli == 1) $libTypeAppli = "National";
						if ($typeAppli == 2) $libTypeAppli = "Local";
						if ($typeAppli == 3) $libTypeAppli = "Autre Académie";
						if ($typeAppli == 4) $libTypeAppli = "Prestataire extérieur";
						
						include('include/con1APACA.php'); 
					
					?> 	
				<!-- Liste des  Applis - formulaire en lecture -->
													
					<tr>
									
									
					
							<input type="hidden" name="idAppli"
							value="<?php echo htmlspecialchars($idAppli); ?>"
							></input>
									
														
						<td>
							<input type=text name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
													
													
														
						<td>
							<input type=text name="libelleAppli" 
							value="<?php echo htmlspecialchars($libelleAppli); ?>" 
							maxlength="80" size="32" readonly></input>
						</td>
						
						<td>
							<form action="consAP.php" method="post">

			 					<input type="hidden" name="idAppli" 
			 					value="<?php echo htmlspecialchars($idAppli); ?>">
			 					</input>
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form> 
						</td>
						<td>
							<form action="modifAP.php" method="post">

			 					<input type="hidden" name="idAppli" 
			 					value="<?php echo htmlspecialchars($idAppli); ?>">
			 					</input>
								<input border=0 src="images/crayon.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form>
						</td>
							<td> 
							<form action="supprAP.php" method="post">

			 					<input type="hidden" name="idAppli" 
			 					value="<?php echo htmlspecialchars($idAppli); ?>">
			 					</input>
								<input border=0 src="images/button-cancel.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form>
						</td>
						
						<td> 					
							
							<form action="editions/edElAPPDF.php" method="post">

			 					<input type="hidden" name="idAppli" 
								value="<?php echo htmlspecialchars($idAppli); ?>">
			 					</input>
			 					<input type="hidden" name="libelleCourtDivision" 
								value="<?php echo htmlspecialchars($libelleCourtDivision); ?>">
			 					</input>
			 					<input type="hidden" name="nomDiffusion" 
								value="<?php echo htmlspecialchars($nomDiffusion); ?>">
			 					</input>
								<input type="hidden" name="nomAppli" 
								value="<?php echo htmlspecialchars($nomAppli); ?>">
			 					</input>
			 					
			 					<input type="hidden" name="libelleAppli" 
								value="<?php echo htmlspecialchars($libelleAppli); ?>">
								</input>
								
								<input type="hidden" name="urlPresAppli" 
								value="<?php echo htmlspecialchars($urlPresAppli); ?>">
								</input>
								
								<input type="hidden" name="libTypeAppli" 
								value="<?php echo htmlspecialchars($libTypeAppli); ?>">
								</input>
								
								<input type="hidden" name="nomAca" 
								value="<?php echo htmlspecialchars($nomAca); ?>">
								</input>
								
								<input type="hidden" name="prestataireAppli" 
								value="<?php echo htmlspecialchars($prestataireAppli); ?>">
								</input>
								
								<input type="hidden" name="dDiffusAppli" 
								value="<?php echo htmlspecialchars($dDiffusAppli); ?>">
								</input>
								
								<input type="hidden" name="dDebutAppli" 
								value="<?php echo htmlspecialchars($dDebutAppli); ?>">
								</input>
								
								<input type="hidden" name="dFinAppli" 
								value="<?php echo htmlspecialchars($dFinAppli); ?>">
								</input>
								
								<input type="hidden" name="dPriseEnChargeAppli" 
								value="<?php echo htmlspecialchars($dPriseEnChargeAppli); ?>">
								</input>
								
								<input type="hidden" name="dInstallationAppli" 
								value="<?php echo htmlspecialchars($dInstallationAppli); ?>">
								</input>
								
								<input type="hidden" name="dMiseADispoAppli" 
								value="<?php echo htmlspecialchars($dMiseADispoAppli); ?>">
								</input>
								
								<input type="hidden" name="domFoncAppli" 
								value="<?php echo htmlspecialchars($domFoncAppli); ?>">
								</input>
								
								<input type="hidden" name="loginAppli" 
								value="<?php echo htmlspecialchars($loginAppli); ?>">
								</input>
								
									
								
			 					<input border=0 src="images/pdficon.jpg" 
								type=image value=submit name = "soumet" align="left" 
								height="20" width="20">
								</input>
										
							</form>
						</td>
						<td> 
								<form action="edAPUT.php" method="post">

			 					<input type="hidden" name="idAppli" 
			 					value="<?php echo htmlspecialchars($idAppli); ?>">
			 					</input>
			 					
			 							 				
								<input border=0 src="images/util.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
								</form>
						</td> 
						<td> 
								<form action="edAPBD.php" method="post">

			 					<input type="hidden" name="idAppli" 
			 					value="<?php echo htmlspecialchars($idAppli); ?>">
			 					</input>
			 					
			 							 				
								<input border=0 src="images/database.jpg" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
								</form>
						</td> 
						
						<td> 
								<form action="edAPPR.php" method="post">

			 					<input type="hidden" name="idAppli" 
			 					value="<?php echo htmlspecialchars($idAppli); ?>">
			 					</input>
			 					
			 							 				
								<input border=0 src="images/project.jpg" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
								</form>
						</td> 
						<td> 
								<form action="edAPCO.php" method="post">

			 					<input type="hidden" name="idAppli" 
			 					value="<?php echo htmlspecialchars($idAppli); ?>">
			 					</input>
			 					
			 							 				
								<input border=0 src="images/contact.jpg" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
								</form>
						</td> 									
					</tr>			
										
							
				<?php 
				}
				$query = null;
				?>
			</table>
		</fieldset>

		</div> <!-- principal-->
	
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
