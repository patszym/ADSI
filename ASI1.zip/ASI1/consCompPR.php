<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		projets
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p>Cliquez sur l'onglet <b>Liste et Edition </b> pour une autre consultation, 
			une modification, ou une suppression </p>
			<p> Cliquez sur l'onglet <b> Ajout </b> pour créer une occurence de Projet</p>
			
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5>Consultation complète d'un projet </h5>
			
			
						
			<fieldset class="saisie">
			
			
				<table width="100%" border ="1" cellspacing="1" 
					cellpadding="1"><tr><td>
						<div align=center>
					Présentation des applications
						</div>
					</td><tr></table>
				<table border=0>
				<?php 
				
				include('include/con3PRAP.php'); 
				$i = 0 ;
				
				$nomAppli =  null;
				$libelleAppli = null;
				$idAppli = null;
				
				while ($i<$maxRow0)
				{
					$nomAppli =  $tableauPR0 [$i][0] ;
					$libelleAppli =  $tableauPR0 [$i][1] ;
					$idAppli =  $tableauPR0 [$i][2] ;
					
					
					
					$i++;
					/* Exploitation des lignes dans la liste */
				?>
					
					<tr>
				
						
						<form name="consComp0Projet" id="consComp0ProjetForm" method="post"
				 			enctype="multipart/form-data" 
							action="">
						<td>
							<input type=text name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="16" readonly></input>
						</td>
									
						<td>
							<input type=text name="libelleAppli" 
							value="<?php echo htmlspecialchars($libelleAppli); ?>" 
							maxlength="100" size="60" readonly></input>
						</td>
						
							</form>
						<td>
							<form action="consAP.php" method="post">

			 					<input type="hidden" name="idAppli" 
			 					value="<?php echo htmlspecialchars($idAppli); ?>">
			 					</input>
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form> 
						</td>
					</tr>
					
					<?php 
				}
				$query = null;
				?>	
				</table>	
			
			
			</fieldset>	
			<fieldset class="saisie">
			
			
				<table width="100%" border ="1" cellspacing="1" 
					cellpadding="1"><tr><td>
						<div align=center>
					Présentation des applications,<br></br>
					des divisions et des responsables de la<br></br>
					maîtrise d'ouvrage (MOA)
						</div>
					</td><tr></table>
				<table border=0>
				<?php 
				
				include('include/con3PRMOA.php'); 
				$i = 0 ;
				
				$nomAppli =  null;
				$libelleCourtDivision =  null ;
				$nomMoa = null;
				$prenomMoa =  null;
				$idMoa = null;
				
				while ($i<$maxRow1)
				{
					$nomAppli =  $tableauPR1 [$i][0] ;
					$libelleCourtDivision =  $tableauPR1 [$i][1] ;
					$nomMoa =  $tableauPR1 [$i][2] ;
					$prenomMoa=  $tableauPR1 [$i][3] ;
					$idMoa = $tableauPR1 [$i][4] ;
					
					
					
					$i++;
					/* Exploitation des lignes dans la liste */
				?>
					
					<tr>
				
						
						<form name="consComp1Projet" id="consComp1ProjetForm" method="post"
				 			enctype="multipart/form-data" 
							action="">
						<td>
							<input type=text name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="16" readonly></input>
						</td>
									
						<td>
							<input type=text name="libelleCourtDivision" 
							value="<?php echo htmlspecialchars($libelleCourtDivision); ?>" 
							maxlength="20" size="16" readonly></input>
						</td>
						<td>
							<input type=text name="nomMoa" 
							value="<?php echo htmlspecialchars($nomMoa); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
						<td>
							<input type=text name="prenomMoa" 
							value="<?php echo htmlspecialchars($prenomMoa); ?>" 
							maxlength="20" size="16" readonly></input>
						</td>
							</form>
						<td>
							<form action="consMOA.php" method="post">

			 					<input type="hidden" name="idMoa" 
			 					value="<?php echo htmlspecialchars($idMoa); ?>">
			 					</input>
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form> 
						</td>
					</tr>
					
					<?php 
				}
				$query = null;
				?>	
				</table>	
			
			
			</fieldset>	
			<fieldset class="saisie">
			
			
				<table width="100%" border ="1" cellspacing="1" 
					cellpadding="1"><tr><td>
						<div align=center>
					Présentation des applications,<br></br>
					et des administrateurs ASI, responsables du<br></br>
					suivi de l'application
						</div>
					</td><tr></table>
				<table border=0>
				<?php 
				include('include/con3PRUT.php');
				$i = 0 ;
				
				$nomAppli =  null;
				$nomUti = null;
				$prenomUti =  null;
				$idUti = null;
				
				
				while ($i<$maxRow2)
				{
					$nomAppli =  $tableauPR2 [$i][0] ;
					$nomUti =  $tableauPR2 [$i][1] ;
					$prenomUti =  $tableauPR2 [$i][2] ;
					$idUti =  $tableauPR2 [$i][3];
					
					
					
					$i++;
					/* Exploitation des lignes dans la liste */
				?>
					
					<tr>
						<form name="consComp2Projet" id="consComp2ProjetForm" method="post"
				 		enctype="multipart/form-data" 
						action="">
				
						<td>
							<input type=text name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
						
						<td>
							<input type=text name="nomUti" 
							value="<?php echo htmlspecialchars($nomUti); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
						<td>
							<input type=text name="prenomUti" 
							value="<?php echo htmlspecialchars($prenomUti); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
					
					</form>
						<td>
							<form action="consUT.php" method="post">

			 					<input type="hidden" name="idUti" 
			 					value="<?php echo htmlspecialchars($idUti); ?>">
			 					</input>
			 				
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form> 
						</td>
					</tr>
					<?php 
				}
				$query = null;
				?>	
				</table>	
			
			
			</fieldset>	
			
			
			<fieldset class="saisie">
				
			
				<table width="100%" border ="1" cellspacing="1" 
					cellpadding="1"><tr><td>
						<div align=center>
					Présentation des applications,<br></br>
					et des bases de données impactées<br></br>
					
						</div>
					</td><tr></table>
				<table border=0>
				<?php include('include/con3PRBD.php'); 
				$i = 0 ;
				
				$nomAppli =  null;
				$nomAsi = null;
				$libelleMaj =  null;
				$idBasdon = null;
				
				
				while ($i<$maxRow3)
				{
					$nomAppli =  $tableauPR3 [$i][0] ;
					$nomAsi =  $tableauPR3 [$i][1] ;
					$libelleMaj =  $tableauPR3 [$i][2] ;
					$idBasdon =  $tableauPR3 [$i][3] ;
					
					
					$i++;
					/* Exploitation des lignes dans la liste */
				?>
					
					<tr>
						<form name="consComp3Projet" id="consComp3ProjetForm" method="post"
					 	enctype="multipart/form-data" 
						action="">
				
						<td>
							<input type=text name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
						
						<td>
							<input type=text name="nomAsi" 
							value="<?php echo htmlspecialchars($nomAsi); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
						<td>
							<input type=text name="libelleMaj" 
							value="<?php echo htmlspecialchars($libelleMaj); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
						</form>
						<td>
							<form action="consBD.php" method="post">

			 					<input type="hidden" name="idBasdon" 
			 					value="<?php echo htmlspecialchars($idBasdon); ?>">
			 					</input>
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form> 
						</td>
					</tr>
					
					<?php 
				}
				$query = null;
				?>	
				</table>	
		
			
			</fieldset>	
			<fieldset class="saisie">
			
			
				<table width="100%" border ="1" cellspacing="1" 
					cellpadding="1"><tr><td>
						<div align=center>
					Présentation des applications,<br></br>
					et de l'organisme de diffusion,<br></br>
					avec les contacts de cet organisme
						</div>
					</td><tr></table>
				<table border=0>
				<?php 
				include('include/con3PRCO.php');
				$i = 0 ;
				
				$nomAppli =  null;
				$nomDiffusion =  null;
				$nomContact = null;
				$prenomContact =  null;
				$idContact = null;
				
				
				while ($i<$maxRow4)
				{
					$nomAppli =  $tableauPR4 [$i][0] ;
					$nomDiffusion  =  $tableauPR4 [$i][1] ;
					$nomContact  =  $tableauPR4 [$i][2] ;
					$prenomContact  =  $tableauPR4 [$i][3] ;
					$idContact   =  $tableauPR4 [$i][4] ;
					
					$i++;
					/* Exploitation des lignes dans la liste */
				?>
					
					<tr>
						<form name="consComp4Projet" id="consComp4ProjetForm" method="post"
				 		enctype="multipart/form-data" 
						action="">
				
						<td>
							<input type=text name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="16" readonly></input>
						</td>
						<td>
							<input type=text name="nomDiffusion" 
							value="<?php echo htmlspecialchars($nomDiffusion); ?>" 
							maxlength="20" size="16" readonly></input>
						</td>
						
						<td>
							<input type=text name="nomContact" 
							value="<?php echo htmlspecialchars($nomContact); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
						<td>
							<input type=text name="prenomContact" 
							value="<?php echo htmlspecialchars($prenomContact); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
						</form>
						<td>
							<form action="consCO.php" method="post">

			 					<input type="hidden" name="idContact" 
			 					value="<?php echo htmlspecialchars($idContact); ?>">
			 					</input>
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form> 
						</td>
					</tr>
					
					<?php 
				}
				$query = null;
				?>	
				</table>	
			
			
			</fieldset>
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	
</div><!-- #global -->

</body>
</html>
