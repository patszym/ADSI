<?php	

if(!empty($_POST["soumet"]))
{

					$idContact = $_POST["idContact"];
					
					if(!empty($_POST["idRowDiffusion"]))
					{
						$idDiffusion=$_POST["idRowDiffusion"];
					} else
					{
						$idDiffusion = null;
					}
					
					if(!empty($_POST["nomContact"]))
					{
						$nomContact=$_POST["nomContact"];
					} else 
					{ 
						$nomContact = null;
					}
					
					if(!empty($_POST["prenomContact"]))						
					{
						$prenomContact=$_POST["prenomContact"];
					} else
					{
						$prenomContact = null;
					}
					
					if(!empty($_POST["telephoneContact"]))
					{
						$telephoneContact=$_POST["telephoneContact"];
					} else
					{
						$telephoneContact = null;
					}
					if(!empty($_POST["emailContact"]))
					{
						$emailContact=$_POST["emailContact"];
					} else
					{
						$emailContact = null;
					}
					if(!empty($_POST["ssDomFoncContact"]))
					{
						$ssDomFoncContact=$_POST["ssDomFoncContact"];
					} else
					{
						$ssDomFoncContact= null;
					}
					
					
					/* Les checbox fonctionnel et informatique :
					 * choix1 : fonctionnel et choix2, informatique
					 */
					$fonctionnel = 0;
					$informatique = 0;
					
					if(!empty($_POST["choix1"]))
					{
						$fonctionnel=1;
						
					
					}
					if(!empty($_POST["choix2"]))
					{
						$informatique=1;
						
					}
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE CONTACT SET '.
							' DIFFUSION_idDIFFUSION ="'.$idDiffusion.'",'.
							' nomCONTACT ="'.$nomContact.'",'.
							' prenomCONTACT ="'.$prenomContact.'",'.
							' telephoneCONTACT ="'.$telephoneContact.'",'.
							' emailCONTACT ="'.$emailContact.'",'.
							' ssDomFoncCONTACT ="'.$ssDomFoncContact.'",'.
							' FonctionnelCONTACT ='.$fonctionnel.', '.
							' InformatiqueCONTACT ='.$informatique.' '.
								' WHERE idCONTACT = :idContact ';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idContact', $idContact, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	