<?php	
			  
				
					if(!empty($_POST["Appli_idAppli"]))

					{
						$Appli_idAppli=$_POST["Appli_idAppli"];
					} else 
					{ 
						$Appli_idAppli = 0;
					}
									
					
					if(!empty($_POST["Basdon_idBasdon"]))
					{
						$Basdon_idBasdon=$_POST["Basdon_idBasdon"];
					} else 
					{ 
						$Basdon_idBasdon = 0;
					}
					
					$indic_Appli_has_Basdon = 0;
					
					if(!empty($_POST["indic_Appli_has_Basdon"]))
					{
						$indic_Appli_has_Basdon=1;
							
					}
						
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
					$validBase = true;
					$nbOccur = 0;
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT count(*) FROM APPLI_has_BASDON
							where APPLI_idAPPLI = :Appli_idAppli
							and BASDON_idBASDON = :Basdon_idBasdon";
					
					$gid = $dbh->prepare($sql1);
					$gid->bindValue(':Appli_idAppli', $Appli_idAppli, PDO::PARAM_INT);
					$gid->bindValue(':Basdon_idBasdon', $Basdon_idBasdon, PDO::PARAM_INT);
					$gid->execute();
					$nbOccur  = $gid->fetchColumn();
					
					if ($nbOccur !=0)
					{
						$validBase = false;
						echo $nbOccur. " occurence(s) dans la table APPLI_has_BASDON utilise(nt) cette réference APPLI et cette référence BASDON <br>";
						?>
						<script language="javascript">
						alert("L'ajout est impossible car il y a au moins une référence identique dans la table des rattachements application et base de données");
						</script>
						<?php
					}
					
					
			
					if ($validBase)
					{
					
						$sql = 'insert into APPLI_has_BASDON values ('.$Appli_idAppli.','
							.$Basdon_idBasdon.
							
							','.$indic_Appli_has_Basdon.
							');'   ;
						
						$dbh->exec($sql);
					
      				
						$dbh->commit();
						echo "Validation de l'Ajout faite";
					}
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
				
			}
				
	?>	