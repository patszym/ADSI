<?php
if (!empty( $_POST['soumet'] ))
{
	$dir = "blobExtract/";
	$dh  = opendir($dir);
	
	while (false !== ($filename = readdir($dh))) {
	
		$files[] = $filename;
		if (($filename != ".") and ($filename != "..")) 
			unlink ("blobExtract/".$filename);
	}
	echo "Nettoyage total réalisé sur le répertoire blobExtract du serveur et donc fait"; 	
}
if (!empty( $_POST['soumet2'] ))
{
	$dir = "blobExtract/";
	$dh  = opendir($dir);
	$ses_id = $_POST['ses_id'];
	$len = strlen($ses_id);
	


	while (false !== ($filename = readdir($dh))) {
		
		$subFilename = substr($filename, 0, $len);
		
		$files[] = $filename;
		if (($filename != ".") and ($filename != ".."))
		{
			if ($subFilename == $ses_id)
				unlink ("blobExtract/".$filename);
		}
	}
	echo "Nettoyage de vos fichiers réalisé sur le répertoire blobExtract du serveur et donc fait";
}
?>