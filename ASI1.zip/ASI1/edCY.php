<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">


<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>
		Cycles
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
</meta>
<head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> A l'appel du menu général, le mode <b> Liste et Edition</b> est le mode par défaut</p>
			<p> Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence Cycle</p>
			<p> Cliquez sur l'image de l'oeil pour voir le détail de la ligne spécifiée en consultation dans la liste</p>
			<p> Cliquez sur l'image du crayon pour voir le détail de la ligne spécifiée en modification dans la liste</p>
			<p> Cliquez sur l'image de la croix pour voir le détail de la ligne spécifiée en suppression dans la liste</p>
			<p>Cliquez sur l'icône <b>PDF</b> pour voir le détail de la ligne en obtenant son édition PDF </p>
			<p>Cliquez sur l'icône <b>PDF</b> à gauche du titre pour obtenir l'édition PDF de la liste</p>
			
	</div><!-- #secondaire -->
		
	<div id="principal"> 
			<h5>Gestion des Cycles </h5>
			
			<br>
			<div id="tabsF">
				<?php include('include/MHCY.php'); ?> 
									
			</div>
		
		<fieldset class="saisie">
			<table BORDER=0>
			
			<tr>
			
				<td>
				<a href="editions/edCYPDF.php">
				<img src="images/pdficon.jpg" height="20" width="20" align = "center" 
				alt="PDF">
				</a>
				</td>
				<td>
				<h3>  LISTE DES CYCLES </h3>
				</td>
			</tr>
				
				<?php 
				include_once "include/connBase.php" ; 
	
				$sql = 'select idCYCLE, libelleCourtCYCLE, 
					libelleLongCYCLE
					from CYCLE order by libelleCourtCYCLE';
	
			
				include_once "include/visuConVCY.php";
				
				$i = 0 ;
				$idCycle = null ;
				
				$libelleCourtCycle =  null;
				$libelleLongCycle =  null;
				while ($i<$maxRow)
				{
					$idCycle =  $tableau [$i][0] ;
					$libelleCourtCycle =  $tableau [$i][1] ;
					$libelleLongCycle =  $tableau [$i][2] ;
					
					
					$i++;
					/* Exploitation des lignes dans la liste */
					?>
									
				
				<!-- Liste des  Cycles - formulaire en lecture -->
													
						
									
						
							<input type="hidden" name="idCycle"
							value="<?php echo htmlspecialchars($idCycle); ?>"
							 ></input>
						
					<tr>
														
														
						<td>
							<input type=text name="libelleCourtCycle" 
							value="<?php echo htmlspecialchars($libelleCourtCycle); ?>" 
							maxlength="11" size="11" readonly></input>
						</td>
													
													
														
						<td>
							<input type=text name="libelleLongCycle" 
							value="<?php echo htmlspecialchars($libelleLongCycle); ?>" 
							maxlength="80" size="60" readonly></input>
						</td>
						
						<td>
							<form action="consCY.php" method="post">

			 					<input type="hidden" name="idCycle" 
			 					value="<?php echo htmlspecialchars($idCycle); ?>">
			 					</input>
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form> 
						</td>
						<td>
							<form action="modifCY.php" method="post">

			 					<input type="hidden" name="idCycle" 
			 					value="<?php echo htmlspecialchars($idCycle); ?>">
			 					</input>
								<input border=0 src="images/crayon.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form>
						</td>
							<td> 
							<form action="supprCY.php" method="post">

			 					<input type="hidden" name="idCycle" 
			 					value="<?php echo htmlspecialchars($idCycle); ?>">
			 					</input>
								<input border=0 src="images/button-cancel.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form>
						</td> 
						<td> 					
							
							<form action="editions/edElCYPDF.php" method="post">

			 					<input type="hidden" name="idCycle" 
								value="<?php echo htmlspecialchars($idCycle); ?>">
			 					</input>
								<input type="hidden" name="libelleCourtCycle" 
								value="<?php echo htmlspecialchars($libelleCourtCycle); ?>">
			 					</input>
			 		
								<input type="hidden" name="libelleLongCycle" 
								value="<?php echo htmlspecialchars($libelleLongCycle); ?>">
								</input>
								
			 					<input border=0 src="images/pdficon.jpg" 
								type=image value=submit name = "soumet" align="left" 
								height="20" width="20">
								</input>
										
							</form>
						</td>  							
					</tr>			
										
							
				<?php 
				}
				$query = null;
				?>
			</table>
		</fieldset>

		</div> <!-- principal-->
	
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
