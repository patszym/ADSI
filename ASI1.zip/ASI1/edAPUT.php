<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">


<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>
		rattachements Application base de données
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
</meta>
<head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> A l'appel du menu général, le mode <b> Liste et Edition</b> est le mode par défaut</p>
			<p> Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence Appli_idAppli</p>
			<p> Cliquez sur l'image de l'oeil pour voir le détail de la ligne spécifiée en consultation dans la liste</p>
			
			<p> Cliquez sur l'image de la croix pour voir le détail de la ligne spécifiée en suppression dans la liste</p>
			<p>Cliquez sur l'icône <b>PDF</b> pour voir le détail de la ligne en obtenant son édition PDF </p>
			<p>Cliquez sur l'icône <b>PDF</b> à gauche du titre pour obtenir l'édition PDF de la liste</p>
			
	</div><!-- #secondaire -->
		
	<div id="principal"> 
			<h5>Gestion des rattachements application et utilisateur </h5>
			
			<br>
		
		<fieldset class="saisie">
			<table BORDER=0>
			
			<tr>
			
				<td>
				<a href="editions/edAPUTPDF.php">
				<img src="images/pdficon.jpg" height="20" width="20" align = "center" 
				alt="PDF">
				</a>
				</td>
				<td>
				<h3>  LISTE DES RATTACHEMENTS DE UTILISATEUR AVEC APPLICATION </h3>
				</td>
			</tr>
				
				<?php 
				if(!empty($_POST["idAppli"]))
				{
					$idAppli=$_POST["idAppli"];
				}
				else {
					$idAppli = null;
				}
				
				include_once "include/connBase.php" ; 
	
				$sql = 'select APPLI_idAPPLI,UTILISATEUR_idUTILISATEUR,
					nomAPPLI, 
					nomUTILISATEUR, prenomUTILISATEUR
					from APPLI_has_UTILISATEUR, APPLI, UTILISATEUR
					where APPLI_idAPPLI = idAPPLI 
					and   UTILISATEUR_idUTILISATEUR = idUTILISATEUR
					and   APPLI_idAPPLI = :idAppli
						order by nomAPPLI, nomUTILISATEUR, prenomUTILISATEUR';
	
			
				include_once "include/visuConvAPUT.php";
				
				$i = 0 ;
				$Appli_idAppli = null;
				$Utilisateur_idUtilisateur = null;
				$nomAppli =  null;
				$nomUtilisateur =  null;
				$prenomUtilisateur= null;
				while ($i<$maxRow)
				{
					$Appli_idAppli = $tableau [$i][0];
					$Utilisateur_idUtilisateur = $tableau [$i][1] ;
					$nomAppli =  $tableau [$i][2] ;
					$nomUtilisateur =  $tableau [$i][3] ;
					$prenomUtilisateur =  $tableau [$i][4] ;
					
					
				
					
					
					$i++;
					?>
					<tr>
									
									
						
							<input type="hidden" name="Appli_idAppli"
							value="<?php echo htmlspecialchars($Appli_idAppli); ?>"
							 ></input>
						
													
						
							<input type="hidden" name="Utilisateur_idUtilisateur"
							value="<?php echo htmlspecialchars($Utilisateur_idUtilisateur); ?>"
							></input>
						
														
						<td>
							<input type="text" name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="20" readonly></input>
						</td>
													
													
														
						<td>
							<input type="text" name="nomUtilisateur" 
							value="<?php echo htmlspecialchars($nomUtilisateur); ?>" 
							maxlength="40" size="20" readonly></input>
						</td>
						<td>
							<input type="text" name="prenomUtilisateur" 
							value="<?php echo htmlspecialchars($prenomUtilisateur); ?>" 
							maxlength="40" size="20" readonly></input>
						</td>
						<td>
							<form action="consAPUT.php" method="post">

			 					<input type="hidden" name="Appli_idAppli" 
			 					value="<?php echo htmlspecialchars($Appli_idAppli); ?>">
			 					</input>
			 					<input type="hidden" name="Utilisateur_idUtilisateur" 
			 					value="<?php echo htmlspecialchars($Utilisateur_idUtilisateur); ?>">
			 					</input>
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form> 
						</td>
						
							<td> 
							<form action="supprAPUT.php" method="post">

			 					<input type="hidden" name="Appli_idAppli" 
			 					value="<?php echo htmlspecialchars($Appli_idAppli); ?>">
			 					</input>
			 					<input type="hidden" name="Utilisateur_idUtilisateur" 
			 					value="<?php echo htmlspecialchars($Utilisateur_idUtilisateur); ?>">
			 					</input>
								<input border=0 src="images/button-cancel.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20"></input>
		
							</form>
						</td> 
						<td> 					
							
							<form action="editions/edElAPUTPDF.php" method="post">

			 					<input type="hidden" name="Appli_idAppli" 
								value="<?php echo htmlspecialchars($Appli_idAppli); ?>">
			 					</input>
			 					<input type="hidden" name="Utilisateur_idUtilisateur"
								value="<?php echo htmlspecialchars($Utilisateur_idUtilisateur); ?>">
								</input>
						
								<input type="hidden" name="nomAppli" 
								value="<?php echo htmlspecialchars($nomAppli); ?>">
			 					</input>
			 		
								<input type="hidden" name="nomUtilisateur" 
								value="<?php echo htmlspecialchars($nomUtilisateur); ?>">
								</input>
								
								<input type="hidden" name="prenomUtilisateur" 
								value="<?php echo htmlspecialchars($prenomUtilisateur); ?>">
								</input>
								
			 					<input border=0 src="images/pdficon.jpg" 
								type=image value=submit name = "soumet" align="left" 
								height="20" width="20">
								</input>
										
							</form>
						</td>  							
					</tr>			
										
							
				<?php 
				}
				$query = null;
				?>
			</table>
		</fieldset>

		</div> <!-- principal-->
	
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
