<?php	

if(!empty($_POST["soumet"]))
{

					$idMoa = $_POST["idMoa"];
					
					if(!empty($_POST["idRowDivision"]))
					{
						$idDivision=$_POST["idRowDivision"];
					} else
					{
						$idDivision = null;
					}
					
					if(!empty($_POST["nomMoa"]))
					{
						$nomMoa=$_POST["nomMoa"];
					} else 
					{ 
						$nomMoa = null;
					}
					
					if(!empty($_POST["prenomMoa"]))						
					{
						$prenomMoa=$_POST["prenomMoa"];
					} else
					{
						$prenomMoa = null;
					}
					
				
					if(!empty($_POST["emailMoa"]))
					{
						$emailMoa=$_POST["emailMoa"];
					} else
					{
						$emailMoa = null;
					}
					if(!empty($_POST["telFixeMoa"]))
					{
						$telFixeMoa=$_POST["telFixeMoa"];
					} else
					{
						$telFixeMoa = null;
					}
					if(!empty($_POST["telMobMoa"]))
					{
						$telMobMoa=$_POST["telMobMoa"];
					} else
					{
						$telMobMoa = null;
					}
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE MOA SET '.
							' DIVISION_idDIVISION ="'.$idDivision.'",'.
							' nomMOA ="'.$nomMoa.'",'.
							' prenomMOA ="'.$prenomMoa.'",'.
							
							' emailMOA ="'.$emailMoa.'",'.
							' telFixeMOA ="'.$telFixeMoa.'",'.
							' telMobMOA ="'.$telMobMoa.'"'.
								' WHERE idMOA = :idMoa ';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idMoa', $idMoa, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	