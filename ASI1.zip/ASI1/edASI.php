<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Asi
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation1.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> A l'appel du menu général, le mode <b> Liste et Edition</b> est le mode par défaut</p>
			<p> Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence Asi</p>
			<p> Cliquez sur l'image de l'oeil pour voir le détail de la ligne spécifiée en consultation dans la liste</p>
			<p> Cliquez sur l'image du crayon pour voir le détail de la ligne spécifiée en modification dans la liste</p>
			<p> Cliquez sur l'image de la croix pour voir le détail de la ligne spécifiée en suppression dans la liste</p>
			<p>Cliquez sur l'icône <b>PDF</b> pour voir le détail de la ligne en obtenant son édition PDF </p>
			<p>Cliquez sur l'icône <b>PDF</b> à gauche du titre pour obtenir l'édition PDF de la liste</p>
			
	</div><!-- #secondaire -->
		
	<div id="principal"> 
			<h5>Gestion des ASIs </h5>
			
		
			<div id="tabsF">
				<?php include('include/MHASI.php'); ?> 
									
			</div>
		
		<fieldset class="saisie">
			<table BORDER=0>
			
			<tr>
			
				<td>
				<a href="editions/edASIPDF.php">
				<img src="images/pdficon.jpg" height="20" width="20" align = "center" 
				alt="PDF">
				</a>
				</td>
				<td>
				<h3>  LISTE DES  ASIs </h3>
				</td>
			</tr>
				
				<?php 
				include_once "include/connBase.php" ; 
	
				$sql = 'select idASI, nomASI, 
					 prenomASI, telephoneASI, emailASI,
					idAutreIdentASI, accesLDAP, sdaLDAP
					from ASI order by nomASI, prenomASI';
	
			
				include_once "include/visuConVASI.php";
				
				$i = 0 ;
				$idAsi = null ;
				$nomAsi =  null;
				$prenomAsi =  null ;
				$telephoneAsi = null;
				$emailAsi =  null;
				$idAutreIdentASI =  null;
				$accesLDAP =  null;
				$sdaLDAP =  null;	
				
				
				while ($i<$maxRow)
				{
					$idAsi =  $tableau [$i][0] ;
					$nomAsi =  $tableau [$i][1] ;
					$prenomAsi =  $tableau [$i][2] ;
					$telephoneAsi=  $tableau [$i][3] ;
					$emailAsi =  $tableau [$i] [4];
					$idAutreIdentASI =  $tableau [$i] [5];
					$accesLDAP =  $tableau [$i] [6];	
					$sdaLDAP  =  $tableau [$i] [7];
					
					
					$i++;
					/* Exploitation des lignes dans la liste */
					?>
									
				
				<!-- Liste des  Asis - formulaire en lecture -->
									
									
						
							<input type="hidden" name="idAsi"
							value="<?php echo htmlspecialchars($idAsi); ?>"
							 ></input>
						
													
					<tr>									
						<td>
							<input type=text name="nomAsi" 
							value="<?php echo htmlspecialchars($nomAsi); ?>" 
							maxlength="30" size="30" readonly></input>
						</td>
													
													
														
						<td>
							<input type=text name="prenomAsi" 
							value="<?php echo htmlspecialchars($prenomAsi); ?>" 
							maxlength="30" size="30" readonly></input>
						</td>
						
						
						<td>
							<form action="consASI.php" method="post">

			 					<input type="hidden" name="idAsi" 
			 					value="<?php echo htmlspecialchars($idAsi); ?>">
			 					</input>
			 				
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form> 
						</td>
						<td>
							<form action="modifASI.php" method="post">

			 					<input type="hidden" name="idAsi" 
			 					value="<?php echo htmlspecialchars($idAsi); ?>">
			 					</input>
			 				
								<input border=0 src="images/crayon.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form>
						</td>
							<td> 
							<form action="supprASI.php" method="post">

			 					<input type="hidden" name="idAsi" 
			 					value="<?php echo htmlspecialchars($idAsi); ?>">
			 					</input>
			 				
								<input border=0 src="images/button-cancel.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form>
						</td> 
						<td> 					
							
							<form action="editions/edElASIPDF.php" method="post">

			 					<input type="hidden" name="idAsi" 
								value="<?php echo htmlspecialchars($idAsi); ?>">
								</input>
			 				
								<input type="hidden" name="nomAsi" 
								value="<?php echo htmlspecialchars($nomAsi); ?>">
								</input>
			 				
			 		
								<input type="hidden" name="prenomAsi" 
								value="<?php echo htmlspecialchars($prenomAsi); ?>">
								</input>
							
								<input type="hidden" name="telephoneAsi" 
								value="<?php echo htmlspecialchars($telephoneAsi); ?>">
								</input>
								
								<input type="hidden" name="emailAsi" 
								value="<?php echo htmlspecialchars($emailAsi); ?>">
								</input>
								
								<input type="hidden" name="idAutreIdentASI" 
								value="<?php echo htmlspecialchars($idAutreIdentASI); ?>">
								</input>
				
								<input type="hidden" name="accesLDAP" 
								value="<?php echo htmlspecialchars($accesLDAP); ?>">
								</input>
			 					
			 					<input type="hidden" name="sdaLDAP" 
								value="<?php echo htmlspecialchars($sdaLDAP); ?>">
								</input>
			 					
			 					<input border=0 src="images/pdficon.jpg" 
								type=image value=submit name = "soumet" align="left" 
								height="20" width="20">
								</input>

										
							</form>
						</td>  							
					</tr>			
										
							
				<?php 
				}
				$query = null;
				?>
			</table>
		</fieldset>

		</div> <!-- principal-->
	
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
