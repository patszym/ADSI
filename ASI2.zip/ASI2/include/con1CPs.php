<?php 
			if(!empty($_POST["idAppli"]))
			{
				$idAppli=$_POST["idAppli"];
			} else
			{
				
				$idAppli = null;
			}
			$libelleCampagne = null;
			$nomAppli = null;
			$libelleSelCampagne = null;
			$nomSelAppli = null;
			$index1 = 0;
			if (!(empty($idAppli)))
			{
		
				include('include/connBase.php');
				// on crée la requête SQL
				
				$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
				$sql = 'SELECT idCAMPAGNE, libelleCAMPAGNE, nomAPPLI
						FROM CAMPAGNE, APPLI
						WHERE APPLI_idAPPLI = :idAppli
						AND APPLI_idAPPLI = idAPPLI
				ORDER BY nomAPPLI, libelleCAMPAGNE ';
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				$query->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
				
				$query->execute();
				
				$tableau1 = array();
			
				// Parcours des résultats
				
				$libelleSelCampagne = null;
				$nomSelAppli = null;
				
				while ($row = $query->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
				
				{
					
					
					$arg0 = $row [0];
					
					$arg1 = $row [1] ;
					$arg3 = $row [2];
				
					$nomAppli = $arg3;
					
					$arg2=null;
					$tableau1[$index1][2] = null;
				
					
					if ($idRowCampagne == $arg0)
					{
						$arg2 = "selected";
						$libelleSelCampagne = $arg1;
						$nomSelAppli = $arg3;
						
					}
					$tableau1[$index1] = array($arg0,$arg1,$arg2, $arg3);
					
					$index1++;
					// $u représente l'utilisateur courant du jeu de résultats
					// La forme prise par $u pour représenter ce résultat est vue ci-dessous
				
				}
				if (!(empty($libelleSelCampagne)))
				{
					$libelleCampagne = $libelleSelCampagne;
				}
				if (!(empty($nomSelAppli)))
				{
					$nomAppli = $nomSelAppli;
				}
			}
					
			?> 