		<div id="navigation">
			<ul>
				<li><a href="index.php">Accueil</a></li>
				<li><a href="logout.php">Déconnection</a></li>
				<li><a href="edPR.php">Projets</a></li>
				<li><a href="etTC.php">Etat des taches</a></li>
				<li><a href="edCA.php">Calendriers</a></li>
				<li><a href="edTM.php">Traitements de mise à jour Logicielle</a></li>
				<li><a href="edTL.php">Traitements locaux</a></li>
				<li><a href="edCP.php">Campagnes</a></li>
				<li><a href="edPO.php">Phases</a></li>
				<li><a href="edTA.php">Tâches</a></li>
				<li><a href="edCC.php">Campagne par cycle</a></li>
				<li><a href="edPC.php">Phases par cycle</a></li>
				<li><a href="edTC.php">Tache par cycle</a></li>
			</ul>
		</div><!-- #navigation    -->