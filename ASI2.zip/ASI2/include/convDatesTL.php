<?php
include_once('ConversionDates.class.php');
$ddemandeTraitlocal = null;

if (!empty ($datedemandeTraitlocal))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datedemandeTraitlocal);
	$conversionDates->convDated();
	$ddemandeTraitlocal = $conversionDates->getdt() ;
	
}

 
?>