<?php 
			
				include('include/con2log.php');
				
				$nomAppli = null;			
				$nomSelAppli = null;
				$index1 = 0;
				// on crée la requête SQL
				$index1 = 0;
				
				$sql = 'SELECT idAPPLI, nomAPPLI'; 
				$sql = $sql .'	FROM APPLI';
				
					
					if ($admuti == 'uti')
					{
						
						$sql=$sql.' , APPLI_has_UTI';
						
						$sql=$sql.' WHERE APPLI.idAPPLI = APPLI_has_UTI.APPLI_idAPPLI';
						$sql=$sql.' AND APPLI_has_UTI.UTI_idUTI = :idUti';
					}
				
			
				
				$sql = $sql.' ORDER BY nomAPPLI ';
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				
					if ($admuti == 'uti')
					{
							
						$query->bindParam(':idUti', $idUti, PDO::PARAM_INT);
					}
				
				//echo $sql;
				$query->execute();
			
				$tableau1 = array();
				
				// Parcours des résultats
				
				while ($row = $query->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
				{
					
					$arg0 = $row [0];
					
					$arg1 = $row [1] ;
					
					$arg2=null;
					$tableau1[$index1][2] = null;
					if ($idRowAppli == $arg0)
					{
						$arg2 = "selected";
						$nomSelAppli = $arg1;
					}
					$tableau1[$index1] = array($arg0,$arg1,$arg2);
					
					$index1++;
					// $u représente l'utilisateur courant du jeu de résultats
					// La forme prise par $u pour représenter ce résultat est vue ci-dessous
				
				}
				if (!(empty($nomSelAppli)))
				{
					$nomAppli = $nomSelAppli;
				}
				
				
					
			?> 