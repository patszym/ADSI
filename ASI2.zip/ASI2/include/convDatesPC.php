<?php
include_once('ConversionDates.class.php');
$dPrevOuvProcessuscycle = null;
$HPrevOuvProcessuscycle = null;
$iPrevOuvProcessuscycle = null;
if (!empty ($datePrevOuvProcessuscycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevOuvProcessuscycle);
	$conversionDates->convDated();
	$dPrevOuvProcessuscycle = $conversionDates->getdt() ;
	$HPrevOuvProcessuscycle = $conversionDates->getheure() ;
	$iPrevOuvProcessuscycle = $conversionDates->getminut() ;
}
$dEffOuvProcessuscycle = null;
$HEffOuvProcessuscycle = null;
$iEffOuvProcessuscycle = null;
if (!empty ($dateEffOuvProcessuscycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffOuvProcessuscycle);
	$conversionDates->convDated();
	$dEffOuvProcessuscycle = $conversionDates->getdt() ;
	$HEffOuvProcessuscycle = $conversionDates->getheure() ;
	$iEffOuvProcessuscycle = $conversionDates->getminut() ;
}
$dPrevFerProcessuscycle = null;
$HPrevFerProcessuscycle = null;
$iPrevFerProcessuscycle = null;
if (!empty ($datePrevFerProcessuscycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevFerProcessuscycle);
	$conversionDates->convDated();
	$dPrevFerProcessuscycle = $conversionDates->getdt() ;
	$HPrevFerProcessuscycle = $conversionDates->getheure() ;
	$iPrevFerProcessuscycle = $conversionDates->getminut() ;
}
$dEffFerProcessuscycle = null;
$HEffFerProcessuscycle = null;
$iEffFerProcessuscycle = null;
if (!empty ($dateEffFerProcessuscycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffFerProcessuscycle);
	$conversionDates->convDated();
	$dEffFerProcessuscycle = $conversionDates->getdt() ;
	$HEffFerProcessuscycle = $conversionDates->getheure() ;
	$iEffFerProcessuscycle = $conversionDates->getminut() ;
}
$dPrevFinProcessuscycle = null;
$HPrevFinProcessuscycle = null;
$iPrevFinProcessuscycle = null;
if (!empty ($datePrevFinProcessuscycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevFinProcessuscycle);
	$conversionDates->convDated();
	$dPrevFinProcessuscycle = $conversionDates->getdt() ;
	$HPrevFinProcessuscycle = $conversionDates->getheure() ;
	$iPrevFinProcessuscycle = $conversionDates->getminut() ;
}
$dEffFinProcessuscycle = null;
$HEffFinProcessuscycle = null;
$iEffFinProcessuscycle = null;
if (!empty ($dateEffFinProcessuscycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffFinProcessuscycle);
	$conversionDates->convDated();
	$dEffFinProcessuscycle = $conversionDates->getdt() ;
	$HEffFinProcessuscycle = $conversionDates->getheure() ;
	$iEffFinProcessuscycle = $conversionDates->getminut() ;
}
?>