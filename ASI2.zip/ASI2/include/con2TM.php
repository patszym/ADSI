<?php 

				/* initialisations : */
			
				
				$validId = true;
				$nomTraitmaj=null;
				$libelleTraitmaj=null;
				$servTraitmaj = null;
				$chemTraitmaj=null;
				$nomprogTraitmaj = null;
				$locCompRendTraitmaj = null;
				$crdTraitmaj=null;
				$mimecrdTraitmaj=null;
				$sizecrdTraitmaj=null;
				$filenamecrdTraitmaj = null;
				$extensioncrdTraitmaj = null;
				
				
				if(!empty($_POST["idTraitmaj"]))
				{
					$idTraitmaj = $_POST['idTraitmaj'];
					/// $idTraitmaj = filter_var($idTraitmaj), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idTraitmaj))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idTraitmaj = $_POST['idTraitmaj'];
					
				} else {
					$idTraitmaj = null;
					
				}
				// Initialisation de la session :
				
				session_start();
				$ses_id = session_id();
					
			
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  APPLI_idAPPLI, nomTRAITMAJ, libelleTRAITMAJ, 
						servTRAITMAJ, chemTRAITMAJ, 
						nomprogTRAITMAJ, locCompRendTRAITMAJ, 
						crdTRAITMAJ, mimecrdTRAITMAJ,
						sizecrdTRAITMAJ,filenamecrdTRAITMAJ,
						extensioncrdTRAITMAJ
						
						FROM TRAITMAJ
    					WHERE idTRAITMAJ  = :idTraitmaj LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idTraitmaj, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idTraitmaj' => $idTraitmaj));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								if (!empty ($row['APPLI_idAPPLI']))
								{
									$idRowAppli=$row['APPLI_idAPPLI'];
								}
								else
								{
									$idRowAppli=null;
								}
								if (!empty ($row['nomTRAITMAJ']))
								{
									$nomTraitmaj=$row['nomTRAITMAJ'];
								}
								else 
								{
									$nomTraitmaj=null;
								}
								if (!empty ($row['libelleTRAITMAJ']))
								{
									$libelleTraitmaj=$row['libelleTRAITMAJ'];
								}
								else
								{
									$libelleTraitmaj=null;
								}
							
								if (!empty ($row['servTRAITMAJ']))
								{
									$servTraitmaj=$row['servTRAITMAJ'];
								}
								else
								{
									$servTraitmaj=null;
								}
								
								if (!empty ($row['chemTRAITMAJ']))
								{
									$chemTraitmaj=$row['chemTRAITMAJ'];
								}
								else
								{
									$chemTraitmaj=null;
								}
								if (!empty ($row['nomprogTRAITMAJ']))
								{
									$nomprogTraitmaj=$row['nomprogTRAITMAJ'];
								}
								else
								{
									$nomprogTraitmaj=null;
								}
								if (!empty ($row['locCompRendTRAITMAJ']))
								{
									$locCompRendTraitmaj=$row['locCompRendTRAITMAJ'];
								}
								else
								{
									$locCompRendTraitmaj=null;
								}
								// Traitement de crd
								
								if (!empty ($row['crdTRAITMAJ']))
								{
									$crdTraitmaj=$row['crdTRAITMAJ'];
								}
								else
								{
									$crdTraitmaj=null;
								}
								if (!empty ($row['mimecrdTRAITMAJ']))
								{
									$mimecrdTraitmaj=$row['mimecrdTRAITMAJ'];
										
								}
								else
								{
									$mimecrdTraitmaj=null;
									
										
								}
								
								if (!empty ($row['sizecrdTRAITMAJ']))
								{
									$sizecrdTraitmaj=$row['sizecrdTRAITMAJ'];
								}
								else
								{
									$sizecrdTraitmaj=null;
								}
								if (!empty ($row['filenamecrdTRAITMAJ']))
								{
									$filenamecrdTraitmaj=$row['filenamecrdTRAITMAJ'];
								}
								else
								{
								$filenamecrdTraitmaj=null;
								}
								if (!empty ($row['extensioncrdTRAITMAJ']))
								{
									$extensioncrdTraitmaj=$row['extensioncrdTRAITMAJ'];
								}
								else
								{
									$extensioncrdTraitmaj=null;
								}
								
								
								if ($cons == 1)
								{
											
									
								
									$ficcrdnom = "blobExtract/".$ses_id.$filenamecrdTraitmaj.".".$extensioncrdTraitmaj;
								
									$fp = fopen($ficcrdnom, 'w');
									
									if (fwrite($fp,$crdTraitmaj)) {
										echo "Le fichier de compte rendu à été créé avec succès.";
									} else {
										// Erreur
										echo "Impossible de créer le fichier de compte rendu.";
									}
									fclose($fp);
								}
									
									
								
							}
						
					
					
				}
				
					
			?> 