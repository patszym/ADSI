
<?php
 $dsn = 'mysql:dbname=ASI;host=127.0.0.1';

/* $dsn = 'mysql:dbname=test;host=127.0.0.1';*/
$user = 'admin';
$password = 'neo';

try {
	
	$dbh = new PDO($dsn, $user, $password)
	
	
		;
} catch (PDOException $e) {
	echo 'Connexion échouée : ' . $e->getMessage();
}

?>