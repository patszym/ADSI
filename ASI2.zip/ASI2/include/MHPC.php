<ul>
<li><a href="edPC.php" title="Liste et Edition"><span>Liste et Edition</span></a></li>

<li><a href="ajPC_AP.php" title="Ajout"><span>Ajout</span></a></li>

</ul>
