<?php
include_once('ConversionDates.class.php');
$dPrevOuvCampagnecycle = null;
$HPrevOuvCampagnecycle = null;
$iPrevOuvCampagnecycle = null;
if (!empty ($datePrevOuvCampagnecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevOuvCampagnecycle);
	$conversionDates->convDated();
	$dPrevOuvCampagnecycle = $conversionDates->getdt() ;
	$HPrevOuvCampagnecycle = $conversionDates->getheure() ;
	$iPrevOuvCampagnecycle = $conversionDates->getminut() ;
}
$dEffOuvCampagnecycle = null;
$HEffOuvCampagnecycle = null;
$iEffOuvCampagnecycle = null;
if (!empty ($dateEffOuvCampagnecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffOuvCampagnecycle);
	$conversionDates->convDated();
	$dEffOuvCampagnecycle = $conversionDates->getdt() ;
	$HEffOuvCampagnecycle = $conversionDates->getheure() ;
	$iEffOuvCampagnecycle = $conversionDates->getminut() ;
}
$dPrevFerCampagnecycle = null;
$HPrevFerCampagnecycle = null;
$iPrevFerCampagnecycle = null;
if (!empty ($datePrevFerCampagnecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevFerCampagnecycle);
	$conversionDates->convDated();
	$dPrevFerCampagnecycle = $conversionDates->getdt() ;
	$HPrevFerCampagnecycle = $conversionDates->getheure() ;
	$iPrevFerCampagnecycle = $conversionDates->getminut() ;
}
$dEffFerCampagnecycle = null;
$HEffFerCampagnecycle = null;
$iEffFerCampagnecycle = null;
if (!empty ($dateEffFerCampagnecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffFerCampagnecycle);
	$conversionDates->convDated();
	$dEffFerCampagnecycle = $conversionDates->getdt() ;
	$HEffFerCampagnecycle = $conversionDates->getheure() ;
	$iEffFerCampagnecycle = $conversionDates->getminut() ;
}
$dPrevFinCampagnecycle = null;
$HPrevFinCampagnecycle = null;
$iPrevFinCampagnecycle = null;
if (!empty ($datePrevFinCampagnecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevFinCampagnecycle);
	$conversionDates->convDated();
	$dPrevFinCampagnecycle = $conversionDates->getdt() ;
	$HPrevFinCampagnecycle = $conversionDates->getheure() ;
	$iPrevFinCampagnecycle = $conversionDates->getminut() ;
}
$dEffFinCampagnecycle = null;
$HEffFinCampagnecycle = null;
$iEffFinCampagnecycle = null;
if (!empty ($dateEffFinCampagnecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffFinCampagnecycle);
	$conversionDates->convDated();
	$dEffFinCampagnecycle = $conversionDates->getdt() ;
	$HEffFinCampagnecycle = $conversionDates->getheure() ;
	$iEffFinCampagnecycle = $conversionDates->getminut() ;
}
?>