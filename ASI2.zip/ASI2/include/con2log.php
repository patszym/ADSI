<?php
/* initialisations : */


include('include/connBase.php');
$validId = false;



if(isset($_SESSION["idloginUti"]))
{
	if(!empty($_SESSION["idloginUti"]))
	{
		$idloginUti = $_SESSION['idloginUti'];
		$validId = true;
	}
}

if(isset($_SESSION["admuti"]))
{

	if(!empty($_SESSION["admuti"]))
	{
		$admuti = $_SESSION['admuti'];
		
		if ($admuti == "adm") $adm = 1;
		if ($admuti == "uti") $adm = 0;
		
	}
}
 else {
 	$adm = true;
 }

if(isset($_SESSION["ses_id"]))
{
	if(!empty($_SESSION["ses_id"]))
	{
		$ses_id = $_SESSION['ses_id'];
		
	}
}

if ($validId == true)
{

	
	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql="SELECT  idUTI,
								nomUTI,
								prenomUTI,

								loginUTI,
								mdpUTI,
								datemodifUTI

							FROM UTI ";
	
if (!empty($idloginUti))
{
		$sql = $sql . " WHERE "."idUTI = :idloginUti";
		$sql = $sql." LIMIT 1";
		$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
		$sth->bindValue(':idloginUti', $idloginUti, PDO::PARAM_INT);
			
	
		
	// echo $sql;
	try {
		$sth->execute();
			
	} catch (PDOException $e) {
		echo 'la recherche du login a échouée : ' . $e->getMessage();
			
	}
	while ($row = $sth->fetch())
		
	{

		if (!empty ($row['idUTI']))
		{
			$idUti=$row['idUTI'];
		}
		else
		{
			$idUti=null;
		}
		
		if (!empty ($row['nomUTI']))
		{
			$nomUti=$row['nomUTI'];
				
		}
		else
		{
			$nomUti=null;
		}
		if (!empty ($row['prenomUTI']))
		{
			$prenomUti=$row['prenomUTI'];

		}
		if (!empty ($row['loginUTI']))
		{
			$loginUti=$row['loginUTI'];

		}
		else
		{
			$loginUti=null;
		}
		if (!empty ($row['mdpUTI']))
		{
			$mdpUti=$row['mdpUTI'];

		}
		else
		{
			$mdpUti=null;
		}
		if (!empty ($row['datemodifUTI']))
		{
			$datemodifUti=$row['datemodifUTI'];

		}
		else
		{
			$datemodifUti=null;
		}
		
	
		
	}
}

		
		
}

	
?>