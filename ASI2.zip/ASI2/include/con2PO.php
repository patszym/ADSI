<?php 

				/* initialisations : */
			
				
				$validId = true;
				
				$libelleProcessus=null;
				$descriptifProcessus = null;
				$nomAppli = null;
				
				if(!empty($_POST["idProcessus"]))
				{
					$idProcessus = $_POST['idProcessus'];
					/// $idProcessus = filter_var($idProcessus), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idProcessus))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idProcessus = $_POST['idProcessus'];
					
				} else {
					$idProcessus = null;
					
				}
				// Initialisation de la session :
				
				session_start();
				$ses_id = session_id();
					
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  CAMPAGNE_idCAMPAGNE, libellePROCESSUS, 
						descriptifPROCESSUS, nomAPPLI, idAPPLI
						
						FROM PROCESSUS, CAMPAGNE, APPLI
    					WHERE CAMPAGNE.APPLI_idAPPLI = APPLI.idAPPLI
							AND PROCESSUS.CAMPAGNE_idCAMPAGNE = CAMPAGNE.idCAMPAGNE
							AND idPROCESSUS  = :idProcessus 
							LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idProcessus, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idProcessus' => $idProcessus));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								if (!empty ($row['CAMPAGNE_idCAMPAGNE']))
								{
									$idRowCampagne=$row['CAMPAGNE_idCAMPAGNE'];
								}
								else
								{
									$idRowCampagne=null;
								}
								
								
								if (!empty ($row['libellePROCESSUS']))
								{
									$libelleProcessus=$row['libellePROCESSUS'];
								}
								else
								{
									$libelleProcessus=null;
								}
							
								
								
								if (!empty ($row['descriptifPROCESSUS']))
								{
									$descriptifProcessus=$row['descriptifPROCESSUS'];
								}
								else
								{
									$descriptifProcessus=null;
								}
								
								if (!empty ($row['nomAPPLI']))
								{
									$nomAppli=$row['nomAPPLI'];
								}
								else
								{
									$nomAppli=null;
								}
								if (!empty ($row['idAPPLI']))
								{
									$idAppli=$row['idAPPLI'];
								}
								else
								{
									$idAppli=null;
								}
								
								
							}
						
					
					
				}
				
					
			?> 