<ul>
<li><a href="edTC.php" title="Liste et Edition"><span>Liste et Edition</span></a></li>

<li><a href="ajTC_AP.php" title="Ajout"><span>Ajout</span></a></li>

</ul>
