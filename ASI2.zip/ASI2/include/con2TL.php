<?php 
include_once('include/ConversionDates.class.php');
				/* initialisations : */
			
				
				$validId = true;
				$nomTraitlocal=null;
				$libelleTraitlocal=null;
				$servTraitlocal = null;
				$chemTraitlocal=null;
				$nomprogTraitlocal = null;
				$phraseSQLTraitlocal = null;
				$ddemandeTraitlocal = null;
				if(!empty($_POST["idTraitlocal"]))
				{
					$idTraitlocal = $_POST['idTraitlocal'];
					/// $idTraitlocal = filter_var($idTraitlocal), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idTraitlocal))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idTraitlocal = $_POST['idTraitlocal'];
					
				} else {
					$idTraitlocal = null;
					
				}
				
				// Initialisation de la session :
				
				session_start();
				$ses_id = session_id();
					
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  APPLI_idAPPLI, nomTRAITLOCAL, libelleTRAITLOCAL, 
						servTRAITLOCAL, chemTRAITLOCAL, 
						nomprogTRAITLOCAL, phraseSQLTRAITLOCAL, 
						datedemandeTRAITLOCAL
						
						FROM TRAITLOCAL
    					WHERE idTRAITLOCAL  = :idTraitlocal LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idTraitlocal, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idTraitlocal' => $idTraitlocal));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								if (!empty ($row['APPLI_idAPPLI']))
								{
									$idRowAppli=$row['APPLI_idAPPLI'];
								}
								else
								{
									$idRowAppli=null;
								}
								if (!empty ($row['nomTRAITLOCAL']))
								{
									$nomTraitlocal=$row['nomTRAITLOCAL'];
								}
								else 
								{
									$nomTraitlocal=null;
								}
								if (!empty ($row['libelleTRAITLOCAL']))
								{
									$libelleTraitlocal=$row['libelleTRAITLOCAL'];
								}
								else
								{
									$libelleTraitlocal=null;
								}
							
								if (!empty ($row['servTRAITLOCAL']))
								{
									$servTraitlocal=$row['servTRAITLOCAL'];
								}
								else
								{
									$servTraitlocal=null;
								}
								
								if (!empty ($row['chemTRAITLOCAL']))
								{
									$chemTraitlocal=$row['chemTRAITLOCAL'];
								}
								else
								{
									$chemTraitlocal=null;
								}
								if (!empty ($row['nomprogTRAITLOCAL']))
								{
									$nomprogTraitlocal=$row['nomprogTRAITLOCAL'];
								}
								else
								{
									$nomprogTraitlocal=null;
								}
								if (!empty ($row['phraseSQLTRAITLOCAL']))
								{
									$phraseSQLTraitlocal=$row['phraseSQLTRAITLOCAL'];
								}
								else
								{
									$phraseSQLTraitlocal=null;
								}
							
								if (!empty ($row['datedemandeTRAITLOCAL']))
								{
								
									$datedemandeTraitlocal=$row['datedemandeTRAITLOCAL'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($datedemandeTraitlocal);
									$conversionDates->convDated();
									$ddemandeTraitlocal = $conversionDates->getdt() ;
									
								}
								else
								{
									$ddemandeTraitlocal=null;
									
								}
											
								
								
								
							}
						
					
					
				}
				
					
			?> 