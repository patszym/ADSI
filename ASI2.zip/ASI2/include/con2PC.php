<?php 
include_once('include/ConversionDates.class.php');
				/* initialisations : */
			
				
				$validId = true;
				
				
				if(!empty($_POST["idProcessuscycle"]))
				{
					$idProcessuscycle = $_POST['idProcessuscycle'];
					/// $idProcessuscycle = filter_var($idProcessuscycle), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idProcessuscycle))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idProcessuscycle = $_POST['idProcessuscycle'];
					
				} else {
					$idProcessuscycle = null;
					
				}
				
				// Initialisation de la session :
			
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT CYCLE_idCYCLE, PROCESSUS_idPROCESSUS, nomAPPLI,
					 		libelleCAMPAGNE,
					 		libellePROCESSUS, 
						libelleLongCYCLE,
						datePrevOuvPROCESSUSCYCLE, 
						dateEffOuvPROCESSUSCYCLE, 
						datePrevFerPROCESSUSCYCLE, 
						dateEffFerPROCESSUSCYCLE, 
						datePrevFinPROCESSUSCYCLE, 
						dateEffFinPROCESSUSCYCLE 
						
						FROM PROCESSUSCYCLE, CAMPAGNE, PROCESSUS, APPLI, CYCLE
    					WHERE idPROCESSUSCYCLE  = :idProcessuscycle 
						AND APPLI.idAPPLI = CAMPAGNE.APPLI_idAPPLI
					 	AND CAMPAGNE.idCAMPAGNE = PROCESSUS.CAMPAGNE_idCAMPAGNE
						AND PROCESSUSCYCLE.PROCESSUS_idPROCESSUS = PROCESSUS.idPROCESSUS
						AND PROCESSUSCYCLE.CYCLE_idCYCLE = CYCLE.idCYCLE
						LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idProcessuscycle, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idProcessuscycle' => $idProcessuscycle));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								if (!empty ($row['PROCESSUS_idPROCESSUS']))
								{
									$idRowProcessus=$row['PROCESSUS_idPROCESSUS'];
								}
								else
								{
									$idRowProcessus=null;
								}
								if (!empty ($row['CYCLE_idCYCLE']))
								{
									$idRowCycle=$row['CYCLE_idCYCLE'];
								}
								else
								{
									$idRowCycle=null;
								}
								if (!empty ($row['nomAPPLI']))
								{
									$nomAppli=$row['nomAPPLI'];
								}
								else 
								{
									$nomAppli=null;
								}
								if (!empty ($row['libelleCAMPAGNE']))
								{
									$libelleCampagne=$row['libelleCAMPAGNE'];
								}
								else
								{
									$libelleCampagne=null;
								}
									
								if (!empty ($row['libellePROCESSUS']))
								{
									$libelleProcessus=$row['libellePROCESSUS'];
								}
								else
								{
									$libelleProcessus=null;
								}
							
								
								// date d'ouverture	
								if (!empty ($row['datePrevOuvPROCESSUSCYCLE']))
								{
								
									$datePrevOuvProcessuscycle=$row['datePrevOuvPROCESSUSCYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($datePrevOuvProcessuscycle);
									$conversionDates->convDated();
									$dPrevOuvProcessuscycle = $conversionDates->getdt() ;
									$HPrevOuvProcessuscycle = $conversionDates->getheure() ;
									$iPrevOuvProcessuscycle = $conversionDates->getminut() ;
								}
								else
								{
									$dPrevOuvProcessuscycle=null;
									$HPrevOuvProcessuscycle = null;
									$iPrevOuvProcessuscycle = null;
								}
								if (!empty ($row['dateEffOuvPROCESSUSCYCLE']))
								{
								
									$dateEffOuvProcessuscycle=$row['dateEffOuvPROCESSUSCYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateEffOuvProcessuscycle);
									$conversionDates->convDated();
									$dEffOuvProcessuscycle = $conversionDates->getdt() ;
									$HEffOuvProcessuscycle = $conversionDates->getheure() ;
									$iEffOuvProcessuscycle = $conversionDates->getminut() ;
								}
								else
								{
									$dEffOuvProcessuscycle=null;
									$HEffOuvProcessuscycle = null;
									$iEffOuvProcessuscycle = null;
								}			
								// date de fermeture
								if (!empty ($row['datePrevFerPROCESSUSCYCLE']))
								{
								
									$datePrevFerProcessuscycle=$row['datePrevFerPROCESSUSCYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($datePrevFerProcessuscycle);
									$conversionDates->convDated();
									$dPrevFerProcessuscycle = $conversionDates->getdt() ;
									$HPrevFerProcessuscycle = $conversionDates->getheure() ;
									$iPrevFerProcessuscycle = $conversionDates->getminut() ;
								}
								else
								{
									$dPrevFerProcessuscycle=null;
									$HPrevFerProcessuscycle = null;
									$iPrevFerProcessuscycle = null;
								}
								if (!empty ($row['dateEffFerPROCESSUSCYCLE']))
								{
								
									$dateEffFerProcessuscycle=$row['dateEffFerPROCESSUSCYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateEffFerProcessuscycle);
									$conversionDates->convDated();
									$dEffFerProcessuscycle = $conversionDates->getdt() ;
									$HEffFerProcessuscycle = $conversionDates->getheure() ;
									$iEffFerProcessuscycle = $conversionDates->getminut() ;
								}
								else
								{
									$dEffFerProcessuscycle=null;
									$HEffFerProcessuscycle = null;
									$iEffFerProcessuscycle = null;
								}
								// date de fin
								if (!empty ($row['datePrevFinPROCESSUSCYCLE']))
								{
								
									$datePrevFinProcessuscycle=$row['datePrevFinPROCESSUSCYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($datePrevFinProcessuscycle);
									$conversionDates->convDated();
									$dPrevFinProcessuscycle = $conversionDates->getdt() ;
									$HPrevFinProcessuscycle = $conversionDates->getheure() ;
									$iPrevFinProcessuscycle = $conversionDates->getminut() ;
								}
								else
								{
									$dPrevFinProcessuscycle=null;
									$HPrevFinProcessuscycle = null;
									$iPrevFinProcessuscycle = null;
								}
								if (!empty ($row['dateEffFinPROCESSUSCYCLE']))
								{
								
									$dateEffFinProcessuscycle=$row['dateEffFinPROCESSUSCYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateEffFinProcessuscycle);
									$conversionDates->convDated();
									$dEffFinProcessuscycle = $conversionDates->getdt() ;
									$HEffFinProcessuscycle = $conversionDates->getheure() ;
									$iEffFinProcessuscycle = $conversionDates->getminut() ;
								}
								else
								{
									$dEffFinProcessuscycle=null;
									$HEffFinProcessuscycle = null;
									$iEffFinProcessuscycle = null;
								}
								
							}
						
					
					
				}
				
					
			?> 