<?php 
			
				
				include('include/connBase.php');
				// on crée la requête SQL
				
				$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
				$sql = 'SELECT idDIFFUSION, nomDIFFUSION FROM DIFFUSION
				ORDER BY nomDIFFUSION ';
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				$query->execute();
			
				$tableau3 = array();
				$index3 = 0;
				// Parcours des résultats
				
				while ($row = $query->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
				{
					
					$arg0 = $row [0];
					
					$arg1 = $row [1] ;
					
					$arg2=null;
					$tableau3[$index3][2] = null;
					if ($idRowDiffusion == $arg0)
					{
						$arg2 = "selected";
						$nomDiffusion = $arg1;
					}
					$tableau3[$index3] = array($arg0,$arg1,$arg2);
					
					$index3++;
					// $u représente l'utilisateur courant du jeu de résultats
					// La forme prise par $u pour représenter ce résultat est vue ci-dessous
				
				}
				
				
					
			?> 