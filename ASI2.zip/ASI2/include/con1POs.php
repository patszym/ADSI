<?php 
			
						if(!empty($_POST["idCampagne"]))
						{
							$idCampagne=$_POST["idCampagne"];
						} else
						{
							$idCampagne = null;
						}
						$libelleProcessus = null;
						$libelleCampagne = null;
						$nomAppli = null;
						$libelleSelProcessus = null;
						$libelleSelCampagne = null;
						$nomSelAppli = null;
						$index1 = 0;
			if (!(empty($idCampagne)))
			{

				include('include/connBase.php');
				// on crée la requête SQL
				
				$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
				$sql = 'SELECT idPROCESSUS, libellePROCESSUS, libelleCAMPAGNE , nomAPPLI
						FROM PROCESSUS, CAMPAGNE, APPLI
						WHERE CAMPAGNE_idCAMPAGNE = :idCampagne
						AND PROCESSUS.CAMPAGNE_idCAMPAGNE = CAMPAGNE.idCAMPAGNE
						AND APPLI.idAPPLI = CAMPAGNE.APPLI_idAPPLI
				ORDER BY nomAPPLI, libelleCAMPAGNE, libellePROCESSUS ';
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				$query->bindValue(':idCampagne', $idCampagne, PDO::PARAM_INT);
				$query->execute();
			
				$tableau1 = array();
			
				// Parcours des résultats
				$libelleSelProcessus = null;
				$libelleSelCampagne = null;
				$nomSelAppli = null;
				while ($row = $query->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
				{
					
					$arg0 = $row [0];
					
					$arg1 = $row [1] ;
					$arg3 = $row [2];
					$arg4 = $row[3];
					$libelleCampagne = $arg3;
					$nomAppli = $arg4;
					
					$arg2=null;
					$tableau1[$index1][2] = null;
				
					if ($idRowProcessus == $arg0)
					{
						$arg2 = "selected";
						$libelleSelProcessus = $arg1;
						$libelleSelCampagne = $arg3;
						$nomSelAppli = $arg4;
					
					}
					$tableau1[$index1] = array($arg0,$arg1,$arg2, $arg3, $arg4);
					
					$index1++;
					// $u représente l'utilisateur courant du jeu de résultats
					// La forme prise par $u pour représenter ce résultat est vue ci-dessous
				
				}
				if (!(empty($libelleSelProcessus)))
				{
					$libelleProcessus = $libelleSelProcessus;
				}
				if (!(empty($libelleSelCampagne)))
				{
					$libelleCampagne = $libelleSelCampagne;
				}
				if (!(empty($nomSelAppli)))
				{
					$nomAppli = $nomSelAppli;
				}
			}
				
					
			?> 