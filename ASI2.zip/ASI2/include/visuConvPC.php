<?php
try
	{   
		
		$query->execute();
		$maxRow = 0 ;
		$tableau = array();
		while ($row = $query->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
		{
			
			$arg0 = $row [0];
			$arg1 = $row [1];
			
			$arg2 = $row [2] ;
			$arg3 = $row [3] ;
			$arg4 = $row [4] ;
			$arg5 = $row [5] ;
			$arg6 = $row [6] ;
			$arg7 = $row [7] ;
			$arg8 = $row [8] ;
			$arg9 = $row [9] ;
			$arg10 = $row [10] ;
			$arg11 = $row [11] ;
			$arg12 = $row [12] ;
			$arg13 = $row [13] ;
			$arg14 = $row [14] ;
			
			$tableau[$maxRow] = array($arg0,$arg1,$arg2, $arg3, 
					$arg4, $arg5, $arg6, $arg7, $arg8, $arg9, $arg10, $arg11,
					$arg12, $arg13, $arg14
			);
			$maxRow++;
		}
	}
	
	
	
	
	catch (PDOException $e)
	{
		print $e->getMessage();
	}
	
?>