<?php
$taille_max = 650000;
?>