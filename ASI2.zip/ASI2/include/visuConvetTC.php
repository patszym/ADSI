<?php
try
	{   
		
		$query->execute();
		$maxRow = 0 ;
		$tableau = array();
		while ($row = $query->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
		{
			
			$arg0 = $row [0];
			$arg1 = $row [1];
			
			$arg2 = $row [2] ;
			$arg3 = $row [3] ;
			$arg4 = $row [4] ;
			$arg5 = $row [5] ;
			$arg6 = $row [6] ;
			$arg7 = $row [7] ;
			$arg8 = $row [8] ;
			$arg9 = $row [9] ;
			$arg10 = $row [10] ;
			$arg11 = $row [11] ;
			$arg12 = $row [12] ;
			$arg13 = $row [13] ;
		
			$arg14 = $row [14] ;
			$arg15 = $row [15] ;
			$arg16 = $row [16] ;
			$arg17 = $row [17] ;
			
			$arg18 = $row [18] ;
			$arg19 = $row [19];
			$arg20 = $row [20];
				
			$arg21 = $row [21] ;
			$arg22 = $row [22] ;
			$arg23 = $row [23] ;
			$arg24 = $row [24] ;
			$arg25 = $row [25] ;
			$arg26 = $row [26] ;
			$arg27 = $row [27] ;
			$arg28 = $row [28] ;
			$arg29 = $row [29] ;
			$arg30 = $row [30] ;
			
			
			$tableau[$maxRow] = array($arg0,$arg1,$arg2, $arg3, 
					$arg4, $arg5, $arg6, $arg7, $arg8, $arg9, $arg10, $arg11,
					$arg12, $arg13, $arg14, $arg15, $arg16, $arg17, $arg18,
					$arg19, $arg20, $arg21, $arg22, $arg23, $arg24, $arg25,
					$arg26, $arg27, $arg28, $arg29, $arg30
			);
			$maxRow++;
		}
	}
	
	
	
	
	catch (PDOException $e)
	{
		print $e->getMessage();
	}
	
?>