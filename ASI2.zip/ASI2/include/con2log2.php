<?php 
				/* initialisations : */

			include 'encrypt_decrypt.php';
				
				$validId = true;
			
				
				if(!empty($_POST["loginUti"]))
				{
					$loginUti = $_POST['loginUti'];
					
				}
				
				if(!empty($_POST["mdpUti"]))
				{
					$mdpUti=$_POST["mdpUti"];
						
				
				
					$plain_txt = $mdpUti;
				
					$encrypted_txt = encrypt_decrypt('encrypt', $plain_txt);
						
					$mdpChiffreUti = $encrypted_txt;
					
				
				} else
				{
					$mdpChiffreUti = null;
				}
				
				
				
			if ($validId == true) 
			{
				
					include('include/connBase.php');
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql="SELECT  idUTI, 
								nomUTI,
								prenomUTI,
								
								loginUTI,
								mdpUTI,
								datemodifUTI
								
								
							FROM UTI ";
					
				if ((!empty($_POST['loginUti'])) and (!empty($_POST['mdpUti'])))
					{
					
    				$sql = $sql . " WHERE "."loginUTI = :loginUti";
					$sql = $sql ." AND mdpUTI = :mdpChiffreUti";
					$sql = $sql." LIMIT 1";
					$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
					$sth->bindValue(':loginUti', $loginUti, PDO::PARAM_INT);
					$sth->bindValue(':mdpChiffreUti', $mdpChiffreUti, PDO::PARAM_INT);
					
					
				
					 
					try {
						$sth->execute();
							
					} catch (PDOException $e) {
						echo 'la recherche du login a échouée : ' . $e->getMessage();
							
					}
							while ($row = $sth->fetch())
							
							{ 
								
							if (!empty ($row['idUTI']))
								{
									$idUti=$row['idUTI'];
									$idloginUti=$idUti;
								}
								else
								{
									$idUti=null;
								}
								if (!empty ($row['nomUTI']))
								{
									$nomUti=$row['nomUTI'];
									
								}
								else 
								{
									$nomUti=null;
								}
								if (!empty ($row['prenomUTI']))
								{
									$prenomUti=$row['prenomUTI'];
								
								}
								else
								{
									$prenomUti=null;
								}
								if (!empty ($row['loginUTI']))
								{
									$loginUti=$row['loginUTI'];
								
								}
								else
								{
									$loginUti=null;
								}
								if (!empty ($row['mdpUTI']))
								{
									$mdpUti=$row['mdpUTI'];
								
								}
								else
								{
									$mdpUti=null;
								}
								if (!empty ($row['datemodifUTI']))
								{
									$datemodifUti=$row['datemodifUTI'];
								
								}
								else
								{
									$datemodifUti=null;
								}
								
								
							}
					}
					else 
					{
						$idUti=null;
						$nomUti=null;
						$prenomUti=null;
						$loginUti=null;
						$mdpUti=null;
						$datemodifUti=null;
						
					}
						
					
					
				}
				
					
			?> 