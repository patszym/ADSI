<?php
echo '<div id="navigation">';
echo '<ul>';

if (!(isset($loginUti)))
{
	$loginUti = null;
}
if (!(isset($mdpUti)))
{
	$mdpUti = 0;
}
if (!(isset($adm))) 
{
	$adm = false;
}
if ($adm == true)
{
	echo '<li><a href="../ASI1/index1.php">Accueil ADMINISTRATEUR</a></li>';
	
}
if ($idUti != null)
{
	echo '<li><a href="index2.php">Accueil ASI</a></li>';
}
echo '</ul>';
echo '	</div><!-- #navigation    -->';
?> 

		