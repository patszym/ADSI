<?php

class ConversionDates

{
    private $dateRow; // date en DateTime preparant la mise en base de données;
   
    // //  date conditionnée pour etre enregistree sur la base (Mysql)
    private $dt; // date formatée pour la sortie sur form, ou entrée par le clavier
    // avec des "/".
  	private $heure; // heure au format interne 00:00:00 (avec les mn et les s.)
  	private $Y ; // année
  	private $m ; // mois
  	private $d ; // jour
  	private $H ; // heure
  	private $i ; // minutes
  	private $s ; // secondes
  	
  	
  	 
	public function convDated ()
	{
		
		
		$tDatetime = explode(" ", $this->dateRow);
		
		
		$tDate = explode("-", $tDatetime [0]);
		
		$this->heure = $tDatetime [1];
		$heureMinutes = explode(":", $tDatetime [1]);
		$this->Y = $tDate[0];
		$this->m = $tDate[1];
		$this->d = $tDate[2];
		$this->H = $heureMinutes[0];
		$this->i = $heureMinutes[1];
		
		$this->dt = $this->d."/".$this->m."/".$this->Y ;
		
		
	}
    public function getdt()
	{
		return $this->dt;
	}
	public function getheure()
	{
		return $this->H;
	}
	public function getminut()
	{
		return $this->i;
	}
	 public function setDate($dateInput)
	{
		$this->dateRow = $dateInput;
		
	}
	
	public function getDate()
	{
		return $this->dateRow;
	}
	public function getY()
	{
		return $this->Y;
	}
	public function getm()
	{
		return $this->m;
	}
	public function getd()
	{
		return $this->d;
	}
	
	public function setdt($dt)
	{
		$this->dt = $dt;
	}
	public function convdDate ()
	{
		// la date entrée dans la form dt est examinée, elle 
		// contient les heures, minutes et secondes.
		// les champs H,i,s sont initialisées au préalable. 
		// avec l'initialisation par
		// des set des variables internes H,i,s
	
		$tDate = explode("/", $this->dt);
	
		$this->Y = $tDate[2];
		$this->m = $tDate[1];
		$this->d = $tDate[0];
	
		
		$this->dateRow = date($this->Y."-".$this->m."-".$this->d." ".$this->H.":".$this->i.":".$this->s) ;
	
	}
	public function setH($H_Input)
	{
		$this->H = $H_Input;
	}
	public function seti($i_Input)
	{
		$this->i = $i_Input;
	}
	public function sets($s_Input)
	{
		$this->s = $s_Input;
	}
	public function initHeure()
	{
		
		$this->H="00";
		$this->i="00";
		$this->s="00";
	}

}

?>