<?php
include_once('ConversionDates.class.php');

$dPrevOuvCampagnecycle = null;
$HPrevOuvCampagnecycle = null;
$iPrevOuvCampagnecycle = null;
if (!empty ($datePrevOuvCampagnecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevOuvCampagnecycle);
	$conversionDates->convDated();
	$dPrevOuvCampagnecycle = $conversionDates->getdt() ;
	$HPrevOuvCampagnecycle = $conversionDates->getheure() ;
	$iPrevOuvCampagnecycle = $conversionDates->getminut() ;
}
$dEffOuvCampagnecycle = null;
$HEffOuvCampagnecycle = null;
$iEffOuvCampagnecycle = null;
if (!empty ($dateEffOuvCampagnecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffOuvCampagnecycle);
	$conversionDates->convDated();
	$dEffOuvCampagnecycle = $conversionDates->getdt() ;
	$HEffOuvCampagnecycle = $conversionDates->getheure() ;
	$iEffOuvCampagnecycle = $conversionDates->getminut() ;
}
$dPrevFerCampagnecycle = null;
$HPrevFerCampagnecycle = null;
$iPrevFerCampagnecycle = null;
if (!empty ($datePrevFerCampagnecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevFerCampagnecycle);
	$conversionDates->convDated();
	$dPrevFerCampagnecycle = $conversionDates->getdt() ;
	$HPrevFerCampagnecycle = $conversionDates->getheure() ;
	$iPrevFerCampagnecycle = $conversionDates->getminut() ;
}
$dEffFerCampagnecycle = null;
$HEffFerCampagnecycle = null;
$iEffFerCampagnecycle = null;
if (!empty ($dateEffFerCampagnecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffFerCampagnecycle);
	$conversionDates->convDated();
	$dEffFerCampagnecycle = $conversionDates->getdt() ;
	$HEffFerCampagnecycle = $conversionDates->getheure() ;
	$iEffFerCampagnecycle = $conversionDates->getminut() ;
}
$dPrevFinCampagnecycle = null;
$HPrevFinCampagnecycle = null;
$iPrevFinCampagnecycle = null;
if (!empty ($datePrevFinCampagnecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevFinCampagnecycle);
	$conversionDates->convDated();
	$dPrevFinCampagnecycle = $conversionDates->getdt() ;
	$HPrevFinCampagnecycle = $conversionDates->getheure() ;
	$iPrevFinCampagnecycle = $conversionDates->getminut() ;
}
$dEffFinCampagnecycle = null;
$HEffFinCampagnecycle = null;
$iEffFinCampagnecycle = null;
if (!empty ($dateEffFinCampagnecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffFinCampagnecycle);
	$conversionDates->convDated();
	$dEffFinCampagnecycle = $conversionDates->getdt() ;
	$HEffFinCampagnecycle = $conversionDates->getheure() ;
	$iEffFinCampagnecycle = $conversionDates->getminut() ;
}


$dPrevOuvProcessuscycle = null;
$HPrevOuvProcessuscycle = null;
$iPrevOuvProcessuscycle = null;
if (!empty ($datePrevOuvProcessuscycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevOuvProcessuscycle);
	$conversionDates->convDated();
	$dPrevOuvProcessuscycle = $conversionDates->getdt() ;
	$HPrevOuvProcessuscycle = $conversionDates->getheure() ;
	$iPrevOuvProcessuscycle = $conversionDates->getminut() ;
}
$dEffOuvProcessuscycle = null;
$HEffOuvProcessuscycle = null;
$iEffOuvProcessuscycle = null;
if (!empty ($dateEffOuvProcessuscycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffOuvProcessuscycle);
	$conversionDates->convDated();
	$dEffOuvProcessuscycle = $conversionDates->getdt() ;
	$HEffOuvProcessuscycle = $conversionDates->getheure() ;
	$iEffOuvProcessuscycle = $conversionDates->getminut() ;
}
$dPrevFerProcessuscycle = null;
$HPrevFerProcessuscycle = null;
$iPrevFerProcessuscycle = null;
if (!empty ($datePrevFerProcessuscycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevFerProcessuscycle);
	$conversionDates->convDated();
	$dPrevFerProcessuscycle = $conversionDates->getdt() ;
	$HPrevFerProcessuscycle = $conversionDates->getheure() ;
	$iPrevFerProcessuscycle = $conversionDates->getminut() ;
}
$dEffFerProcessuscycle = null;
$HEffFerProcessuscycle = null;
$iEffFerProcessuscycle = null;
if (!empty ($dateEffFerProcessuscycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffFerProcessuscycle);
	$conversionDates->convDated();
	$dEffFerProcessuscycle = $conversionDates->getdt() ;
	$HEffFerProcessuscycle = $conversionDates->getheure() ;
	$iEffFerProcessuscycle = $conversionDates->getminut() ;
}
$dPrevFinProcessuscycle = null;
$HPrevFinProcessuscycle = null;
$iPrevFinProcessuscycle = null;
if (!empty ($datePrevFinProcessuscycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevFinProcessuscycle);
	$conversionDates->convDated();
	$dPrevFinProcessuscycle = $conversionDates->getdt() ;
	$HPrevFinProcessuscycle = $conversionDates->getheure() ;
	$iPrevFinProcessuscycle = $conversionDates->getminut() ;
}
$dEffFinProcessuscycle = null;
$HEffFinProcessuscycle = null;
$iEffFinProcessuscycle = null;
if (!empty ($dateEffFinProcessuscycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffFinProcessuscycle);
	$conversionDates->convDated();
	$dEffFinProcessuscycle = $conversionDates->getdt() ;
	$HEffFinProcessuscycle = $conversionDates->getheure() ;
	$iEffFinProcessuscycle = $conversionDates->getminut() ;
}


$dPrevOuvTachecycle = null;
$HPrevOuvTachecycle = null;
$iPrevOuvTachecycle = null;
if (!empty ($datePrevOuvTachecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevOuvTachecycle);
	$conversionDates->convDated();
	$dPrevOuvTachecycle = $conversionDates->getdt() ;
	$HPrevOuvTachecycle = $conversionDates->getheure() ;
	$iPrevOuvTachecycle = $conversionDates->getminut() ;
}
$dEffOuvTachecycle = null;
$HEffOuvTachecycle = null;
$iEffOuvTachecycle = null;
if (!empty ($dateEffOuvTachecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffOuvTachecycle);
	$conversionDates->convDated();
	$dEffOuvTachecycle = $conversionDates->getdt() ;
	$HEffOuvTachecycle = $conversionDates->getheure() ;
	$iEffOuvTachecycle = $conversionDates->getminut() ;
}
$dPrevFerTachecycle = null;
$HPrevFerTachecycle = null;
$iPrevFerTachecycle = null;
if (!empty ($datePrevFerTachecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevFerTachecycle);
	$conversionDates->convDated();
	$dPrevFerTachecycle = $conversionDates->getdt() ;
	$HPrevFerTachecycle = $conversionDates->getheure() ;
	$iPrevFerTachecycle = $conversionDates->getminut() ;
}
$dEffFerTachecycle = null;
$HEffFerTachecycle = null;
$iEffFerTachecycle = null;
if (!empty ($dateEffFerTachecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffFerTachecycle);
	$conversionDates->convDated();
	$dEffFerTachecycle = $conversionDates->getdt() ;
	$HEffFerTachecycle = $conversionDates->getheure() ;
	$iEffFerTachecycle = $conversionDates->getminut() ;
}
$dPrevFinTachecycle = null;
$HPrevFinTachecycle = null;
$iPrevFinTachecycle = null;
if (!empty ($datePrevFinTachecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevFinTachecycle);
	$conversionDates->convDated();
	$dPrevFinTachecycle = $conversionDates->getdt() ;
	$HPrevFinTachecycle = $conversionDates->getheure() ;
	$iPrevFinTachecycle = $conversionDates->getminut() ;
}
$dEffFinTachecycle = null;
$HEffFinTachecycle = null;
$iEffFinTachecycle = null;
if (!empty ($dateEffFinTachecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffFinTachecycle);
	$conversionDates->convDated();
	$dEffFinTachecycle = $conversionDates->getdt() ;
	$HEffFinTachecycle = $conversionDates->getheure() ;
	$iEffFinTachecycle = $conversionDates->getminut() ;
}





?>