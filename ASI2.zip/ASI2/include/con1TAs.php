<?php 
			
						if(!empty($_POST["idProcessus"]))
						{
							$idProcessus=$_POST["idProcessus"];
						} else
						{
							$idProcessus = null;
						}
						$libelleTache = null;
						$libelleProcessus = null;
						$libelleCampagne = null;
						$nomAppli = null;
						
						$libelleSelTache = null;
						$libelleSelProcessus = null;
						$libelleSelCampagne = null;
						$nomSelAppli = null;
						$index1 = 0;
		if (!(empty($idProcessus)))
		{

				include('include/connBase.php');
				// on crée la requête SQL
				
				$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
				$sql = 'SELECT idTACHE, libelleTACHE, 
						libellePROCESSUS , libelleCAMPAGNE, nomAPPLI
						FROM PROCESSUS, CAMPAGNE, TACHE, APPLI
						WHERE PROCESSUS_idPROCESSUS = :idProcessus
						AND TACHE.PROCESSUS_idPROCESSUS = PROCESSUS.idPROCESSUS
						AND CAMPAGNE.APPLI_idAPPLI = APPLI.idAPPLI
						AND PROCESSUS.CAMPAGNE_idCAMPAGNE = CAMPAGNE.idCAMPAGNE
				ORDER BY nomAPPLI, libellePROCESSUS, libellePROCESSUS ';
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				$query->bindValue(':idProcessus', $idProcessus, PDO::PARAM_INT);
				$query->execute();
			
				$tableau1 = array();
				
				// Parcours des résultats
				
				while ($row = $query->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
				{
					
					$arg0 = $row [0];
					
					$arg1 = $row [1] ;
					$arg3 = $row [3];
					$arg4 = $row [2];
					$arg5 = $row[4];
					$libelleCampagne = $arg3;
					$libelleProcessus = $arg4;
					$nomAppli = $arg5;
					
					$arg2=null;
					$tableau1[$index1][2] = null;
				
					if ($idRowTache == $arg0)
					{
						$arg2 = "selected";
						$libelleSelTache = $arg1;
						$libelleSelCampagne = $arg3;
						$libelleSelProcessus = $arg4;
						$nomSelAppli = $arg5;
					}
					$tableau1[$index1] = array($arg0,$arg1,$arg2, $arg3, $arg4, $arg5);
					
					$index1++;
					// $u représente l'utilisateur courant du jeu de résultats
					// La forme prise par $u pour représenter ce résultat est vue ci-dessous
				
				}
				if (!(empty($libelleSelTache)))
				{
					$libelleTache = $libelleSelTache;
				}
				if (!(empty($libelleSelProcessus)))
				{
					$libelleProcessus = $libelleSelProcessus;
				}
				if (!(empty($libelleSelCampagne)))
				{
					$libelleCampagne = $libelleSelCampagne;
				}
				if (!(empty($nomSelAppli)))
				{
					$nomAppli = $nomSelAppli;
				}
		}
				
				
				
					
			?> 