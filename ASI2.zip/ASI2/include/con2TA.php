<?php 

				/* initialisations : */
			
				
				$validId = true;
				
				if(!empty($_POST["idTache"]))
				{
					$idTache = $_POST['idTache'];
					/// $idTache = filter_var($idTache), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idTache))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idTache = $_POST['idTache'];
					
				} else {
					$idTache = null;
					
				}
				
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  PROCESSUS_idPROCESSUS, libelleCAMPAGNE,
							libellePROCESSUS, libelleTACHE, 
						descriptifTACHE, synchroEntreeTACHE,
							entreeTACHE, sortieTACHE,
							servTACHE, nomTraitTACHE,
							chemShellTACHE,
							nomAPPLI, idAPPLI
						
						FROM TACHE, PROCESSUS, CAMPAGNE, APPLI
    					WHERE CAMPAGNE.APPLI_idAPPLI = APPLI.idAPPLI
							AND PROCESSUS.CAMPAGNE_idCAMPAGNE = CAMPAGNE.idCAMPAGNE
							AND TACHE.PROCESSUS_idPROCESSUS = PROCESSUS.idPROCESSUS
							AND idTACHE  = :idTache 
							LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idTache, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idTache' => $idTache));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								if (!empty ($row['PROCESSUS_idPROCESSUS']))
								{
									$idRowProcessus=$row['PROCESSUS_idPROCESSUS'];
								}
								else
								{
									$idRowProcessus=null;
								}

								if (!empty ($row['libelleCAMPAGNE']))
								{
									$libelleCampagne=$row['libelleCAMPAGNE'];
								}
								else
								{
									$libelleCampagne=null;
								}
								
								if (!empty ($row['libelleTACHE']))
								{
									$libelleTache=$row['libelleTACHE'];
								}
								else
								{
									$libelleTache=null;
								}
							
								
								
								if (!empty ($row['descriptifTACHE']))
								{
									$descriptifTache=$row['descriptifTACHE'];
								}
								else
								{
									$descriptifTache=null;
								}
								if (!empty ($row['synchroEntreeTACHE']))
								{
									$synchroEntreeTache=$row['synchroEntreeTACHE'];
								}
								else
								{
									$synchroEntreeTache=null;
								}
								if (!empty ($row['entreeTACHE']))
								{
									$entreeTache=$row['entreeTACHE'];
								}
								else
								{
									$entreeTache=null;
								}
								if (!empty ($row['entreeTACHE']))
								{
									$entreeTache=$row['entreeTACHE'];
								}
								else
								{
									$entreeTache=null;
								}
								if (!empty ($row['sortieTACHE']))
								{
									$sortieTache=$row['sortieTACHE'];
								}
								else
								{
									$sortieTache=null;
								}
								if (!empty ($row['servTACHE']))
								{
									$servTache=$row['servTACHE'];
								}
								else
								{
									$servTache=null;
								}
								if (!empty ($row['nomTraitTACHE']))
								{
									$nomTraitTache=$row['nomTraitTACHE'];
								}
								else
								{
									$nomTraitTache=null;
								}
								if (!empty ($row['chemShellTACHE']))
								{
									$chemShellTache=$row['chemShellTACHE'];
								}
								else
								{
									$chemShellTache=null;
								}
								if (!empty ($row['nomAPPLI']))
								{
									$nomAppli=$row['nomAPPLI'];
								}
								else
								{
									$nomAppli=null;
								}
								if (!empty ($row['idAPPLI']))
								{
									$idAppli=$row['idAPPLI'];
								}
								else
								{
									$idAppli=null;
								}
								
								
							}
						
					
					
				}
				
					
			?> 