<?php 
include_once('include/ConversionDates.class.php');
				/* initialisations : */
			
				
				$validId = true;
				
				
				if(!empty($_POST["idTachecycle"]))
				{
					$idTachecycle = $_POST['idTachecycle'];
					/// $idTachecycle = filter_var($idTachecycle), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idTachecycle))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idTachecycle = $_POST['idTachecycle'];
					
				} else {
					$idTachecycle = null;
					
				}
				
				// Initialisation de la session :
				session_start();
				$ses_id = session_id();
				
			
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT CYCLE_idCYCLE, TACHE_idTACHE, nomAPPLI,
					 		libelleCAMPAGNE,
							libellePROCESSUS,
					 		libelleTACHE, 
						libelleLongCYCLE,
						datePrevOuvTACHECYCLE, 
						dateEffOuvTACHECYCLE, 
						datePrevFerTACHECYCLE, 
						dateEffFerTACHECYCLE, 
						datePrevFinTACHECYCLE, 
						dateEffFinTACHECYCLE,
						contenuCompRendTACHECYCLE, mimeCompRendTACHECYCLE,sizeCompRendTACHECYCLE,
							filenameCompRendTACHECYCLE,extensionCompRendTACHECYCLE 
						
						FROM TACHECYCLE, CAMPAGNE, PROCESSUS, TACHE, APPLI, CYCLE
    					WHERE idTACHECYCLE  = :idTachecycle 
						AND APPLI.idAPPLI = CAMPAGNE.APPLI_idAPPLI
					 	AND CAMPAGNE.idCAMPAGNE = PROCESSUS.CAMPAGNE_idCAMPAGNE
						AND PROCESSUS.idPROCESSUS = TACHE.PROCESSUS_idPROCESSUS
						AND TACHECYCLE.TACHE_idTACHE = TACHE.idTACHE
						AND TACHECYCLE.CYCLE_idCYCLE = CYCLE.idCYCLE
						LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idTachecycle, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idTachecycle' => $idTachecycle));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								if (!empty ($row['TACHE_idTACHE']))
								{
									$idRowTache=$row['TACHE_idTACHE'];
								}
								else
								{
									$idRowTache=null;
								}
								if (!empty ($row['CYCLE_idCYCLE']))
								{
									$idRowCycle=$row['CYCLE_idCYCLE'];
								}
								else
								{
									$idRowCycle=null;
								}
								if (!empty ($row['nomAPPLI']))
								{
									$nomAppli=$row['nomAPPLI'];
								}
								else 
								{
									$nomAppli=null;
								}
								if (!empty ($row['libelleCAMPAGNE']))
								{
									$libelleCampagne=$row['libelleCAMPAGNE'];
								}
								else
								{
									$libelleCampagne=null;
								}
								if (!empty ($row['libellePROCESSUS']))
								{
									$libelleProcessus=$row['libellePROCESSUS'];
								}
								else
								{
									$libelleProcessus=null;
								}
									
								if (!empty ($row['libelleTACHE']))
								{
									$libelleTache=$row['libelleTACHE'];
								}
								else
								{
									$libelleTache=null;
								}
							
								
								// date d'ouverture	
								if (!empty ($row['datePrevOuvTACHECYCLE']))
								{
								
									$datePrevOuvTachecycle=$row['datePrevOuvTACHECYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($datePrevOuvTachecycle);
									$conversionDates->convDated();
									$dPrevOuvTachecycle = $conversionDates->getdt() ;
									$HPrevOuvTachecycle = $conversionDates->getheure() ;
									$iPrevOuvTachecycle = $conversionDates->getminut() ;
								}
								else
								{
									$dPrevOuvTachecycle=null;
									$HPrevOuvTachecycle = null;
									$iPrevOuvTachecycle = null;
								}
								if (!empty ($row['dateEffOuvTACHECYCLE']))
								{
								
									$dateEffOuvTachecycle=$row['dateEffOuvTACHECYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateEffOuvTachecycle);
									$conversionDates->convDated();
									$dEffOuvTachecycle = $conversionDates->getdt() ;
									$HEffOuvTachecycle = $conversionDates->getheure() ;
									$iEffOuvTachecycle = $conversionDates->getminut() ;
								}
								else
								{
									$dEffOuvTachecycle=null;
									$HEffOuvTachecycle = null;
									$iEffOuvTachecycle = null;
								}			
								// date de fermeture
								if (!empty ($row['datePrevFerTACHECYCLE']))
								{
								
									$datePrevFerTachecycle=$row['datePrevFerTACHECYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($datePrevFerTachecycle);
									$conversionDates->convDated();
									$dPrevFerTachecycle = $conversionDates->getdt() ;
									$HPrevFerTachecycle = $conversionDates->getheure() ;
									$iPrevFerTachecycle = $conversionDates->getminut() ;
								}
								else
								{
									$dPrevFerTachecycle=null;
									$HPrevFerTachecycle = null;
									$iPrevFerTachecycle = null;
								}
								if (!empty ($row['dateEffFerTACHECYCLE']))
								{
								
									$dateEffFerTachecycle=$row['dateEffFerTACHECYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateEffFerTachecycle);
									$conversionDates->convDated();
									$dEffFerTachecycle = $conversionDates->getdt() ;
									$HEffFerTachecycle = $conversionDates->getheure() ;
									$iEffFerTachecycle = $conversionDates->getminut() ;
								}
								else
								{
									$dEffFerTachecycle=null;
									$HEffFerTachecycle = null;
									$iEffFerTachecycle = null;
								}
								// date de fin
								if (!empty ($row['datePrevFinTACHECYCLE']))
								{
								
									$datePrevFinTachecycle=$row['datePrevFinTACHECYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($datePrevFinTachecycle);
									$conversionDates->convDated();
									$dPrevFinTachecycle = $conversionDates->getdt() ;
									$HPrevFinTachecycle = $conversionDates->getheure() ;
									$iPrevFinTachecycle = $conversionDates->getminut() ;
								}
								else
								{
									$dPrevFinTachecycle=null;
									$HPrevFinTachecycle = null;
									$iPrevFinTachecycle = null;
								}
								if (!empty ($row['dateEffFinTACHECYCLE']))
								{
								
									$dateEffFinTachecycle=$row['dateEffFinTACHECYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateEffFinTachecycle);
									$conversionDates->convDated();
									$dEffFinTachecycle = $conversionDates->getdt() ;
									$HEffFinTachecycle = $conversionDates->getheure() ;
									$iEffFinTachecycle = $conversionDates->getminut() ;
								}
								else
								{
									$dEffFinTachecycle=null;
									$HEffFinTachecycle = null;
									$iEffFinTachecycle = null;
								}
								// Traitement de CompRend
								
								if (!empty ($row['contenuCompRendTACHECYCLE']))
								{
									$contenuCompRendTachecycle=$row['contenuCompRendTACHECYCLE'];
								}
								else
								{
									$contenuCompRendTachecycle=null;
								}
								if (!empty ($row['mimeCompRendTACHECYCLE']))
								{
									$mimeCompRendTachecycle=$row['mimeCompRendTACHECYCLE'];
								
								}
								else
								{
									$mimeCompRendTachecycle=null;
										
								
								}
								
								if (!empty ($row['sizeCompRendTACHECYCLE']))
								{
									$sizeCompRendTachecycle=$row['sizeCompRendTACHECYCLE'];
								}
								else
								{
									$sizeCompRendTachecycle=null;
								}
								if (!empty ($row['filenameCompRendTACHECYCLE']))
								{
									$filenameCompRendTachecycle=$row['filenameCompRendTACHECYCLE'];
								}
								else
								{
									$filenameCompRendTachecycle=null;
								}
								if (!empty ($row['extensionCompRendTACHECYCLE']))
								{
									$extensionCompRendTachecycle=$row['extensionCompRendTACHECYCLE'];
								}
								else
								{
									$extensionCompRendTachecycle=null;
								}
								
								
								if ($cons == 1)
								{
										
										
								
									$ficCompRendnom = "blobExtract/".$ses_id.$filenameCompRendTachecycle.".".$extensionCompRendTachecycle;
								
									$fp = fopen($ficCompRendnom, 'w');
										
									if (fwrite($fp,$contenuCompRendTachecycle)) {
										echo "Le fichier du compte rendu à été créé avec succès.";
									} else {
										// Erreur
										echo "Impossible de créer le fichier de compte rendu.";
									}
									fclose($fp);
								}
									
									
								
							}
						
					
					
				}
				
					
			?> 