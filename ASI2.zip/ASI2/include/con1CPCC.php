<?php 
			
						if(!empty($_POST["idAppli"]))
						{
							$idAppli=$_POST["idAppli"];
						} else
						{
							$idAppli = null;
						}

				include('include/connBase.php');
				// on crée la requête SQL
				
				$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
				$sql = 'SELECT idCAMPAGNE, libelleCAMPAGNE, nomAPPLI
						FROM CAMPAGNE, APPLI
						WHERE APPLI_idAPPLI = :idAppli
						AND APPLI_idAPPLI = idAPPLI
				ORDER BY nomAPPLI, libelleCAMPAGNE ';
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				$query->bindValue(':idAppli', $idAppli, PDO::PARAM_INT);
				$query->execute();
			
				$tableau1 = array();
				$index1 = 0;
				// Parcours des résultats
				
				while ($row = $query->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
				{
					
					$arg0 = $row [0];
					
					$arg1 = $row [1] ;
					$nomAppli = $row [2];
					
					$arg2=null;
					$tableau1[$index1][2] = null;
				
					if ($idRowCampagne == $arg0)
					{
						$arg2 = "selected";
						$libelleCampagne = $arg1;
					}
					$tableau1[$index1] = array($arg0,$arg1,$arg2);
					
					$index1++;
					// $u représente l'utilisateur courant du jeu de résultats
					// La forme prise par $u pour représenter ce résultat est vue ci-dessous
				
				}
				
				
					
			?> 