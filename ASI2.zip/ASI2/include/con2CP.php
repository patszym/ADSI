<?php 

				/* initialisations : */
			
				
				$validId = true;
				$nomAppli=null;
				$libelleCampagne=null;
				$descriptifCampagne = null;
				
				if(!empty($_POST["idCampagne"]))
				{
					$idCampagne = $_POST['idCampagne'];
					/// $idCampagne = filter_var($idCampagne), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idCampagne))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idCampagne = $_POST['idCampagne'];
					
				} else {
					$idCampagne = null;
					
				}
				
				// Initialisation de la session :
				
				session_start();
				$ses_id = session_id();
					
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  APPLI_idAPPLI, nomAPPLI, libelleCAMPAGNE, 
						descriptifCAMPAGNE
						
						FROM CAMPAGNE, APPLI
    					WHERE idCAMPAGNE  = :idCampagne
							AND CAMPAGNE.APPLI_idAPPLI = APPLI.idAPPLI
							LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idCampagne, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idCampagne' => $idCampagne));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								if (!empty ($row['APPLI_idAPPLI']))
								{
									$idRowAppli=$row['APPLI_idAPPLI'];
								}
								else
								{
									$idRowAppli=null;
								}
								
								if (!empty ($row['nomAPPLI']))
								{
									$nomAppli=$row['nomAPPLI'];
								}
								else
								{
									$nomAppli=null;
								}
								if (!empty ($row['libelleCAMPAGNE']))
								{
									$libelleCampagne=$row['libelleCAMPAGNE'];
								}
								else
								{
									$libelleCampagne=null;
								}
							
								
								
								if (!empty ($row['descriptifCAMPAGNE']))
								{
									$descriptifCampagne=$row['descriptifCAMPAGNE'];
								}
								else
								{
									$descriptifCampagne=null;
								}
							
								
								
								
							}
						
					
					
				}
				
					
			?> 