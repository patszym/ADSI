<?php 
include_once('include/ConversionDates.class.php');
				/* initialisations : */
			
				
				$validId = true;
				
				
				if(!empty($_POST["idCampagnecycle"]))
				{
					$idCampagnecycle = $_POST['idCampagnecycle'];
					/// $idCampagnecycle = filter_var($idCampagnecycle), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idCampagnecycle))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idCampagnecycle = $_POST['idCampagnecycle'];
					
				} else {
					$idCampagnecycle = null;
					
				}
				
				// Initialisation de la session :
			
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  CYCLE_idCYCLE, CAMPAGNE_idCAMPAGNE, nomAPPLI, libelleCAMPAGNE, 
						libelleLongCYCLE,
						datePrevOuvCAMPAGNECYCLE, 
						dateEffOuvCAMPAGNECYCLE, 
						datePrevFerCAMPAGNECYCLE, 
						dateEffFerCAMPAGNECYCLE, 
						datePrevFinCAMPAGNECYCLE, 
						dateEffFinCAMPAGNECYCLE 
						
						FROM CAMPAGNECYCLE, CAMPAGNE, APPLI, CYCLE
    					WHERE idCAMPAGNECYCLE  = :idCampagnecycle 
						AND APPLI.idAPPLI = CAMPAGNE.APPLI_idAPPLI
						AND CAMPAGNECYCLE.CAMPAGNE_idCAMPAGNE = CAMPAGNE.idCAMPAGNE
						AND CAMPAGNECYCLE.CYCLE_idCYCLE = CYCLE.idCYCLE
						LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idCampagnecycle, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idCampagnecycle' => $idCampagnecycle));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								if (!empty ($row['CAMPAGNE_idCAMPAGNE']))
								{
									$idRowCampagne=$row['CAMPAGNE_idCAMPAGNE'];
									
								}
								else
								{
									$idRowCampagne=null;
									
								}
								if (!empty ($row['CYCLE_idCYCLE']))
								{
									$idRowCycle=$row['CYCLE_idCYCLE'];
									
								}
								else
								{
									$idRowCycle=null;
									
								}
								if (!empty ($row['nomAPPLI']))
								{
									$nomAppli=$row['nomAPPLI'];
								}
								else 
								{
									$nomAppli=null;
								}
								if (!empty ($row['libelleCAMPAGNE']))
								{
									$libelleCampagne=$row['libelleCAMPAGNE'];
								}
								else
								{
									$libelleCampagne=null;
								}
							
								if (!empty ($row['libelleLongCYCLE']))
								{
									$libelleLongCycle=$row['libelleLongCYCLE'];
									
								}
								else
								{
									$libelleLongCycle=null;
									
								}
								// date d'ouverture	
								if (!empty ($row['datePrevOuvCAMPAGNECYCLE']))
								{
								
									$datePrevOuvCampagnecycle=$row['datePrevOuvCAMPAGNECYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($datePrevOuvCampagnecycle);
									$conversionDates->convDated();
									$dPrevOuvCampagnecycle = $conversionDates->getdt() ;
									$HPrevOuvCampagnecycle = $conversionDates->getheure() ;
									$iPrevOuvCampagnecycle = $conversionDates->getminut() ;
								}
								else
								{
									$dPrevOuvCampagnecycle=null;
									$HPrevOuvCampagnecycle = null;
									$iPrevOuvCampagnecycle = null;
								}
								if (!empty ($row['dateEffOuvCAMPAGNECYCLE']))
								{
								
									$dateEffOuvCampagnecycle=$row['dateEffOuvCAMPAGNECYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateEffOuvCampagnecycle);
									$conversionDates->convDated();
									$dEffOuvCampagnecycle = $conversionDates->getdt() ;
									$HEffOuvCampagnecycle = $conversionDates->getheure() ;
									$iEffOuvCampagnecycle = $conversionDates->getminut() ;
								}
								else
								{
									$dEffOuvCampagnecycle=null;
									$HEffOuvCampagnecycle = null;
									$iEffOuvCampagnecycle = null;
								}			
								// date de fermeture
								if (!empty ($row['datePrevFerCAMPAGNECYCLE']))
								{
								
									$datePrevFerCampagnecycle=$row['datePrevFerCAMPAGNECYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($datePrevFerCampagnecycle);
									$conversionDates->convDated();
									$dPrevFerCampagnecycle = $conversionDates->getdt() ;
									$HPrevFerCampagnecycle = $conversionDates->getheure() ;
									$iPrevFerCampagnecycle = $conversionDates->getminut() ;
								}
								else
								{
									$dPrevFerCampagnecycle=null;
									$HPrevFerCampagnecycle = null;
									$iPrevFerCampagnecycle = null;
								}
								if (!empty ($row['dateEffFerCAMPAGNECYCLE']))
								{
								
									$dateEffFerCampagnecycle=$row['dateEffFerCAMPAGNECYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateEffFerCampagnecycle);
									$conversionDates->convDated();
									$dEffFerCampagnecycle = $conversionDates->getdt() ;
									$HEffFerCampagnecycle = $conversionDates->getheure() ;
									$iEffFerCampagnecycle = $conversionDates->getminut() ;
								}
								else
								{
									$dEffFerCampagnecycle=null;
									$HEffFerCampagnecycle = null;
									$iEffFerCampagnecycle = null;
								}
								// date de fin
								if (!empty ($row['datePrevFinCAMPAGNECYCLE']))
								{
								
									$datePrevFinCampagnecycle=$row['datePrevFinCAMPAGNECYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($datePrevFinCampagnecycle);
									$conversionDates->convDated();
									$dPrevFinCampagnecycle = $conversionDates->getdt() ;
									$HPrevFinCampagnecycle = $conversionDates->getheure() ;
									$iPrevFinCampagnecycle = $conversionDates->getminut() ;
								}
								else
								{
									$dPrevFinCampagnecycle=null;
									$HPrevFinCampagnecycle = null;
									$iPrevFinCampagnecycle = null;
								}
								if (!empty ($row['dateEffFinCAMPAGNECYCLE']))
								{
								
									$dateEffFinCampagnecycle=$row['dateEffFinCAMPAGNECYCLE'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateEffFinCampagnecycle);
									$conversionDates->convDated();
									$dEffFinCampagnecycle = $conversionDates->getdt() ;
									$HEffFinCampagnecycle = $conversionDates->getheure() ;
									$iEffFinCampagnecycle = $conversionDates->getminut() ;
								}
								else
								{
									$dEffFinCampagnecycle=null;
									$HEffFinCampagnecycle = null;
									$iEffFinCampagnecycle = null;
								}
								
							}
						
					
					
				}
				
					
			?> 