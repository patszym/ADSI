<?php
include_once('ConversionDates.class.php');
$dPrevOuvTachecycle = null;
$HPrevOuvTachecycle = null;
$iPrevOuvTachecycle = null;
if (!empty ($datePrevOuvTachecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevOuvTachecycle);
	$conversionDates->convDated();
	$dPrevOuvTachecycle = $conversionDates->getdt() ;
	$HPrevOuvTachecycle = $conversionDates->getheure() ;
	$iPrevOuvTachecycle = $conversionDates->getminut() ;
}
$dEffOuvTachecycle = null;
$HEffOuvTachecycle = null;
$iEffOuvTachecycle = null;
if (!empty ($dateEffOuvTachecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffOuvTachecycle);
	$conversionDates->convDated();
	$dEffOuvTachecycle = $conversionDates->getdt() ;
	$HEffOuvTachecycle = $conversionDates->getheure() ;
	$iEffOuvTachecycle = $conversionDates->getminut() ;
}
$dPrevFerTachecycle = null;
$HPrevFerTachecycle = null;
$iPrevFerTachecycle = null;
if (!empty ($datePrevFerTachecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevFerTachecycle);
	$conversionDates->convDated();
	$dPrevFerTachecycle = $conversionDates->getdt() ;
	$HPrevFerTachecycle = $conversionDates->getheure() ;
	$iPrevFerTachecycle = $conversionDates->getminut() ;
}
$dEffFerTachecycle = null;
$HEffFerTachecycle = null;
$iEffFerTachecycle = null;
if (!empty ($dateEffFerTachecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffFerTachecycle);
	$conversionDates->convDated();
	$dEffFerTachecycle = $conversionDates->getdt() ;
	$HEffFerTachecycle = $conversionDates->getheure() ;
	$iEffFerTachecycle = $conversionDates->getminut() ;
}
$dPrevFinTachecycle = null;
$HPrevFinTachecycle = null;
$iPrevFinTachecycle = null;
if (!empty ($datePrevFinTachecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($datePrevFinTachecycle);
	$conversionDates->convDated();
	$dPrevFinTachecycle = $conversionDates->getdt() ;
	$HPrevFinTachecycle = $conversionDates->getheure() ;
	$iPrevFinTachecycle = $conversionDates->getminut() ;
}
$dEffFinTachecycle = null;
$HEffFinTachecycle = null;
$iEffFinTachecycle = null;
if (!empty ($dateEffFinTachecycle))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateEffFinTachecycle);
	$conversionDates->convDated();
	$dEffFinTachecycle = $conversionDates->getdt() ;
	$HEffFinTachecycle = $conversionDates->getheure() ;
	$iEffFinTachecycle = $conversionDates->getminut() ;
}
?>