<?php
include_once('ConversionDates.class.php');
$dRDVCalendrier = null;
$HRDVCalendrier = null;
$iRDVCalendrier = null;
if (!empty ($dateRDVCalendrier))
{
	$conversionDates = new ConversionDates();
	$conversionDates->setDate($dateRDVCalendrier);
	$conversionDates->convDated();
	$dRDVCalendrier = $conversionDates->getdt() ;
	$HRDVCalendrier = $conversionDates->getheure() ;
	$iRDVCalendrier = $conversionDates->getminut() ;
}

 
?>