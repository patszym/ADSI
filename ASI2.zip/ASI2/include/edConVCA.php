<?php
try
	{   
		$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
		$query->execute();
		$maxRow = 0 ;
		$tableauEd = array();
		while ($row = $query->fetch(PDO::FETCH_NUM, PDO::FETCH_ORI_NEXT))
		{
			
			$arg0 = $row [0];
			$arg1 = $row [1];
			$arg1utf8 = utf8_decode($arg1);
			$arg2 = $row [2] ;
			$arg2utf8 = utf8_decode($arg2);
			$arg3 = $row [3] ;
			$arg3utf8 = utf8_decode($arg3);
			$tableauEd[$maxRow] = array($arg0,$arg1utf8 ,$arg2utf8,$arg3utf8);
			$maxRow++;
		}
	}
	
	
	catch (PDOException $e)
	{
		print $e->getMessage();
	}
?>