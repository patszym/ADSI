<?php 
include_once('include/ConversionDates.class.php');
				/* initialisations : */
			
				
				$validId = true;
				$objetRDVCalendrier=null;
				$dateRDVCalendrier=null;
				$HRDVCalendrier = null;
				$iRDVCalendrier=null;
				$libelleCalendrier = null;
				
				$crdCalendrier=null;
				$mimecrdCalendrier=null;
				$sizecrdCalendrier=null;
				$filenamecrdCalendrier = null;
				$extensioncrdCalendrier = null;
				
				
				if(!empty($_POST["idCalendrier"]))
				{
					$idCalendrier = $_POST['idCalendrier'];
					/// $idCalendrier = filter_var($idCalendrier), FILTER_SANITIZE_NUMBER_INT);
					
					 if (is_numeric($idCalendrier))
					{
						$validId = true;
					} else {
						$validId = false;
						
						?>
						<script language="javascript">
						alert("la clé primaire ou identificateur est non conforme car ce n'est un entier");
						</script>
						<?php
					}
					$idCalendrier = $_POST['idCalendrier'];
					
				} else {
					$idCalendrier = null;
					
				}
				
				// Initialisation de la session :
				
				session_start();
				$ses_id = session_id();
			
				
				if ($validId == true) 
				{
					
						$authorise = true;
						include('include/connBase.php');
						$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
						$sql="SELECT  APPLI_idAPPLI, objetRDVCALENDRIER,
						dateRDVCALENDRIER, 
						libelleCALENDRIER, 
						
						crdCALENDRIER, mimecrdCALENDRIER,
						sizecrdCALENDRIER,filenamecrdCALENDRIER,
						extensioncrdCALENDRIER
						
						FROM CALENDRIER
    					WHERE idCALENDRIER  = :idCalendrier LIMIT 1";
						
						$sth = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
						$sth->bindParam(1, $idCalendrier, PDO::PARAM_INT);
						try {
						$sth->execute(array(':idCalendrier' => $idCalendrier));
						} catch (PDOException $e) {
							echo 'la recherche de la clé a échouée : ' . $e->getMessage();
							
						}	
							while ($row = $sth->fetch())
							
							{ 
								if (!empty ($row['APPLI_idAPPLI']))
								{
									$idRowAppli=$row['APPLI_idAPPLI'];
								}
								else
								{
									$idRowAppli=null;
								}
								if (!empty ($row['objetRDVCALENDRIER']))
								{
									$objetRDVCalendrier=$row['objetRDVCALENDRIER'];
								}
								else 
								{
									$objetRDVCalendrier=null;
								}
								if (!empty ($row['libelleCALENDRIER']))
								{
									$libelleCalendrier=$row['libelleCALENDRIER'];
								}
								else
								{
									$libelleCalendrier=null;
								}
							
							
								if (!empty ($row['dateRDVCALENDRIER']))
								{
								
									$dateRDVCalendrier=$row['dateRDVCALENDRIER'];
									$conversionDates = new ConversionDates();
									$conversionDates->setDate($dateRDVCalendrier);
									$conversionDates->convDated();
									$dRDVCalendrier = $conversionDates->getdt() ;
									$HRDVCalendrier = $conversionDates->getheure() ;
									$iRDVCalendrier = $conversionDates->getminut() ;
								}
								else
								{
									$dRDVCalendrier=null;
									$HRDVCalendrier = null;
									$iRDVCalendrier = null;
								}
											
								// Traitement de crd
								
								if (!empty ($row['crdCALENDRIER']))
								{
									$crdCalendrier=$row['crdCALENDRIER'];
								}
								else
								{
									$crdCalendrier=null;
								}
								if (!empty ($row['mimecrdCALENDRIER']))
								{
									$mimecrdCalendrier=$row['mimecrdCALENDRIER'];
										
								}
								else
								{
									$mimecrdCalendrier=null;
									
										
								}
								
								if (!empty ($row['sizecrdCALENDRIER']))
								{
									$sizecrdCalendrier=$row['sizecrdCALENDRIER'];
								}
								else
								{
									$sizecrdCalendrier=null;
								}
								if (!empty ($row['filenamecrdCALENDRIER']))
								{
									$filenamecrdCalendrier=$row['filenamecrdCALENDRIER'];
								}
								else
								{
								$filenamecrdCalendrier=null;
								}
								if (!empty ($row['extensioncrdCALENDRIER']))
								{
									$extensioncrdCalendrier=$row['extensioncrdCALENDRIER'];
								}
								else
								{
									$extensioncrdCalendrier=null;
								}
								
								
								if ($cons == 1)
								{
											
									
								
									$ficcrdnom = "blobExtract/".$ses_id.$filenamecrdCalendrier.".".$extensioncrdCalendrier;
								
									$fp = fopen($ficcrdnom, 'w');
									
									if (fwrite($fp,$crdCalendrier)) {
										echo "Le fichier de compte rendu à été créé avec succès.";
									} else {
										// Erreur
										echo "Impossible de créer le fichier de compte rendu.";
									}
									fclose($fp);
								}
									
									
								
							}
						
					
					
				}
				
					
			?> 