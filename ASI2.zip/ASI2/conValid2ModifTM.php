<?php	

if(!empty($_POST["soumet"]))
{

					$idTraitmaj = $_POST["idTraitmaj"];
					
					if(!empty($_POST["idRowAppli"]))
					{
						$idAppli=$_POST["idRowAppli"];
					} else
					{
						$idAppli = null;
					}
					
					if(!empty($_POST["nomTraitmaj"]))
					{
						$nomTraitmaj=$_POST["nomTraitmaj"];
					} else 
					{ 
						$nomTraitmaj = null;
					}
					
					
					if(!empty($_POST["libelleTraitmaj"]))
					{
						$libelleTraitmaj=$_POST["libelleTraitmaj"];
					} else
					{
						$libelleTraitmaj = null;
					}
					if(!empty($_POST["servTraitmaj"]))
					{
						$servTraitmaj=$_POST["servTraitmaj"];
					} else
					{
						$servTraitmaj = null;
					}
					if(!empty($_POST["chemTraitmaj"]))
					{
						$chemTraitmaj=$_POST["chemTraitmaj"];
					} else
					{
						$chemTraitmaj = null;
					}
					if(!empty($_POST["nomprogTraitmaj"]))
					{
						$nomprogTraitmaj=$_POST["nomprogTraitmaj"];
					} else
					{
						$nomprogTraitmaj = null;
					}
					if(!empty($_POST["locCompRendTraitmaj"]))
					{
						$locCompRendTraitmaj=$_POST["locCompRendTraitmaj"];
					} else
					{
						$locCompRendTraitmaj = null;
					}
					
					
					// initialisation des attibuts en modification de la table TRAITMAJ
					
					$crdTraitmaj = null;
					$mimecrdTraitmaj = null;
					$sizecrdTraitmaj = null;
					$filenamecrdTraitmaj = null;
					$extensioncrdTraitmaj = null;
					
					include('include/tailleMaxi.php');
					$content_blob = null;
					$mime_type = null;
					$fic_taille = 0;
					$content_nom = null;
					
					if(!empty($_FILES["crdFormTraitmaj"]))
					{
						if ($_FILES["crdFormTraitmaj"]["error"] > 0)
						{
							echo "Erreur Return Code: " . $_FILES["crdFormTraitmaj"]["error"] . "<br />";
						}
						else
						{
								
							if(!empty($_FILES['crdFormTraitmaj']['tmp_name']))
							{
					
								echo $_FILES['crdFormTraitmaj']['tmp_name'];
					
								$content_temp_nom = $_FILES['crdFormTraitmaj']['tmp_name'];
								$nom_fichier_origine = $_FILES['crdFormTraitmaj']['name'];
									
								$ret = is_uploaded_file ($_FILES['crdFormTraitmaj']['tmp_name']);
								if ( !$ret )
								{
									echo "Problème de transfert";
									return false;
								}
								else
								{
									$nom_fichier_origine = $_FILES['crdFormTraitmaj']['name'];
									// Le fichier a bien été reçu
									$fic_taille = $_FILES['crdFormTraitmaj']['size'];
									if ( $fic_taille > $taille_max )
									{
										echo "Fichier téléchargé trop important - taille maxi dépassée !";
										return false;
									}
										
									$mime_type = $_FILES['crdFormTraitmaj']['type'];
					
										
										
									$fp = fopen ($content_temp_nom, "rb");
										
									$content_blob = fread($fp, $fic_taille);
									fclose ($fp);
									$crdTraitmaj = addslashes($content_blob);
										
									$sizecrdTraitmaj = $fic_taille;
									$mimecrdTraitmaj = $mime_type;
										
									$path_parts = pathinfo($nom_fichier_origine);
										
									// echo $path_parts['dirname'], "\n";
									// echo $path_parts['basename'], "\n";
									$extensioncrdTraitmaj = $path_parts['extension'];
									$filenamecrdTraitmaj = $path_parts['filename']; // depuis PHP 5.2.0
										
										
										
										
								}
							}
					
						}
					}
								
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE TRAITMAJ SET '.
							' APPLI_idAPPLI ="'.$idAppli.'",'.
							' nomTRAITMAJ ="'.$nomTraitmaj.'",'.
							' libelleTRAITMAJ ="'.$libelleTraitmaj.'",'.
							' servTRAITMAJ ="'.$servTraitmaj.'",'.
							' chemTRAITMAJ ="'.$chemTraitmaj.'",'.
							' nomprogTRAITMAJ ="'.$nomprogTraitmaj.'",'.
							' locCompRendTRAITMAJ ="'.$locCompRendTraitmaj.'"';
					
					if(!empty($crdTraitmaj))
					{
					
						$sql = $sql .', crdTRAITMAJ ="'.$crdTraitmaj.'",';
						$sql = $sql .' mimecrdTRAITMAJ ="'.$mimecrdTraitmaj.'",';
						$sql = $sql .' sizecrdTRAITMAJ ='.$sizecrdTraitmaj.',';
						$sql = $sql .' filenamecrdTRAITMAJ ="'.$filenamecrdTraitmaj.'",';
						$sql = $sql .' extensioncrdTRAITMAJ ="'.$extensioncrdTraitmaj.'"';
									
					
					}
					
					
					
					$sql = $sql.' WHERE idTRAITMAJ = :idTraitmaj ';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idTraitmaj', $idTraitmaj, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	