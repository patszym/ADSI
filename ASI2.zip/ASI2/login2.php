<!DOCTYPE html PUBLIC "-//W3C//Dtd XHTML 1.0 Strict//EN"
	"http://www.w3.org/tr/xhtml1/Dtd/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Login - 2
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />


</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
		<a href="logout.php">Deconnexion</a>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">
		<?php include('include/con2log2.php'); ?> 
		
		<?php include('include/ADMnavigation.php'); ?> 
	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> Choisissez l'option ou l'une des options sur le menu à gauche <p>
		</div><!-- #secondaire -->

		<div id="principal"> 
			<?php echo '<h5> Bonjour '.$prenomUti.'</h5>'; 
			 
				session_start();
 
				echo ' Bienvenue !';
 
				$_SESSION['idloginUti'] = $idUti;
			
				$_SESSION['time']	 = time();
				
				$_SESSION['admuti']	 = 'uti' ;
				
				
				$_SESSION['ses_id']=session_id();
				
 
			?>
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	
</div><!-- #global -->

</body>
</html>
