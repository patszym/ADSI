<?php
require_once('../include/fpdf181/fpdf.php');

class PDF extends FPDF
{
function Header()
{
    global $titre;

    // Arial gras 15
    $this->SetFont('Arial','B',15);
    // Calcul de la largeur du titre et positionnement
    $w = $this->GetStringWidth($titre)+6;
    $this->SetX((210-$w)/2);
    // Couleurs du cadre, du fond et du texte
    $this->SetDrawColor(0,80,180);
    $this->SetFillColor(255,255,255);
    $this->SetTextColor(50,0,0);
    // Epaisseur du cadre (1 mm)
    $this->SetLineWidth(1);
    // Titre
    $this->Cell($w,9,$titre,1,1,'C',true);
    // Saut de ligne
    $this->Ln(10);
}

function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Arial italique 8
    $this->SetFont('Arial','I',8);
    // Couleur du texte en gris
    $this->SetTextColor(128);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
}

function TitreChapitre($num, $libelle)
{
    // Arial 12
    $this->SetFont('Arial','',12);
    // Couleur de fond
    $this->SetFillColor(200,220,255);
    // Titre
    $this->Cell(0,6,$libelle,0,1,'L',true);
    // Saut de ligne
    $this->Ln(4);
}

function CorpsChapitre()
{
    // Lecture du contenuFiche texte
    
  
    // $txt = "Identificateur : ".$_POST['idTache'];
    // Times 12
    // $this->SetFont('Times','',12);
    // Sortie du texte justifié
    // $this->MultiCell(0,5,$txt);
    // Saut de ligne
	// $this->Ln();
	
	$txt = "Nom de l'application : ";
	$arg = $_POST['nomAppli'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Libellé de la campagne : ";
	$arg = $_POST['libelleCampagne'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Libelle de la phase : ";
	$arg= $_POST['libelleProcessus'];
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Libelle de la tache : ";
	$arg= $_POST['libelleTache'];
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	
	$txt = "Descriptif de la tache : ";
	$arg= $_POST['descriptifTache'];
	
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);

	$arg1utf8=substr($argutf8, 0, 62);
	$arg2utf8=substr($argutf8, 62, 62);
	$arg3utf8=substr($argutf8, 124, 62);
	$arg4utf8=substr($argutf8, 186, 62);
	$arg5utf8=substr($argutf8, 248, 62);
	$arg6utf8=substr($argutf8, 310, 62);
	$arg7utf8=substr($argutf8, 372, 62);
	$arg8utf8=substr($argutf8, 434, 62);
	$arg9utf8=substr($argutf8, 496, 62);
	
	
	
	$this->Cell(110,10,$arg1utf8,1,1,'LR');
	
	$txtutf8 = null;
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg2utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg3utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg4utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg5utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg6utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg7utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg8utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg9utf8,1,1,'LR');
	
	
	$txt = "Synchronisation à l'entrée : ";
	$arg= $_POST['synchroEntreeTache'];
	
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	
	$arg1utf8=substr($argutf8, 0, 62);
	$arg2utf8=substr($argutf8, 62, 62);
	$arg3utf8=substr($argutf8, 124, 62);
	$arg4utf8=substr($argutf8, 186, 62);
	$arg5utf8=substr($argutf8, 248, 62);
	$arg6utf8=substr($argutf8, 310, 62);
	$arg7utf8=substr($argutf8, 372, 62);
	$arg8utf8=substr($argutf8, 434, 62);
	$arg9utf8=substr($argutf8, 496, 62);
	
	
	
	$this->Cell(110,10,$arg1utf8,1,1,'LR');
	
	$txtutf8 = null;
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg2utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg3utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg4utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg5utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg6utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg7utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg8utf8,1,1,'LR');
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg9utf8,1,1,'LR');
	
	$txt = "Entrée : ";
	$arg= $_POST['entreeTache'];
	
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	
	$arg1utf8=substr($argutf8, 0, 62);
	$arg2utf8=substr($argutf8, 62, 62);
	
	
	$this->Cell(110,10,$arg1utf8,1,1,'LR');
	
	$txtutf8 = null;
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg2utf8,1,1,'LR');
	
	$txt = "Sortie : ";
	$arg= $_POST['sortieTache'];
	
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	
	$arg1utf8=substr($argutf8, 0, 62);
	$arg2utf8=substr($argutf8, 62, 62);
	
	
	$this->Cell(110,10,$arg1utf8,1,1,'LR');
	
	$txtutf8 = null;
	$this->Cell(80,10,$txtutf8,1);
	$this->Cell(110,10,$arg2utf8,1,1,'LR');
	

	$txt = "Serveur : ";
	$arg = $_POST['servTache'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Nom du traitement : ";
	$arg = $_POST['nomTraitTache'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
	$txt = "Chemin vers le shell : ";
	$arg = $_POST['chemShellTache'];
	$arg=substr($arg, 0, 62);
	$txtutf8 = utf8_decode($txt);
	$this->SetFont('Times','',12);
	$this->Cell(80,10,$txtutf8,1);
	$argutf8 = utf8_decode($arg);
	$this->Cell(110,10,$argutf8,1,1,'LR');
	
    // Saut de ligne
    $this->Ln();
    
   
    // Mention en italique
    $this->SetFont('','I');
    $this->Cell(0,5,"(fin de la Fiche)");
}

function AjouterChapitre($num, $titre)
{
    $this->AddPage();
    $this->TitreChapitre($num,$titre);
    $this->CorpsChapitre();
}
}

$pdf = new PDF();
$titre = "Fiche d'une tache";
$pdf->SetTitle($titre);
$idTache = $_POST["idTache"];

$pdf->AjouterChapitre(1,'Contenu de la fiche');


$pdf->Output();
?>