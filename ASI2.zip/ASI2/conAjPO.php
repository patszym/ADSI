<?php	

				
					$idProcessus = null;
					
					if(!empty($_POST["idCampagne"]))
					{
						$idCampagne=$_POST["idCampagne"];
					} else
					{
						$idCampagne = null;
					}
					
					
					if(!empty($_POST["libelleProcessus"]))						
					{
						$libelleProcessus=$_POST["libelleProcessus"];
					} else
					{
						$libelleProcessus = null;
					}
				
					if(!empty($_POST["descriptifProcessus"]))
					{
						$descriptifProcessus=$_POST["descriptifProcessus"];
					} else
					{
						$descriptifProcessus = null;
					}
					
					
				
					
					
						
		/* Mise à jour :
		 * 
		 */
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idPROCESSUS) FROM PROCESSUS ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idProcessus = $gid->fetchColumn();
					
					
					
					$idProcessus ++ ;
					
					
					$sql = 'insert into PROCESSUS values ("'.$idProcessus.'",'.
							'"'.$idCampagne.'","'.
							
							$libelleProcessus.'","'.
							$descriptifProcessus.'"';
							
							
							
							
					$sql = $sql .');'   ;
					// echo $sql;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
			?>	