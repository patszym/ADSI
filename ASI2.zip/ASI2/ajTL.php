<!DOCTYPE html PUBLIC "-//W3C//DTD XHTLL 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Traitements local
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css">
	<style type="text/css">    
		div.ui-datepicker{
		font-size: 12px;
	}
	</style>
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
	<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
	<script src="jquery.ui.datepicker-fr.js"></script>
	<script>
		$(function() {
		$("#calendrier1").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		
	</script>
	
</head>		

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation2.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> Il faut valider l'ajout pour achever la tâche (bouton <b> valider </b>)</p>
			
			<p>Cliquez sur l'onglet <b>Liste et Edition </b> pour une consultation, 
			une modification, ou une suppression </p>
			<p> Cliquez sur l'onglet <b> Ajout </b> pour créer une occurence de Traitlocal</p>
			
	</div><!-- #secondaire -->

	<div id="principal"> 
			<h5>Gestion des traitements locaux</h5>
			
			
			<div id="tabsF">
				<?php include('include/MHTL.php'); ?>
				<?php $idRowAppli = null ;
				session_start();
				$ses_id = session_id();
				
				?>
				<?php include('include/con1APs.php'); ?> 
			<fieldset class="saisie">
			
			<form name="ajTL" id="ajTLForm" method="post"
				 enctype="multipart/form-data" 
					action="ajTL2.php">
					<input type="hidden" name="ses_id"
						value="<?php echo htmlspecialchars($ses_id); ?>"
					></input>	
				<table BORDER=0>	
					<!-- ajout Traitlocal - formulaire -->
					<tr>
						<td>Application :</td>
						<td>
						 <select   name="idAppli">
							<?php
							
							$i = 0;
							while ($i<$index1)
							{
					
								 	echo '<option value="'.
										$tableau1 [$i][0].'"'.$tableau1 [$i][2].'>'.
										$tableau1 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
					
					
					<tr>
						<td> Nom du traitement local :</td>
						<td>
							<INPUT type="text"  
							name="nomTraitlocal" value="" maxlength="20" size="20">
							</input>
						</td>
					</tr>
					
				
					<tr>
						<td> Libellé du traitement local : </td>
						<td>
							<INPUT type="text" 
							name="libelleTraitlocal" value="" maxlength="80" size="50">
							</input>
						</td>
					</tr>
					<tr>
						<td> Serveur où trouver le traitement : </td>
						<td>
							<INPUT type="text" 
							name="servTraitlocal" value="" maxlength="20" size="20">
							</input>
						</td>
					</tr>
					<tr>
						<td> Chemin dans ce serveur : </td>
						<td>
							<INPUT type="text" 
							name="chemTraitlocal" value="" maxlength="100" size="50">
							</input>
						</td>
					</tr>
					<tr>
						<td> Nom du programme : </td>
						<td>
							<INPUT type="text" 
							name="nomprogTraitlocal" value="" maxlength="30" size="30">
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Eventuellement, PhraseSQL :</td>
						<td>
							<textarea name = "phraseSQLTraitlocal" rows="20" cols="50" >
							</textarea>
						</td>
					</tr>
					<tr>
						<td> Date de la demande : </td>
						<td>
							<INPUT type="text" id="calendrier1" 
							name="datedemandeTraitlocal" value="" maxlength="10" size="10">
							</input>
						</td>
					</tr>
					
					<tr>
						<td>
						
					<input type="submit" value="Valider" name="soumet">
					</input>
						</td>
						<td>
					
					<input type="submit" value="Annuler">
					</input>
						</td>
					</tr>
				</table>			
					
					
					
			</form>
			
		</fieldset>
		</div>
	</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	

</div><!-- #global -->

</body>
</html>
