<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		projets
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation2.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p>Cliquez sur l'onglet <b>Liste et Edition </b> pour une autre consultation, 
			une modification, ou une suppression </p>
			<p> Cliquez sur l'onglet <b> Ajout </b> pour créer une occurence de Projet</p>
			
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5>Gestion des Projets </h5>
			
			
			
				<?php $cons=1;?>
				<?php include('include/con2PR.php'); ?> 
			<fieldset class="saisie">	
			
					
			<form name="consProjet" id="consProjetForm" method="post"
				 enctype="multipart/form-data" 
					action="consPR2.php">
				<table border=0>	
				
					
							<input type="hidden" name="ses_id"
							value="<?php echo htmlspecialchars($ses_id); ?>"
							maxlength="3" size="3"  ></input>
						
								
				
					<tr>
						<td> Nom du projet :</td>
						<td>
							<input type="text" name="nomProjet" 
							value="<?php echo htmlspecialchars($nomProjet); ?>"
							 maxlength="20" size="20" readonly></input>
						</td>
					</tr>
						<tr>
						<td> Libelle du projet :</td>
						<td>
							<input type="text" name="libelleProjet" 
							value="<?php echo htmlspecialchars($libelleProjet); ?>"
							 maxlength="100" size="60" readonly></input>
						</td>
					</tr>				
					<tr>
						<td> Contexte du projet :</td>
						<td>
							<textarea readonly name = "contexteProjet" rows="11" cols="50" readonly>
							<?php echo htmlspecialchars($contexteProjet); ?>
							</textarea>
						</td>
					</tr>
					<tr>
						
						<td>
							<?php if ($indLocalProjet==1): ?>
						
							<input type="checkbox" name="choixLocal" value="1" disabled="disabled">
							Indicateur Projet local
							</input>
							<?php else: ?>
						
							<input type="checkbox" name="choixLocal" value="2" checked disabled="disabled">
							Indicateur Projet local
							</input>
						<?php endif ?>
						</td>
					</tr>
					<tr>
						
						<td>
							<?php if ($indNationalProjet==1): ?>
						
							<input type="checkbox" name="choixNational" value="1" disabled="disabled">
							Indicateur Projet National
							</input>
							<?php else: ?>
						
							<input type="checkbox" name="choixNational" value="2" checked disabled="disabled">
							Indicateur Projet National
							</input>
						<?php endif ?>
						</td>
					</tr>
					<tr>
						
						<td>
							<?php if ($indInterAcaProjet==1): ?>
						
							<input type="checkbox" name="choixInterAca" value="1" disabled="disabled">
							Indicateur Projet Inter-Académique
							</input>
							<?php else: ?>
						
							<input type="checkbox" name="choixInterAca" value="2" checked disabled="disabled">
							Indicateur Projet Inter-Académique
							</input>
						<?php endif ?>
						</td>
					</tr>
					<tr>
						<td> Date de la demande : </td>
						<td>
							<INPUT type=text id="calendrier1" 
							name="dateDemandeProjet" 
							value="<?php echo htmlspecialchars($dDemandeProjet); ?>" 
							maxlength="10" size="10" readonly>
							</input>
						</td>
					</tr>
					
					<tr>
						<td> Date de Fin :</td>
						<td>
							<INPUT type=text id="calendrier2" 
							name="dateFinProjet" 
							value="<?php echo htmlspecialchars($dFinProjet); ?>" 
							maxlength="10" size="10" readonly>
							</input>
						</td>
					</tr>
					<tr>
					
						<td> Demande :</td>
						<td>
						<?php  
							$dem = '<object data="'.$ficdemnom.'" type="'.$mimedemProjet.
								 '" width="400" height="400">'.
								'</object>';
							echo $dem;
							
						?>
					</tr>
					<tr>
						
						<td> Cahier de charges du projet :</td>
						<td>
						<?php  
							$cdc = '<object data="'.$ficcdcnom.'" type="'.$mimecdcProjet.
								 '" width="400" height="400">'.
								'</object>';
							echo $cdc;
							
						?>
						</td>
					</tr>
					<tr>
						
						<td> Documentation du projet :</td>
						<td>
						<?php  
							$doc = '<object data="'.$ficdocnom.'" type="'.$mimedocProjet.
								 '" width="400" height="400">'.
								'</object>';
							echo $doc;
							
						?>
						</td>
					</tr>
					
					<table width="100%" border ="1" cellspacing="1" 
					cellpadding="1"><tr><td>
						<div align=center>
					Des fichiers ont été générés<br></br>
					dans le répertoire du serveur<br></br>
					nommé blobExtract
						</div>
					</td><tr></table>
					<tr>
						<br></br>
						<td>		
					<input type="submit" name = "soumet"
					value="Nettoyage de tous les fichiers" name="soumet">				
					</input>
						</td>
					
						<td>			
					<input type="submit" name = "soumet2"
					value="Nettoyage de vos fichiers générés" name="soumet">
					</input>			
					
					
						</td>
					</tr>
				</table>	
			</form>
			
			</fieldset>	
			
			
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	
</div><!-- #global -->

</body>
</html>
