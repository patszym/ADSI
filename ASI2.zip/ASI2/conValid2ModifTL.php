<?php	
include_once('include/ConversionDates.class.php');
if(!empty($_POST["soumet"]))
{

					$idTraitlocal = $_POST["idTraitlocal"];
					
					if(!empty($_POST["idRowAppli"]))
					{
						$idAppli=$_POST["idRowAppli"];
					} else
					{
						$idAppli = null;
					}
					
					if(!empty($_POST["nomTraitlocal"]))
					{
						$nomTraitlocal=$_POST["nomTraitlocal"];
					} else 
					{ 
						$nomTraitlocal = null;
					}
					
					
					if(!empty($_POST["libelleTraitlocal"]))
					{
						$libelleTraitlocal=$_POST["libelleTraitlocal"];
					} else
					{
						$libelleTraitlocal = null;
					}
					if(!empty($_POST["servTraitlocal"]))
					{
						$servTraitlocal=$_POST["servTraitlocal"];
					} else
					{
						$servTraitlocal = null;
					}
					if(!empty($_POST["chemTraitlocal"]))
					{
						$chemTraitlocal=$_POST["chemTraitlocal"];
					} else
					{
						$chemTraitlocal = null;
					}
					if(!empty($_POST["nomprogTraitlocal"]))
					{
						$nomprogTraitlocal=$_POST["nomprogTraitlocal"];
					} else
					{
						$nomprogTraitlocal = null;
					}
					if(!empty($_POST["phraseSQLTraitlocal"]))
					{
						$phraseSQLTraitlocal=$_POST["phraseSQLTraitlocal"];
					} else
					{
						$phraseSQLTraitlocal = null;
					}

					$dateversRowdemandeTraitlocal  = null;
					$validdatedemandeTraitlocal = true;
					
					if(!empty($_POST["datedemandeTraitlocal"]))
					{
							
							
						$conversionDate1 = new ConversionDates();
						$conversionDate1->setdt($_POST['datedemandeTraitlocal']);
						
						$conversionDate1->convdDate();
						$dateversRowdemandeTraitlocal = $conversionDate1->getdate() ;
						if (!checkdate($conversionDate1->getm(), $conversionDate1->getd(), $conversionDate1->getY()))
						{
								
							$validdatedemandeTraitlocal = false;
							echo $datedemandeTraitlocal. " n'est pas une date valide <br>";
							?>
													<script language="javascript">
													alert("Date de rendez vous du projet non conforme au format d'une date");
													</script>
													<?php
											}
										} 
										else
										{
											$dateversRowdemandeTraitlocal  = null;
										}
					
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE TRAITLOCAL SET '.
							' APPLI_idAPPLI ="'.$idAppli.'",'.
							' nomTRAITLOCAL ="'.$nomTraitlocal.'",'.
							' libelleTRAITLOCAL ="'.$libelleTraitlocal.'",'.
							' servTRAITLOCAL ="'.$servTraitlocal.'",'.
							' chemTRAITLOCAL ="'.$chemTraitlocal.'",'.
							' nomprogTRAITLOCAL ="'.$nomprogTraitlocal.'",'.
							' phraseSQLTRAITLOCAL ="'.$phraseSQLTraitlocal.'"';
					
					if(!empty($_POST["datedemandeTraitlocal"]))
					{
						$sql = $sql.', datedemandeTRAITLOCAL ="'.$dateversRowdemandeTraitlocal.'"';
					}
					
					
					$sql = $sql.' WHERE idTRAITLOCAL = :idTraitlocal ';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idTraitlocal', $idTraitlocal, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	