<!DOCTYPE html PUBLIC "-//W3C//DTD XHPOL 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		processus ou phases
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation2.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			
			<p>	Cliquez sur l'onglet <b>Liste et Edition </b>pour une consultation, une modification, 
			ou une autre suppression </p>
			<p>	Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence de phase</p>
		
			<p> Vérifiez le message de modification dans la base de données "... faite"</p>
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5>Gestion des processus</h5>
			
			
			<div id="tabsF">
				<?php include('include/MHPO.php'); ?> 
			<!-- modification - formulaire2 -->
			<br></br>
			<h2>Validation de la modification de la phase </h2>		
			
			<?php include('conValid2modifPO.php'); ?> 	
					
			
				
			</div>
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	

</div><!-- #global -->

</body>
</html>
