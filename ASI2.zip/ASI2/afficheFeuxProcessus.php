<?php

// Ouverture processus Cycle :
						
							if ($datePrevOuvProcessuscycle != null)
							{
							$dt = new DateTime($datePrevOuvProcessuscycle, new DateTimeZone('Europe/Paris'));
						
							$dtsPrevOuv =($dt->getTimestamp());
							}
							else 
							{
								$dtsPrevOuv = null;
							}
							
							if ($dateEffOuvProcessuscycle != null)
							{
								$dt = new DateTime($dateEffOuvProcessuscycle, new DateTimeZone('Europe/Paris'));
							
								$dtsEffOuv =($dt->getTimestamp());
							}
							else
							{
								$dtsEffOuv = null;
							}
							
							$differenceOuv = $todayTimeStamp - $dtsPrevOuv ;
							
							if ((($differenceOuv > 0)and ($dtsPrevOuv != null))  and ($dtsEffOuv == null)) 
								
							{
            					echo "<br></br>".$nomAppli." Processus ".$libelleCourtCycle.": date prévisionnelle d'ouverture ".$datePrevOuvProcessuscycle." inférieure à aujourd'hui";
            					echo "  et date effective d'ouverture nulle ";
						
            				
            				$feu_Rouge = 
            				'<td>
							<a href="edPC.php">
							<img src="images/feuRouge.jpg" height="20" width="20" align = "center" 
							>
							
							</a>
				
							</td>';
            				
							echo $feu_Rouge;
						
							}
							
			// Fermeture processus Cycle :
							
							if ($datePrevFerProcessuscycle != null)
							{
								$dt = new DateTime($datePrevFerProcessuscycle, new DateTimeZone('Europe/Paris'));
							
								$dtsPrevFer =($dt->getTimestamp());
							}
							else
							{
								$dtsPrevFer = null;
							}
								
							if ($dateEffFerProcessuscycle != null)
							{
								$dt = new DateTime($dateEffFerProcessuscycle, new DateTimeZone('Europe/Paris'));
									
								$dtsEffFer =($dt->getTimestamp());
							}
							else
							{
								$dtsEffFer = null;
							}
								
							$differenceFer = $todayTimeStamp - $dtsPrevFer ;
								
							if ((($differenceFer > 0)and ($dtsPrevFer != null)) and ($dtsEffFer == null))
							
							{
								echo "<br></br>".$nomAppli." Processus ".$libelleCourtCycle.": date prévisionnelle de fermeture ".$datePrevFerProcessuscycle." inférieure à aujourd'hui";
								echo "  et date effective de fermeture nulle ";
							
							
								$feu_Rouge =
								'<td>
							<a href="edPC.php">
							<img src="images/feuRouge.jpg" height="20" width="20" align = "center"
							>
				
							</a>
							
							</td>';
							
								echo $feu_Rouge;
							
							}
							
			// Fin processus Cycle :
								
							if ($datePrevFinProcessuscycle != null)
							{
								$dt = new DateTime($datePrevFinProcessuscycle, new DateTimeZone('Europe/Paris'));
									
								$dtsPrevFin =($dt->getTimestamp());
							}
							else
							{
								$dtsPrevFin = null;
							}
							
							if ($dateEffFinProcessuscycle != null)
							{
								$dt = new DateTime($dateEffFinProcessuscycle, new DateTimeZone('Europe/Paris'));
									
								$dtsEffFin =($dt->getTimestamp());
							}
							else
							{
								$dtsEffFin = null;
							}
							
							$differenceFin = $todayTimeStamp - $dtsPrevFin ;
							
							if ((($differenceFin > 0)and ($dtsPrevFin != null)) and ($dtsEffFin == null))
								
							{
								echo "<br></br>".$nomAppli." Processus ".$libelleCourtCycle.": date prévisionnelle de fin ".$datePrevFinProcessuscycle." inférieure à aujourd'hui";
								echo "  et date effective de fin nulle ";
									
									
								$feu_Rouge =
								'<td>
							<a href="edPC.php">
							<img src="images/feuRouge.jpg" height="20" width="20" align = "center"
							>
							
							</a>
				
							</td>';
									
								echo $feu_Rouge;
									
							}
							$differenceEffFin = $todayTimeStamp - $dtsEffFin ;
							
							if (($differenceEffFin > 0)and ($dtsEffFin != null))
								
							{
							
								$panneau_stop =
								'<td>
				
							<img src="images/arreter.png" height="20" width="20" align = "center"
							>
							
				
				
							</td>';
									
								echo $panneau_stop;
									
							}
							$differencePrevFin = $todayTimeStamp - $dtsPrevFin ;
							$differenceEffOuv = $todayTimeStamp - $dtsEffOuv ;
							
							if ((($differenceEffOuv > 0)and ($dtsEffOuv != null))
										
							
										
									and(($differencePrevFin < 0)and ($dtsPrevFin != null)))
							
							{
									
								$sunburst =
								'<td>
							
							<img src="images/Sunburst.jpg" height="20" width="20" align = "center"
							>
				
							
							
							</td>';
									
								echo $sunburst;
									
							}
?>