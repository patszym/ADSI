<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Tache par cycle
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation2.php'); 
				session_start();
				$ses_id = session_id();
				?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> Cliquez sur l'image du feu pour accéder aux 
			listes respectivement de campagnes, phases ou taches</p>
	</div><!-- #secondaire -->
		
	<div id="principal"> 
			<h5>Etat des taches par cycles </h5>
		
		<fieldset class="saisie">
			<table BORDER=0>
		
			<?php  $today = date("Y-m-d H:i:s");
				$aujourdhui = date("d-m-Y H:i:s");
				$date = new DateTime($today,new DateTimeZone('Europe/Paris'));
				$todayTimeStamp = $date->getTimestamp();
				
			?>
			
			<tr>
			
			
			<td>Aujourd'hui :</td>
				<td>								
							<input type="text" name="aujourdhui" 
								value="<?php echo htmlspecialchars($aujourdhui); ?>" 
								maxlength="20" size="20" readonly></input>
				</td>
			</tr>
			<tr>
			
			
				
				<td></td>
				<td>
				<h3>  LISTE DES TACHES PAR CYCLE </h3>
				</td>
			</tr>
				
				<?php 
				
				include('include/con2log.php');
				
	
				$sql = 'select idTACHE, idTACHECYCLE, 
					 datePrevOuvCAMPAGNECYCLE, dateEffOuvCAMPAGNECYCLE,
					datePrevFerCAMPAGNECYCLE, dateEffFerCAMPAGNECYCLE,
					datePrevFinCAMPAGNECYCLE, dateEffFinCAMPAGNECYCLE,
			 		datePrevOuvPROCESSUSCYCLE, dateEffOuvPROCESSUSCYCLE,
					datePrevFerPROCESSUSCYCLE, dateEffFerPROCESSUSCYCLE,
					datePrevFinPROCESSUSCYCLE, dateEffFinPROCESSUSCYCLE,
			 		datePrevOuvTACHECYCLE, dateEffOuvTACHECYCLE,
					datePrevFerTACHECYCLE, dateEffFerTACHECYCLE,
					datePrevFinTACHECYCLE, dateEffFinTACHECYCLE,
					libelleCourtCYCLE, libelleTACHE, idTACHE, 
					libellePROCESSUS, libelleCAMPAGNE,  
					idPROCESSUS, idCAMPAGNE, idAppli, nomAPPLI,
					filenameCompRendTACHECYCLE, extensionCompRendTACHECYCLE
					
					from TACHECYCLE, TACHE, PROCESSUS, CAMPAGNE, APPLI, CYCLE,
							PROCESSUSCYCLE, CAMPAGNECYCLE';
				if (isset ($adm))
				
				{
					if ($adm == 0)
					{
						$sql=$sql.' , APPLI_has_UTI';
						
							
					}
				}
				$sql=$sql.' where CAMPAGNE.APPLI_idAPPLI = APPLI.idAPPLI
					and TACHE.PROCESSUS_idPROCESSUS = PROCESSUS.idPROCESSUS
					and PROCESSUS.CAMPAGNE_idCAMPAGNE = CAMPAGNE.idCAMPAGNE';
				$sql=$sql.' and CAMPAGNECYCLE.CAMPAGNE_idCAMPAGNE = CAMPAGNE.idCAMPAGNE
					and CAMPAGNECYCLE.CYCLE_idCYCLE = CYCLE.idCYCLE';
				$sql=$sql.' and PROCESSUSCYCLE.PROCESSUS_idPROCESSUS = PROCESSUS.idPROCESSUS
					and PROCESSUSCYCLE.CYCLE_idCYCLE = CYCLE.idCYCLE';
				$sql = $sql.' and TACHECYCLE.TACHE_idTACHE = TACHE.idTACHE
					and TACHECYCLE.CYCLE_idCYCLE = CYCLE.idCYCLE';
				if (isset($adm))
				
				{
					if ($adm == 0)
					{
				
						$sql=$sql.' AND APPLI.idAPPLI = APPLI_has_UTI.APPLI_idAPPLI';
						$sql=$sql.' AND APPLI_has_UTI.UTI_idUTI = :idUti';
					}
				}
				$sql=$sql.' order by nomAPPLI, libelleCAMPAGNE, libelleTACHE, libelleCourtCYCLE';
	
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				if (isset ($adm))
				
				{
					if ($adm == 0)
					{
				
						$query->bindParam(':idUti', $idUti, PDO::PARAM_INT);
					}
				}
				
				
				include_once "include/visuConvetTC.php";
				
				
				$i = 0 ;
				/*
				 *  idCAMPAGNE, 
				 *  idCAMPAGNECYCLE, 
				 *  libelleCAMPAGNE, 
				 *  idPROCESSUS, 
				 *  idPROCESSUSCYCLE, 
				 *  libellePROCESSUS, 
				 *  idTACHE, 
				 *  idTACHECYCLE, 
				 *  libelleTACHE, 
				 *  idAppli, 
				 *  nomAPPLI,
				 *   
				 *  datePrevOuvCAMPAGNECYCLE, 
				 *  dateEffOuvCAMPAGNECYCLE, 
				 *  datePrevFerCAMPAGNECYCLE, 
				 *  dateEffFerCAMPAGNECYCLE, 
				 *  datePrevFinCAMPAGNECYCLE, 
				 *  dateEffFinCAMPAGNECYCLE, 
					datePrevOuvPROCESSUSCYCLE, 
					dateEffOuvPROCESSUSCYCLE, 
					datePrevFerPROCESSUSCYCLE, 
					dateEffFerPROCESSUSCYCLE, 
					datePrevFinPROCESSUSCYCLE, 
					dateEffFinPROCESSUSCYCLE, 
					datePrevOuvTACHECYCLE, 
					dateEffOuvTACHECYCLE, 
					datePrevFerTACHECYCLE, 
					dateEffFerTACHECYCLE, 
					datePrevFinTACHECYCLE, 
					dateEffFinTACHECYCLE, 
					
					libelleCourtCYCLE, 
					filenameCompRendTACHECYCLE, 
				 *  extensionCompRendTACHECYCLE
				 */
				$i = 0 ;
				$idRowTache = null;
				
				$idTachecycle = null ;
				
				$datePrevOuvCampagnecycle =  null;
				$dateEffOuvCampagnecycle = null;
				$datePrevFerCampagnecycle =  null;
				$dateEffFerCampagnecycle = null;
				$datePrevFinCampagnecycle =  null;
				$dateEffFinCampagnecycle = null;
				
				$datePrevOuvProcessuscycle =  null;
				$dateEffOuvProcessuscycle = null;
				$datePrevFerProcessuscycle =  null;
				$dateEffFerProcessuscycle = null;
				$datePrevFinProcessuscycle =  null;
				$dateEffFinProcessuscycle = null;
				
				$datePrevOuvTachecycle =  null;
				$dateEffOuvTachecycle = null;
				$datePrevFerTachecycle =  null;
				$dateEffFerTachecycle = null;
				$datePrevFinTachecycle =  null;
				$dateEffFinTachecycle = null;
				
				
				$libelleCourtCycle = null ;
				$libelleTache = null;
				$idTache = null ;
				$libelleProcessus = null;
				$libelleCampagne =  null ;
				$idProcessus = null;
				$idCampagne = null;
				$idAppli = null;
				$nomAppli = null;
				$filenameCompRendTachecycle = null;
				$extensionCompRendTachecycle= null;
				
			
				
				
				
				while ($i<$maxRow)
				{
					$idRowTache =  $tableau [$i][0] ;
					$idTachecycle =  $tableau [$i][1] ;
					
					$datePrevOuvCampagnecycle=  $tableau [$i][2] ;
					$dateEffOuvCampagnecycle =  $tableau [$i][3] ;
					$datePrevFerCampagnecycle =  $tableau [$i] [4];
					$dateEffFerCampagnecycle =  $tableau [$i] [5];
					$datePrevFinCampagnecycle =  $tableau [$i] [6];
					$dateEffFinCampagnecycle  = $tableau [$i] [7];
					
					$datePrevOuvProcessuscycle=  $tableau [$i][8] ;
					$dateEffOuvProcessuscycle =  $tableau [$i][9] ;
					$datePrevFerProcessuscycle =  $tableau [$i] [10];
					$dateEffFerProcessuscycle =  $tableau [$i] [11];
					$datePrevFinProcessuscycle =  $tableau [$i] [12];
					$dateEffFinProcessuscycle  = $tableau [$i] [13];
					
					$datePrevOuvTachecycle=  $tableau [$i][14] ;
					$dateEffOuvTachecycle =  $tableau [$i][15] ;
					$datePrevFerTachecycle =  $tableau [$i] [16];
					$dateEffFerTachecycle =  $tableau [$i] [17];
					$datePrevFinTachecycle =  $tableau [$i] [18];
					$dateEffFinTachecycle  = $tableau [$i] [19];
					
					
					$libelleCourtCycle  = $tableau [$i] [20];
					$libelleTache = $tableau [$i] [21];
					$idTache= $tableau [$i] [22];
					$libelleProcessus  = $tableau [$i] [23];
					$libelleCampagne  = $tableau [$i] [24];
					$idProcessus = $tableau [$i] [25];
					$idCampagne = $tableau [$i] [26];
					$idAppli   = $tableau [$i] [27];
					$nomAppli   = $tableau [$i] [28];
					$filenameCompRendTachecycle= $tableau [$i] [29];
					$extensionCompRendTachecycle= $tableau [$i] [30];
					
					
					
					
					$i++;
					/* Exploitation des lignes dans la liste */
					 include "include/convDatesetTC.php" ;
				?> 				
				
				<!-- Liste des  Tachecycles - formulaire en lecture -->
									
					
					<tr>
						<td>								
							<input type="text" name="libelleCourtCycle" 
								value="<?php echo htmlspecialchars($libelleCourtCycle); ?>" 
								maxlength="10" size="10" readonly></input>
						</td>
					
					</tr>
					<tr>
						
						<td>
							<input type="text" name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="10" readonly></input>
						</td>
						<td>
							<input type="text" name="libelleCampagne" 
							value="<?php echo htmlspecialchars($libelleCampagne); ?>" 
							maxlength="100" size="50" readonly></input>
						</td>
							
            				<?php include('afficheFeuxCampagne.php'); ?> 
					</tr>
					<tr>
						
						
						
						<td>
							
						</td>
						<td>
							<input type="text" name="libelleProcessus" 
							value="<?php echo htmlspecialchars($libelleProcessus); ?>" 
							maxlength="100" size="50" readonly></input>
						</td>
						<?php include('afficheFeuxProcessus.php'); ?> 
					</tr>
					<tr>
						
						
						
						<td>
							
						</td>
						<td>
							<input type="text" name="libelleTache" 
							value="<?php echo htmlspecialchars($libelleTache); ?>" 
							maxlength="100" size="50" readonly></input>
						</td>
						
						<?php include('afficheFeuxTache.php'); ?> 
											
					</tr>			
										
							
				<?php 
				}
				$query = null;
				?>
			</table>
		</fieldset>

		</div> <!-- principal-->
	
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
