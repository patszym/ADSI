<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Ecran principal Administrateur de ASI
	</title>
	<!-- La feuille de styles "base.css" doit être appeée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
 
  <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script>
  $(function() {
    $( "#accordion1" ).accordion();
  });
  </script>
   <script>
  $(function() {
    $( "#accordion2" ).accordion();
  });
  </script>
  <script>
  $(function() {
    $( "#menu" ).menu();
  });
  </script>
  <style>
  .ui-menu { width: 150px; }
  </style>
</head>

<body>

<div id="global">

	<div id="entete">
	<?php session_start(); ?> 
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
			
	</div><!-- #entete -->

	<div id="centre">
	 <div id="centre-bis">

		
		
		<?php include('include/laNavigation2.php'); ?> 

	<div id="secondaire">
		
			<h3>Utilisation</h3>
			<p>La liste des fonctionnalités est accessible dans la colonne 
			tout à gauche. Cliquer sur l'option choisie.</p>
			<p> Au centre se précisent les définitions des fonctionnalités attendues.</p>
			
		</div><!-- #secondaire -->

	<div id="principal">
		
		<object type="application/msword" data="doc/ME.doc" width="300" height="200">
			<a href="doc/ME.doc">Mode d'emploi</a>
			</object>
			
			<h1><p>Aide pour les fonctionnalités </p> </h1>
		<h3>Consultations </h3>
	<div id="accordion1">
		<h3>Consultation complète d'un projet</h3>
  		<div>
    		<p>
    			Il s'agit d'une consultation donnant le détail par ligne des applications, avec leur MOA, leurs ASI, 
    			leurs bases de données rattachées, et éventuellement les contacts de la diffusion. 
    		</p>
  		</div>
  		<h3>Etat des taches</h3>
  		<div>
    		<p>
    			Il s'agit d'une consultation donnant le détail des taches à une date d'observation (par défaut aujourd'hui), compte tenu des dates saisies : 
    			prévisionnelles ou effectives, d'ouverture, de fermeture, ou de fin de tache.
    			Les taches sont listées, mais aussi les campagnes, les phases qui les produisent et les encadrent.
    		</p>
  		</div>
  	 </div>
  	
	<h3>par ordre de saisie </h3>
	<div id="accordion2">
		<h3>Calendriers</h3>
  		<div>
    		<p>
    		Gestion des calendriers: Ajouter, modifier, supprimer ou consulter dans la liste 
			des Calendriers. Les calendriers permettent de saisir le compte rendu de réunion. 
    		</p>
  		</div>
  		<h3>Traitements de mise à jour</h3>
  		<div>
    		<p>
    		Gestion des traitements de mise à jour : Ajouter, modifier, supprimer ou consulter dans la liste 
			des traitements de mise à jour. Il s'agit de localiser les traitements de mise à jour logiciels diffusés 
    		</p>
  		</div>
  		
  		<h3>Traitements locaux</h3>
  		<div>
    		<p>
    		Gestion des traitements locaux : Ajouter, modifier, supprimer ou consulter dans la liste 
			des traitements de locaux.  Il s'agit de localiser les traitements qui sont fait à façon sur place et non diffusés.
    		</p>
  		</div>
  		
  		<h3>Campagnes</h3>
  		<div>
    		<p>
    		Gestion des campagnes : Ajouter, modifier, supprimer ou consulter dans la liste 
			des campagnes. Il s'agit du premier niveau dans l'organisation des processus d'entreprise, amenant par la suite 
			plusieurs phases.
    		</p>
  		</div>
  		
  		<h3>Phases</h3>
  		<div>
    		<p>
    		Gestion des phases : Ajouter, modifier, supprimer ou consulter dans la liste 
			des phases. Il s'agit du deuxieme niveau dans l'organisation des processus d'entreprise, amenant par la suite 
			plusieurs taches.
    		</p>
  		</div>
  		
  		<h3>taches</h3>
  		<div>
    		<p>
    		Gestion des taches : Ajouter, modifier, supprimer ou consulter dans la liste 
			des taches. Il s'agit du dernier niveau dans l'organisation des processus d'entreprise.
			(exemple, lancement de la prise en compte 
			de la saisie de candidatures pour les charger dans une base - détail des fonctions 
			accomplies par le logiciel dans un descriptif) 
    		</p>
  		</div>
  		
  		<h3>Campagnes par cycles</h3>
  		<div>
    		<p>
    		Gestion des campagnes par cycles administratifs : Ajouter, modifier, supprimer ou consulter dans la liste 
			des campagnes par cycles administratifs. Dans l'organisation des campagnes, les dates prévisionnelles et
			effective d'ouverture, de fermeture et de fin sont factorisées par les cycles administratifs qui les détermine : 
			exemple, cycle du mois pour la paye, l'année scolaire avec la session de juin ou bien celle de septembre,
			ou encore l'année scolaire ou l'année comptable.
			qui ont les mêmes descriptifs de campagnes... etc
    		</p>
  		</div>
  		
  		<h3>Phases par cycles</h3>
  		<div>
    		<p>
    		Gestion des phases par cycles administratifs : Ajouter, modifier, supprimer ou consulter dans la liste 
			des phases par cycles administratifs. Dans l'organisation des campagnes, les dates prévisionnelles et
			effective d'ouverture, de fermeture et de fin sont factorisées par les cycles administratifs qui les détermine : 
			exemple, cycle du mois pour la paye, l'année scolaire avec la session de juin ou bien celle de septembre, 
			qui ont les mêmes descriptifs de phases... etc
    		</p>
  		</div>
  		
  		<h3>Taches par cycles</h3>
  		<div>
    		<p>
    		Gestion des taches par cycles administratifs : Ajouter, modifier, supprimer ou consulter dans la liste 
			des taches par cycles administratifs. Dans l'organisation des campagnes, les dates prévisionnelles et
			effective d'ouverture, de fermeture et de fin sont factorisées par les cycles administratifs qui les détermine : 
			exemple, cycle du mois pour la paye, l'année scolaire avec la session de juin ou bien celle de septembre, 
			qui ont les mêmes descriptifs de taches... etc. Le compte rendu de la tache (exemple, lancement de la prise en compte 
			de la saisie de candidatures pour les charger dans une base) est ici mémorisé.
    		</p>
  		</div>
  	</div>
		
</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<h3> </h3><BR></BR>
		
		<BR></BR>
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
		
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
