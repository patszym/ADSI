<?php	

if(!empty($_POST["soumet"]))
{

					$idCampagne = $_POST["idCampagne"];
					
					if(!empty($_POST["idRowAppli"]))
					{
						$idAppli=$_POST["idRowAppli"];
					} else
					{
						$idAppli = null;
					}
					
				
					if(!empty($_POST["libelleCampagne"]))
					{
						$libelleCampagne=$_POST["libelleCampagne"];
					} else
					{
						$libelleCampagne = null;
					}
					if(!empty($_POST["descriptifCampagne"]))
					{
						$descriptifCampagne=$_POST["descriptifCampagne"];
					} else
					{
						$descriptifCampagne = null;
					}
				
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE CAMPAGNE SET '.
							' APPLI_idAPPLI ="'.$idAppli.'",'.
							
							' libelleCAMPAGNE ="'.$libelleCampagne.'",'.
							' descriptifCAMPAGNE ="'.$descriptifCampagne.'"';
						
					
					
					$sql = $sql.' WHERE idCAMPAGNE = :idCampagne ';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idCampagne', $idCampagne, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	