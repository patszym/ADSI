<!DOCTYPE html PUBLIC "-//W3C//DTD XHPOL 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Processus
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	

</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation2.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> A l'appel du menu général, le mode <b> Liste et Edition</b> est le mode par défaut</p>
			<p> Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence de traitement local. </p>
			<p> Cliquez sur l'image de l'oeil pour voir le détail de la ligne spécifiée en consultation dans la liste. 
			
			<p> Cliquez sur l'image du crayon pour voir le détail de la ligne spécifiée en modification dans la liste. 
			</p>
			<p> Cliquez sur l'image de la croix pour voir le détail de la ligne spécifiée en suppression dans la liste</p>
			<p>Cliquez sur l'icône <b>PDF</b> pour voir le détail de la ligne en obtenant son édition PDF </p>
			
			<p>Cliquez sur l'icône <b>PDF</b> à gauche du titre pour obtenir l'édition PDF de la liste</p>
			
	</div><!-- #secondaire -->
		
	<div id="principal"> 
			<h5>Gestion des phases</h5>
			
		
			<div id="tabsF">
				<?php include('include/MHPO.php'); 
					session_start();
				$ses_id = session_id();
				?> 
									
			</div>
		
		<fieldset class="saisie">
			<table BORDER=0>
			
			<tr>
			
				<td>
				<a href="editions/edPOPDF.php">
				<img src="images/pdficon.jpg" height="20" width="20" align = "center" 
				alt="PDF">
				</a>
				</td>
				
				<td>
				<h3>  LISTE DES PHASES </h3>
				</td>
			</tr>
				
				<?php 
				include('include/con2log.php');
				$sql = 'select idCAMPAGNE, idPROCESSUS, 
					libellePROCESSUS, descriptifPROCESSUS,
					libelleCAMPAGNE, nomAPPLI, idAPPLI
					
					from PROCESSUS, CAMPAGNE, APPLI';
				if (isset ($adm))
				
				{
					if ($adm == 0)
					{
						$sql=$sql.' , APPLI_has_UTI';
						
							
					}
				}
				
				$sql=$sql.' where PROCESSUS.CAMPAGNE_idCAMPAGNE = CAMPAGNE.idCAMPAGNE
					and CAMPAGNE.APPLI_idAPPLI = APPLI.idAPPLI';
				if (isset ($adm))
					
				{
					if ($adm == 0)
					{
							
						$sql=$sql.' AND APPLI.idAPPLI = APPLI_has_UTI.APPLI_idAPPLI';
						$sql=$sql.' AND APPLI_has_UTI.UTI_idUTI = :idUti';
					}
				}
				
				$sql=$sql.' order by nomAPPLI, libelleCAMPAGNE, libellePROCESSUS';
				$query = $dbh->prepare($sql, array(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL));
				if (isset ($adm))
					
				{
					if ($adm == 0)
					{
							
						$query->bindParam(':idUti', $idUti, PDO::PARAM_INT);
					}
				}
			
				include_once "include/visuConvPO.php";
				
				$i = 0 ;
				$idCampagne = null;
				$idProcessus = null ;
				$nomProcessus =  null;
				$libelleProcessus =  null;
				$descriptifProcessus =  null;
				$libelleCampagne = null;
				$nomAppli = null;
				$idAppli = null;
			
				
				
				while ($i<$maxRow)
				{
					$idCampagne =  $tableau [$i][0] ;
					$idProcessus =  $tableau [$i][1] ;
					
					
					$libelleProcessus =	$tableau [$i] [2];
					$descriptifProcessus =  $tableau [$i][3] ;
					
					
					$libelleCampagne = $tableau [$i] [4];
					$nomAppli = $tableau [$i] [5];
					$idAppli = $tableau [$i] [6];
					
					
					$i++;
					/* Exploitation des lignes dans la liste */
					?>
					
					
				
				<!-- Liste des  Processuss - formulaire en lecture -->
									
									
						
							<input type="hidden" name="idProcessus"
							value="<?php echo htmlspecialchars($idProcessus); ?>"
							maxlength="3" size="3" ></input>
					
					<tr>
						<td>
							<input type="text" name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="10" readonly></input>
						</td>
						<td>
							<input type="text" name="libelleCampagne" 
							value="<?php echo htmlspecialchars($libelleCampagne); ?>" 
							maxlength="100" size="30" readonly></input>
						</td>
						<td>
							<input type="text" name="libelleProcessus" 
							value="<?php echo htmlspecialchars($libelleProcessus); ?>" 
							maxlength="100" size="30" readonly></input>
						</td>
					
						
						
						<td>
							<form action="consPO.php" method="post">

			 					<input type="hidden" name="idProcessus" 
			 					value="<?php echo htmlspecialchars($idProcessus); ?>">
			 					</input>
			 					<input type="hidden" name="idAppli" 
								value="<?php echo htmlspecialchars($idAppli); ?>" 
								></input>
			 				
			 					
								<input border=0 src="images/eye.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
						</td>
							</form> 
						</td>
						<td>
							<form action="modifPO.php" method="post">

			 					<input type="hidden" name="idProcessus" 
			 					value="<?php echo htmlspecialchars($idProcessus); ?>">
			 					</input>
			 					<input type="hidden" name="idAppli" 
								value="<?php echo htmlspecialchars($idAppli); ?>" 
								></input>
			 				
			 				
								<input border=0 src="images/crayon.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form>
						</td>
						<td> 
							<form action="supprPO.php" method="post">

			 					<input type="hidden" name="idProcessus" 
			 					value="<?php echo htmlspecialchars($idProcessus); ?>">
			 					</input>
			 					<input type="hidden" name="idAppli" 
								value="<?php echo htmlspecialchars($idAppli); ?>" 
								></input>
			 				
								<input border=0 src="images/button-cancel.png" 
									type=image value=submit name = "soumet" align="left" 
									height="20" width="20">
									</input>
		
							</form>
						</td> 
						<td> 					
							
							<form action="editions/edElPOPDF.php" method="post">
							
								<input type="hidden" name="nomAppli" 
								value="<?php echo htmlspecialchars($nomAppli); ?>">
								</input>
								
								<input type="hidden" name="libelleCampagne" 
								value="<?php echo htmlspecialchars($libelleCampagne); ?>">
								</input>
			 				
			 					<input type="hidden" name="idProcessus" 
								value="<?php echo htmlspecialchars($idProcessus); ?>">
								</input>
			 				
										 				
			 					<input type="hidden" name="libelleProcessus" 
								value="<?php echo htmlspecialchars($libelleProcessus); ?>">
								</input>
			 		
								<input type="hidden" name="descriptifProcessus" 
								value="<?php echo htmlspecialchars($descriptifProcessus); ?>">
								</input>
							
																
			 					<input border=0 src="images/pdficon.jpg" 
								type=image value=submit name = "soumet" align="left" 
								height="20" width="20">
								</input>

										
							</form>
						</td> 
											
					</tr>			
										
							
				<?php 
				}
				$query = null;
				?>
			</table>
		</fieldset>

		</div> <!-- principal-->
	
	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
