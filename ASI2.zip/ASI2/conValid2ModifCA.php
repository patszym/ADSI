<?php	
include_once('include/ConversionDates.class.php');
if(!empty($_POST["soumet"]))
{

					$idCalendrier = $_POST["idCalendrier"];
					
					if(!empty($_POST["idRowAppli"]))
					{
						$idAppli=$_POST["idRowAppli"];
					} else
					{
						$idAppli = null;
					}
					
					if(!empty($_POST["objetRDVCalendrier"]))
					{
						$objetRDVCalendrier=$_POST["objetRDVCalendrier"];
					} else 
					{ 
						$objetRDVCalendrier = null;
					}
					
					
					
					
					$dateversRowRDVCalendrier  = null;
					$validdateRDVCalendrier = true;
						
					if(!empty($_POST["dateRDVCalendrier"]))
					{
							
							
						$conversionDate1 = new ConversionDates();
						$conversionDate1->setdt($_POST['dateRDVCalendrier']);
						$H = $_POST['HRDVCalendrier'];
						
						if (($H>24) or ($H<00))
						{
							echo "Heure anormale: heure doit être supérieure à 00 et inférieure à 25 <br></br>";
							$H = "00";
						}
						
							$conversionDate1->setH($H);
						
						$i = $_POST['iRDVCalendrier'];
						if (($i>60) or ($i<00))
						{
							echo "minutes anormale: minute doit être supérieure à 00 et inférieure à 61 <br></br>";
							$i = "00";
						}
						
							$conversionDate1->seti($i);
						
						$conversionDate1->convdDate();
						$dateversRowRDVCalendrier = $conversionDate1->getdate() ;
						if (!checkdate($conversionDate1->getm(), $conversionDate1->getd(), $conversionDate1->getY()))
						{
					
							$validdateRDVCalendrier = false;
							echo $dateRDVCalendrier. " n'est pas une date valide <br>";
							?>
								<script language="javascript">
								alert("Date de rendez vous du projet non conforme au format d'une date");
								</script>
								<?php
						}
					} 
					else
					{
						$dateversRowRDVCalendrier  = null;
					}
					if(!empty($_POST["libelleCalendrier"]))
					{
						$libelleCalendrier=$_POST["libelleCalendrier"];
					} else
					{
						$libelleCalendrier = null;
					}
					
					// initialisation des attibuts en modification de la table CALENDRIER
					
					$crdCalendrier = null;
					$mimecrdCalendrier = null;
					$sizecrdCalendrier = null;
					$filenamecrdCalendrier = null;
					$extensioncrdCalendrier = null;
					
					include('include/tailleMaxi.php');
					$content_blob = null;
					$mime_type = null;
					$fic_taille = 0;
					$content_nom = null;
					
					if(!empty($_FILES["crdFormCalendrier"]))
					{
						if ($_FILES["crdFormCalendrier"]["error"] > 0)
						{
							echo "Erreur Return Code: " . $_FILES["crdFormCalendrier"]["error"] . "<br />";
						}
						else
						{
								
							if(!empty($_FILES['crdFormCalendrier']['tmp_name']))
							{
					
								echo $_FILES['crdFormCalendrier']['tmp_name'];
					
								$content_temp_nom = $_FILES['crdFormCalendrier']['tmp_name'];
								$nom_fichier_origine = $_FILES['crdFormCalendrier']['name'];
									
								$ret = is_uploaded_file ($_FILES['crdFormCalendrier']['tmp_name']);
								if ( !$ret )
								{
									echo "Problème de transfert";
									return false;
								}
								else
								{
									$nom_fichier_origine = $_FILES['crdFormCalendrier']['name'];
									// Le fichier a bien été reçu
									$fic_taille = $_FILES['crdFormCalendrier']['size'];
									if ( $fic_taille > $taille_max )
									{
										echo "Fichier téléchargé trop important - taille maxi dépassée !";
										return false;
									}
										
									$mime_type = $_FILES['crdFormCalendrier']['type'];
					
										
										
									$fp = fopen ($content_temp_nom, "rb");
										
									$content_blob = fread($fp, $fic_taille);
									fclose ($fp);
									$crdCalendrier = addslashes($content_blob);
										
									$sizecrdCalendrier = $fic_taille;
									$mimecrdCalendrier = $mime_type;
										
									$path_parts = pathinfo($nom_fichier_origine);
										
									// echo $path_parts['dirname'], "\n";
									// echo $path_parts['basename'], "\n";
									$extensioncrdCalendrier = $path_parts['extension'];
									$filenamecrdCalendrier = $path_parts['filename']; // depuis PHP 5.2.0
										
										
										
										
								}
							}
					
						}
					}
								
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE CALENDRIER SET '.
							' APPLI_idAPPLI ="'.$idAppli.'",'.
							' objetRDVCALENDRIER ="'.$objetRDVCalendrier.'"';
							
						
					
					if(!empty($_POST["dateRDVCalendrier"]))
					{
					$sql = $sql.', dateRDVCALENDRIER ="'.$dateversRowRDVCalendrier.'"';
					}
					else 
						{
							$sql = $sql.', dateRDVCALENDRIER =null';
						}
					
					$sql = $sql.', libelleCALENDRIER ="'.$libelleCalendrier.'"';
							
					
					
					if(!empty($crdCalendrier))
					{
					
						$sql = $sql .', crdCALENDRIER ="'.$crdCalendrier.'",';
						$sql = $sql .' mimecrdCALENDRIER ="'.$mimecrdCalendrier.'",';
						$sql = $sql .' sizecrdCALENDRIER ='.$sizecrdCalendrier.',';
						$sql = $sql .' filenamecrdCALENDRIER ="'.$filenamecrdCalendrier.'",';
						$sql = $sql .' extensioncrdCALENDRIER ="'.$extensioncrdCalendrier.'"';
									
					
					}
					
					
					
					$sql = $sql.' WHERE idCALENDRIER = :idCalendrier ';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idCalendrier', $idCalendrier, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	