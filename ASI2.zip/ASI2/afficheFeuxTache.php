<?php

// Ouverture Tache Cycle :
						
							if ($datePrevOuvTachecycle != null)
							{
							$dt = new DateTime($datePrevOuvTachecycle, new DateTimeZone('Europe/Paris'));
						
							$dtsPrevOuv =($dt->getTimestamp());
							}
							else 
							{
								$dtsPrevOuv = null;
							}
							
							if ($dateEffOuvTachecycle != null)
							{
								$dt = new DateTime($dateEffOuvTachecycle, new DateTimeZone('Europe/Paris'));
							
								$dtsEffOuv =($dt->getTimestamp());
							}
							else
							{
								$dtsEffOuv = null;
							}
							
							$differenceOuv = $todayTimeStamp - $dtsPrevOuv ;
							
							if ((($differenceOuv > 0)and ($dtsPrevOuv != null))  and ($dtsEffOuv == null)) 
								
							{
            					echo "<br></br>".$nomAppli." Taches ".$libelleCourtCycle.": date prévisionnelle d'ouverture ".$datePrevOuvTachecycle." inférieure à aujourd'hui";
            					echo "  et date effective d'ouverture nulle ";
						
            				
            				$feu_Rouge = 
            				'<td>
							<a href="edTC.php">
							<img src="images/feuRouge.jpg" height="20" width="20" align = "center" 
							>
							
							</a>
				
							</td>';
            				
							echo $feu_Rouge;
						
							}
							
	// Fermeture Tache Cycle :
							
							if ($datePrevFerTachecycle != null)
							{
								$dt = new DateTime($datePrevFerTachecycle, new DateTimeZone('Europe/Paris'));
							
								$dtsPrevFer =($dt->getTimestamp());
							}
							else
							{
								$dtsPrevFer = null;
							}
								
							if ($dateEffFerTachecycle != null)
							{
								$dt = new DateTime($dateEffFerTachecycle, new DateTimeZone('Europe/Paris'));
									
								$dtsEffFer =($dt->getTimestamp());
							}
							else
							{
								$dtsEffFer = null;
							}
								
							$differenceFer = $todayTimeStamp - $dtsPrevFer ;
								
							if ((($differenceFer > 0)and ($dtsPrevFer != null)) and ($dtsEffFer == null))
							
							{
								echo "<br></br>".$nomAppli." Taches ".$libelleCourtCycle.": date prévisionnelle de fermeture ".$datePrevFerTachecycle." inférieure à aujourd'hui";
								echo "  et date effective de fermeture nulle ";
							
							
								$feu_Rouge =
								'<td>
							<a href="edTC.php">
							<img src="images/feuRouge.jpg" height="20" width="20" align = "center"
							>
				
							</a>
							
							</td>';
							
								echo $feu_Rouge;
							
							}
							
	// Fin Tache Cycle :
								
							if ($datePrevFinTachecycle != null)
							{
								$dt = new DateTime($datePrevFinTachecycle, new DateTimeZone('Europe/Paris'));
									
								$dtsPrevFin =($dt->getTimestamp());
							}
							else
							{
								$dtsPrevFin = null;
							}
							
							if ($dateEffFinTachecycle != null)
							{
								$dt = new DateTime($dateEffFinTachecycle, new DateTimeZone('Europe/Paris'));
									
								$dtsEffFin =($dt->getTimestamp());
							}
							else
							{
								$dtsEffFin = null;
							}
							
							$differenceFin = $todayTimeStamp - $dtsPrevFin ;
							
							if ((($differenceFin > 0)and ($dtsPrevFin != null)) and ($dtsEffFin == null))
								
							{
								echo "<br></br>".$nomAppli." Taches ".$libelleCourtCycle.": date prévisionnelle de fin".$datePrevFinTachecycle." inférieure à aujourd'hui";
								echo "  et date effective de fin nulle ";
									
									
								$feu_Rouge =
								'<td>
							<a href="edTC.php">
							<img src="images/feuRouge.jpg" height="20" width="20" align = "center"
							>
							
							</a>
				
							</td>';
									
								echo $feu_Rouge;
									
							}
							$differenceEffFin = $todayTimeStamp - $dtsEffFin ;
							
								
							if (($differenceEffFin > 0)and ($dtsEffFin != null)) 
							
							{
								
								$panneau_stop =
								'<td>
							
							<img src="images/arreter.png" height="20" width="20" align = "center"
							>
				
							
							
							</td>';
									
								echo $panneau_stop;
									
							}
							$differencePrevFin = $todayTimeStamp - $dtsPrevFin ;
							$differenceEffOuv = $todayTimeStamp - $dtsEffOuv ;
								
							if ((($differenceEffOuv > 0)and ($dtsEffOuv != null))  
							
						
							
							and(($differencePrevFin < 0)and ($dtsPrevFin != null)))
								
							{
							
								$sunburst =
								'<td>
				
							<img src="images/Sunburst.jpg" height="20" width="20" align = "center"
							>
							
				
				
							</td>';
									
								echo $sunburst;
									
							}
?>