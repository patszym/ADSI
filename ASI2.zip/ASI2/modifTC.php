<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">


<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	</meta>
	<title>
		Taches par cycles
	</title>
	<!-- La feuille de styles "base.css" doit être appelée en premier. -->
	<link rel="stylesheet" type="text/css" href="styles/base.css" media="all" />
	<link rel="stylesheet" type="text/css" href="styles/modele11.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="styles/mHorizontal.css" media="screen" />
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css">
	<style type="text/css">    
		div.ui-datepicker{
		font-size: 12px;
	}
	</style>
	<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
	<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
	<script src="jquery.ui.datepicker-fr.js"></script>
	<script>
		$(function() {
		$("#calendrier1").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		
	</script>
	<script>
		$(function() {
		$("#calendrier2").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		
	</script>
	<script>
		$(function() {
		$("#calendrier3").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		
	</script>
	<script>
		$(function() {
		$("#calendrier4").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		
	</script>
	<script>
		$(function() {
		$("#calendrier5").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		
	</script>
	<script>
		$(function() {
		$("#calendrier6").datepicker({dateFormat: "dd/mm/yy",
			appendText: " jj/mm/aaaa "});
		});
		
	</script>
	
</head>	
	

<body>

<div id="global">

	<div id="entete">
		<h1>
			<img alt="" src="images/acaCreteil.jpg" />
			<span>ADSI</span>
		</h1>
		<p class="sous-titre">
			
			Logiciel de gestion pour l'administration des applications du système d'informations
		</p>
	</div><!-- #entete -->

	<div id="centre">
	<div id="centre-bis">

		<?php include('include/laNavigation2.php'); ?> 

	<div id="secondaire">
			<h3>Utilisation</h3>
			<p> Il faut valider la modification pour achever la tâche (bouton <b> valider </b>)</p>
			
			<p>	Cliquez sur l'onglet <b>Liste et Edition </b>pour une consultation, une autre modification, 
			ou une suppression </p>
			<p>	Cliquez sur l'onglet <b>Ajout </b> pour créer une occurence de Processuscycle </p>
			
			
		</div><!-- #secondaire -->

		<div id="principal"> 
			<h5>Gestion des taches par cycles </h5>
			
		
			<div id="tabsF">
				<?php include('include/MHTC.php'); ?>
			</div> 
				<?php $cons = 2; ?>
				<?php include('include/con2TC.php'); ?> 
			
				<?php include('include/con1TAs.php'); ?> 
				
				<?php include('include/con1CYs.php'); ?> 
			<fieldset class="saisie">
			
			<form name="modifTachecycle" id="modifTachecycleForm" method="post"
				 enctype="multipart/form-data" 
					action="valid2modifTC.php">
					
				<table BORDER=0>	
					<!-- ^modification Tachecycle - formulaire -->
					<br>
					
					<input type="hidden" name="idTachecycle" 
						value="<?php echo htmlspecialchars($idTachecycle); ?>">
						</input>
						
						<tr>
						<td>Application :</td>
						<td>
							<input type="text" name="nomAppli" 
							value="<?php echo htmlspecialchars($nomAppli); ?>" 
							maxlength="20" size="20" ></input>
						</td>
					</tr>
					<tr>
						<td>Campagne :</td>
						<td>
							<input type="text" name="libelleCampagne" 
							value="<?php echo htmlspecialchars($libelleCampagne); ?>" 
							maxlength="100" size="60" ></input>
						</td>
					</tr>
					<tr>
						<td>Phase :</td>
						<td>
							<input type="text" name="libelleProcessus" 
							value="<?php echo htmlspecialchars($libelleProcessus); ?>" 
							maxlength="100" size="60" ></input>
						</td>
					</tr>		
					<tr>
						<td>Tache :</td>
						<td>
						 <select   name="idTache" >
							<?php
							
							$i = 0;
							while ($i<$index1)
							{
					
								 	echo '<option value="'.
										$tableau1 [$i][0].'"'.$tableau1 [$i][2].'>'.
										$tableau1 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
						
				
					
					<tr>
						<td>Cycle :</td>
						<td>
						 <select   name="idCycle" >
							<?php
							
							$i = 0;
							while ($i<$index2)
							{
					
								 	echo '<option value="'.
										$tableau2 [$i][0].'"'.$tableau2 [$i][2].'>'.
										$tableau2 [$i][1].'</option>';
										
								$i++;
							}
							?>
						 </select>
						</td>
					</tr>
						
								
				
					<tr>
						<td> Date prévisionnelle d'ouverture : </td>
						<td>
							<INPUT type=text id="calendrier1" 
							name="datePrevOuvTachecycle" 
							value="<?php echo htmlspecialchars($dPrevOuvTachecycle); ?>" 
							maxlength="10" size="10" readonly>
							</input>
						</td>
					</tr>
					<!--
					<tr>
						<td> Heure prévisionnelle d'ouverture : </td>
						<td>
							<INPUT type="text" 
							name="HPrevOuvTachecycle" 
							value="<?php echo htmlspecialchars($HPrevOuvTachecycle); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>
					<tr>
						<td> Minutes prévisionnelle d'ouverture : </td>
						<td>
							<INPUT type="text" 
							name="iPrevOuvTachecycle" 
							value="<?php echo htmlspecialchars($iPrevOuvTachecycle); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>
					-->			
						<tr>
						<td> Date effective d'ouverture : </td>
						<td>
							<INPUT type=text id="calendrier2" 
							name="dateEffOuvTachecycle" 
							value="<?php echo htmlspecialchars($dEffOuvTachecycle); ?>" 
							maxlength="10" size="10" readonly>
							</input>
						</td>
					</tr>
					<!--
					<tr>
						<td> Heure effective d'ouverture : </td>
						<td>
							<INPUT type="text" 
							name="HEffOuvTachecycle" 
							value="<?php echo htmlspecialchars($HEffOuvTachecycle); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>
					<tr>
						<td> Minutes effective d'ouverture : </td>
						<td>
							<INPUT type="text" 
							name="iEffOuvTachecycle" 
							value="<?php echo htmlspecialchars($iEffOuvTachecycle); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>
					-->						
					
				
					
					<tr>
						<td> Date prévisionnelle de fermeture : </td>
						<td>
							<INPUT type=text id="calendrier3" 
							name="datePrevFerTachecycle" 
							value="<?php echo htmlspecialchars($dPrevFerTachecycle); ?>" 
							maxlength="10" size="10" readonly>
							</input>
						</td>
					</tr>
					<!--
					<tr>
						<td> Heure prévisionnelle de fermeture : </td>
						<td>
							<INPUT type="text" 
							name="HPrevFerTachecycle" 
							value="<?php echo htmlspecialchars($HPrevFerTachecycle); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>
				
					<tr>
						<td> Minutes prévisionnelle de fermeture : </td>
						<td>
							<INPUT type="text" 
							name="iPrevFerTachecycle" 
							value="<?php echo htmlspecialchars($iPrevFerTachecycle); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>
					-->		
					<tr>
						<td> Date effective de fermeture : </td>
						<td>
							<INPUT type=text id="calendrier4" 
							name="dateEffFerTachecycle" 
							value="<?php echo htmlspecialchars($dEffFerTachecycle); ?>" 
							maxlength="10" size="10" readonly>
							</input>
						</td>
					</tr>
					<!--
					<tr>
						<td> Heure effective de fermeture : </td>
						<td>
							<INPUT type="text" 
							name="HEffFerTachecycle" 
							value="<?php echo htmlspecialchars($HEffFerTachecycle); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>
					<tr>
						<td> Minutes effective de fermeture : </td>
						<td>
							<INPUT type="text" 
							name="iEffFerTachecycle" 
							value="<?php echo htmlspecialchars($iEffFerTachecycle); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>					
					-->		
					
					<tr>
						<td> Date prévisionnelle de fin : </td>
						<td>
							<INPUT type=text id="calendrier5" 
							name="datePrevFinTachecycle" 
							value="<?php echo htmlspecialchars($dPrevFinTachecycle); ?>" 
							maxlength="10" size="10" readonly>
							</input>
						</td>
					</tr>
					<!--
					<tr>
						<td> Heure prévisionnelle de fin : </td>
						<td>
							<INPUT type="text" 
							name="HPrevFinTachecycle" 
							value="<?php echo htmlspecialchars($HPrevFinTachecycle); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>
					<tr>
						<td> Minutes prévisionnelle de fin : </td>
						<td>
							<INPUT type="text" 
							name="iPrevFinTachecycle" 
							value="<?php echo htmlspecialchars($iPrevFinTachecycle); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>
					-->			
					<tr>
						<td> Date effective de fin : </td>
						<td>
							<INPUT type=text id="calendrier6" 
							name="dateEffFinTachecycle" 
							value="<?php echo htmlspecialchars($dEffFinTachecycle); ?>" 
							maxlength="10" size="10" readonly>
							</input>
						</td>
					</tr>
					<!--
					<tr>
						<td> Heure effective de fin : </td>
						<td>
							<INPUT type="text" 
							name="HEffFinTachecycle" 
							value="<?php echo htmlspecialchars($HEffFinTachecycle); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>
					<tr>
						<td> Minutes effective de fin : </td>
						<td>
							<INPUT type="text" 
							name="iEffFinTachecycle" 
							value="<?php echo htmlspecialchars($iEffFinTachecycle); ?>" 
							maxlength="2" size="2" readonly>
							</input>
						</td>
					</tr>
					-->										
				
					<tr>
						
						 <td>
						 </td>
						 <td>
						 	<?php  
						 		echo "Le binaire du fichier numérisé associés à l'origine,"; 
							
						 		echo "au compte-rendu d'exploitation est présenté ici avec son nom d'origine 
									et son extension ";
						 	?>
						 </td>
					
					</tr>
					<tr>
						<td> 		
								<input type="text" name="filenameCompRendTachecycle" 
								value="<?php echo htmlspecialchars($filenameCompRendTachecycle); ?>" readonly>
								</input>
						</td>
						<td> 	
								<input type="text" name="extensionCompRendTachecycle"  size="4"
								value="<?php echo htmlspecialchars($extensionCompRendTachecycle); ?>" readonly>
								</input>
						</td>
					</tr>
					<tr>
						<td> Compte rendu d'exploitation :</td>
						<td>
							
							<input type="file" name="CompRendFormTachecycle" id="CompRendFormTachecycle" />
							</input> 
						</td>
					</tr>
					
					<tr>
						<td> 		
						<input type="submit" value="Valider" name="soumet">
						</input>
						</td>
						<td> 	
						<input type="submit" value="Annuler">
					    </input>
						
				
						</td>
					</tr>
					</table>	
			</form>
		
		</fieldset>	
			
		</div><!-- #principal -->

	</div><!-- #centre-bis -->
	</div><!-- #centre -->

	<div id="pied">
		<p id="Copyright">
			Mise en page &copy; 2016
			<a href="http://www.ac-creteil.fr">Académie de Créteil</a> 
		</p>
	</div><!-- #pied -->

</div><!-- #global -->

</body>
</html>
