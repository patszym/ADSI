<?php	

				
					$idCampagne = null;
					
					if(!empty($_POST["idAppli"]))
					{
						$idAppli=$_POST["idAppli"];
					} else
					{
						$idAppli = null;
					}
					
					
					if(!empty($_POST["libelleCampagne"]))						
					{
						$libelleCampagne=$_POST["libelleCampagne"];
					} else
					{
						$libelleCampagne = null;
					}
				
					if(!empty($_POST["descriptifCampagne"]))
					{
						$descriptifCampagne=$_POST["descriptifCampagne"];
					} else
					{
						$descriptifCampagne = null;
					}
					
					
				
					
					
						
		/* Mise à jour :
		 * 
		 */
				if (!empty( $_POST['soumet'] ))  
				{		
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
					$dbh->beginTransaction();
					
					$sql1= "SELECT max(idCAMPAGNE) FROM CAMPAGNE ";
					
					$gid = $dbh->prepare($sql1);
					$gid->execute();
					$idCampagne = $gid->fetchColumn();
					
					
					
					$idCampagne ++ ;
					
					
					$sql = 'insert into CAMPAGNE values ("'.$idCampagne.'",'.
							'"'.$idAppli.'","'.
							
							$libelleCampagne.'","'.
							$descriptifCampagne.'"';
							
							
							
							
					$sql = $sql .');'   ;
					// echo $sql;
					
					$dbh->exec($sql);
					
      				
					$dbh->commit();
					echo "Validation de l'Ajout faite";
				
				} catch (Exception $e) {
					$dbh->rollBack();
					echo "la saisie a échouée: " . $e->getMessage();
				}
			}
				
			?>	