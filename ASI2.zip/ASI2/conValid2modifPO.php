<?php	

if(!empty($_POST["soumet"]))
{

					$idProcessus = $_POST["idProcessus"];
					
					if(!empty($_POST["idRowCampagne"]))
					{
						$idCampagne=$_POST["idRowCampagne"];
					} else
					{
						$idCampagne = null;
					}
					
				
					if(!empty($_POST["libelleProcessus"]))
					{
						$libelleProcessus=$_POST["libelleProcessus"];
					} else
					{
						$libelleProcessus = null;
					}
					if(!empty($_POST["descriptifProcessus"]))
					{
						$descriptifProcessus=$_POST["descriptifProcessus"];
					} else
					{
						$descriptifProcessus = null;
					}
				
					
					include('include/connBase.php');
				
				try {
					$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$sql = 'UPDATE PROCESSUS SET '.
							' CAMPAGNE_idCAMPAGNE ="'.$idCampagne.'",'.
							
							' libellePROCESSUS ="'.$libelleProcessus.'",'.
							' descriptifPROCESSUS ="'.$descriptifProcessus.'"';
						
					
					
					$sql = $sql.' WHERE idPROCESSUS = :idProcessus ';
					
					
					$sth = $dbh->prepare($sql);
					$sth->bindValue(':idProcessus', $idProcessus, PDO::PARAM_INT);
						
					$sth->execute();
						
					echo "Validation de la modification faite";
					
			
      
				} catch (Exception $e) {
					
					echo "la saisie en modification a échouée: " . $e->getMessage();
				}
			
}
				
			?>	